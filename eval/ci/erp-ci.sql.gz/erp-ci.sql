--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Debian 16.15-1.pgdg12+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_move; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_move (
    id integer NOT NULL,
    sequence_number integer,
    message_main_attachment_id integer,
    journal_id integer NOT NULL,
    company_id integer,
    origin_payment_id integer,
    statement_line_id integer,
    tax_cash_basis_rec_id integer,
    tax_cash_basis_origin_move_id integer,
    auto_post_origin_id integer,
    secure_sequence_number integer,
    invoice_payment_term_id integer,
    partner_id integer,
    commercial_partner_id integer,
    partner_shipping_id integer,
    partner_bank_id integer,
    fiscal_position_id integer,
    preferred_payment_method_line_id integer,
    currency_id integer NOT NULL,
    reversed_entry_id integer,
    invoice_user_id integer,
    invoice_incoterm_id integer,
    invoice_cash_rounding_id integer,
    create_uid integer,
    write_uid integer,
    sequence_prefix character varying,
    access_token character varying,
    name character varying,
    ref character varying,
    state character varying NOT NULL,
    move_type character varying NOT NULL,
    auto_post character varying NOT NULL,
    inalterable_hash character varying,
    payment_reference character varying,
    qr_code_method character varying,
    payment_state character varying,
    invoice_source_email character varying,
    invoice_partner_display_name character varying,
    invoice_origin character varying,
    incoterm_location character varying,
    date date NOT NULL,
    auto_post_until date,
    invoice_date date,
    invoice_date_due date,
    delivery_date date,
    taxable_supply_date date,
    sending_data jsonb,
    narration text,
    invoice_currency_rate numeric,
    amount_untaxed numeric,
    amount_tax numeric,
    amount_total numeric,
    amount_residual numeric,
    amount_untaxed_signed numeric,
    amount_untaxed_in_currency_signed numeric,
    amount_tax_signed numeric,
    amount_total_signed numeric,
    amount_total_in_currency_signed numeric,
    amount_residual_signed numeric,
    quick_edit_total_amount numeric,
    always_tax_exigible boolean,
    checked boolean,
    posted_before boolean,
    made_sequence_gap boolean,
    is_manually_modified boolean,
    is_move_sent boolean,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    campaign_id integer,
    source_id integer,
    medium_id integer,
    team_id integer
);


--
-- Name: TABLE account_move; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.account_move IS 'Journal Entry';


--
-- Name: COLUMN account_move.sequence_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.sequence_number IS 'Sequence Number';


--
-- Name: COLUMN account_move.message_main_attachment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.message_main_attachment_id IS 'Main Attachment';


--
-- Name: COLUMN account_move.journal_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.journal_id IS 'Journal';


--
-- Name: COLUMN account_move.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.company_id IS 'Company';


--
-- Name: COLUMN account_move.origin_payment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.origin_payment_id IS 'Payment';


--
-- Name: COLUMN account_move.statement_line_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.statement_line_id IS 'Statement Line';


--
-- Name: COLUMN account_move.tax_cash_basis_rec_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.tax_cash_basis_rec_id IS 'Tax Cash Basis Entry of';


--
-- Name: COLUMN account_move.tax_cash_basis_origin_move_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.tax_cash_basis_origin_move_id IS 'Cash Basis Origin';


--
-- Name: COLUMN account_move.auto_post_origin_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.auto_post_origin_id IS 'First recurring entry';


--
-- Name: COLUMN account_move.secure_sequence_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.secure_sequence_number IS 'Inalterability No Gap Sequence #';


--
-- Name: COLUMN account_move.invoice_payment_term_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_payment_term_id IS 'Payment Terms';


--
-- Name: COLUMN account_move.partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.partner_id IS 'Partner';


--
-- Name: COLUMN account_move.commercial_partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.commercial_partner_id IS 'Commercial Entity';


--
-- Name: COLUMN account_move.partner_shipping_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.partner_shipping_id IS 'Delivery Address';


--
-- Name: COLUMN account_move.partner_bank_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.partner_bank_id IS 'Recipient Bank';


--
-- Name: COLUMN account_move.fiscal_position_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.fiscal_position_id IS 'Fiscal Position';


--
-- Name: COLUMN account_move.preferred_payment_method_line_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.preferred_payment_method_line_id IS 'Preferred Payment Method Line';


--
-- Name: COLUMN account_move.currency_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.currency_id IS 'Currency';


--
-- Name: COLUMN account_move.reversed_entry_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.reversed_entry_id IS 'Reversal of';


--
-- Name: COLUMN account_move.invoice_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_user_id IS 'Salesperson';


--
-- Name: COLUMN account_move.invoice_incoterm_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_incoterm_id IS 'Incoterm';


--
-- Name: COLUMN account_move.invoice_cash_rounding_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_cash_rounding_id IS 'Cash Rounding Method';


--
-- Name: COLUMN account_move.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.create_uid IS 'Created by';


--
-- Name: COLUMN account_move.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.write_uid IS 'Last Updated by';


--
-- Name: COLUMN account_move.sequence_prefix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.sequence_prefix IS 'Sequence Prefix';


--
-- Name: COLUMN account_move.access_token; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.access_token IS 'Security Token';


--
-- Name: COLUMN account_move.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.name IS 'Number';


--
-- Name: COLUMN account_move.ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.ref IS 'Reference';


--
-- Name: COLUMN account_move.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.state IS 'Status';


--
-- Name: COLUMN account_move.move_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.move_type IS 'Type';


--
-- Name: COLUMN account_move.auto_post; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.auto_post IS 'Auto-post';


--
-- Name: COLUMN account_move.inalterable_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.inalterable_hash IS 'Inalterability Hash';


--
-- Name: COLUMN account_move.payment_reference; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.payment_reference IS 'Payment Reference';


--
-- Name: COLUMN account_move.qr_code_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.qr_code_method IS 'Payment QR-code';


--
-- Name: COLUMN account_move.payment_state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.payment_state IS 'Payment Status';


--
-- Name: COLUMN account_move.invoice_source_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_source_email IS 'Source Email';


--
-- Name: COLUMN account_move.invoice_partner_display_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_partner_display_name IS 'Invoice Partner Display Name';


--
-- Name: COLUMN account_move.invoice_origin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_origin IS 'Origin';


--
-- Name: COLUMN account_move.incoterm_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.incoterm_location IS 'Incoterm Location';


--
-- Name: COLUMN account_move.date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.date IS 'Date';


--
-- Name: COLUMN account_move.auto_post_until; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.auto_post_until IS 'Auto-post until';


--
-- Name: COLUMN account_move.invoice_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_date IS 'Invoice/Bill Date';


--
-- Name: COLUMN account_move.invoice_date_due; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_date_due IS 'Due Date';


--
-- Name: COLUMN account_move.delivery_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.delivery_date IS 'Delivery Date';


--
-- Name: COLUMN account_move.taxable_supply_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.taxable_supply_date IS 'Taxable Supply Date';


--
-- Name: COLUMN account_move.sending_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.sending_data IS 'Sending Data';


--
-- Name: COLUMN account_move.narration; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.narration IS 'Terms and Conditions';


--
-- Name: COLUMN account_move.invoice_currency_rate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.invoice_currency_rate IS 'Currency Rate';


--
-- Name: COLUMN account_move.amount_untaxed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_untaxed IS 'Untaxed Amount';


--
-- Name: COLUMN account_move.amount_tax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_tax IS 'Tax';


--
-- Name: COLUMN account_move.amount_total; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_total IS 'Total';


--
-- Name: COLUMN account_move.amount_residual; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_residual IS 'Amount Due';


--
-- Name: COLUMN account_move.amount_untaxed_signed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_untaxed_signed IS 'Untaxed Amount Signed';


--
-- Name: COLUMN account_move.amount_untaxed_in_currency_signed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_untaxed_in_currency_signed IS 'Untaxed Amount Signed Currency';


--
-- Name: COLUMN account_move.amount_tax_signed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_tax_signed IS 'Tax Signed';


--
-- Name: COLUMN account_move.amount_total_signed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_total_signed IS 'Total Signed';


--
-- Name: COLUMN account_move.amount_total_in_currency_signed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_total_in_currency_signed IS 'Total in Currency Signed';


--
-- Name: COLUMN account_move.amount_residual_signed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.amount_residual_signed IS 'Amount Due Signed';


--
-- Name: COLUMN account_move.quick_edit_total_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.quick_edit_total_amount IS 'Total (Tax inc.)';


--
-- Name: COLUMN account_move.always_tax_exigible; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.always_tax_exigible IS 'Always Tax Exigible';


--
-- Name: COLUMN account_move.checked; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.checked IS 'Reviewed';


--
-- Name: COLUMN account_move.posted_before; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.posted_before IS 'Posted Before';


--
-- Name: COLUMN account_move.made_sequence_gap; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.made_sequence_gap IS 'Made Sequence Gap';


--
-- Name: COLUMN account_move.is_manually_modified; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.is_manually_modified IS 'Is Manually Modified';


--
-- Name: COLUMN account_move.is_move_sent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.is_move_sent IS 'Is Move Sent';


--
-- Name: COLUMN account_move.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.create_date IS 'Created on';


--
-- Name: COLUMN account_move.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.write_date IS 'Last Updated on';


--
-- Name: COLUMN account_move.campaign_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.campaign_id IS 'Campaign';


--
-- Name: COLUMN account_move.source_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.source_id IS 'Source';


--
-- Name: COLUMN account_move.medium_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.medium_id IS 'Medium';


--
-- Name: COLUMN account_move.team_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.account_move.team_id IS 'Sales Team';


--
-- Name: account_move_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.account_move_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: account_move_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.account_move_id_seq OWNED BY public.account_move.id;


--
-- Name: product_product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_product (
    id integer NOT NULL,
    product_tmpl_id integer NOT NULL,
    create_uid integer,
    write_uid integer,
    default_code character varying,
    barcode character varying,
    combination_indices character varying,
    standard_price jsonb,
    volume numeric,
    weight numeric,
    active boolean,
    can_image_variant_1024_be_zoomed boolean,
    is_favorite boolean,
    is_in_selected_section_of_order boolean,
    write_date timestamp without time zone,
    create_date timestamp without time zone,
    lot_properties_definition jsonb
);


--
-- Name: TABLE product_product; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_product IS 'Product Variant';


--
-- Name: COLUMN product_product.product_tmpl_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.product_tmpl_id IS 'Product Template';


--
-- Name: COLUMN product_product.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.create_uid IS 'Created by';


--
-- Name: COLUMN product_product.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.write_uid IS 'Last Updated by';


--
-- Name: COLUMN product_product.default_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.default_code IS 'Internal Reference';


--
-- Name: COLUMN product_product.barcode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.barcode IS 'Barcode';


--
-- Name: COLUMN product_product.combination_indices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.combination_indices IS 'Combination Indices';


--
-- Name: COLUMN product_product.standard_price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.standard_price IS 'Cost';


--
-- Name: COLUMN product_product.volume; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.volume IS 'Volume';


--
-- Name: COLUMN product_product.weight; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.weight IS 'Weight';


--
-- Name: COLUMN product_product.active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.active IS 'Active';


--
-- Name: COLUMN product_product.can_image_variant_1024_be_zoomed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.can_image_variant_1024_be_zoomed IS 'Can Variant Image 1024 be zoomed';


--
-- Name: COLUMN product_product.is_favorite; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.is_favorite IS 'Favorite';


--
-- Name: COLUMN product_product.is_in_selected_section_of_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.is_in_selected_section_of_order IS 'Is In Selected Section Of Order';


--
-- Name: COLUMN product_product.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.write_date IS 'Write Date';


--
-- Name: COLUMN product_product.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.create_date IS 'Created on';


--
-- Name: COLUMN product_product.lot_properties_definition; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_product.lot_properties_definition IS 'Lot Properties';


--
-- Name: product_product_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_product_id_seq OWNED BY public.product_product.id;


--
-- Name: product_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.product_template (
    id integer NOT NULL,
    sequence integer,
    categ_id integer,
    uom_id integer NOT NULL,
    company_id integer,
    color integer,
    create_uid integer,
    write_uid integer,
    type character varying NOT NULL,
    service_tracking character varying NOT NULL,
    default_code character varying,
    name jsonb NOT NULL,
    description jsonb,
    description_purchase jsonb,
    description_sale jsonb,
    product_properties jsonb,
    list_price numeric,
    volume numeric,
    weight numeric,
    sale_ok boolean,
    purchase_ok boolean,
    active boolean,
    can_image_1024_be_zoomed boolean,
    has_configurable_attributes boolean,
    is_favorite boolean,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    property_account_income_id jsonb,
    property_account_expense_id jsonb,
    sale_delay integer,
    lot_sequence_id integer,
    tracking character varying NOT NULL,
    responsible_id jsonb,
    property_stock_production jsonb,
    property_stock_inventory jsonb,
    description_picking jsonb,
    description_pickingout jsonb,
    description_pickingin jsonb,
    is_storable boolean,
    purchase_method character varying,
    purchase_line_warn_msg text,
    property_price_difference_account_id jsonb,
    lot_valuated boolean,
    service_type character varying,
    expense_policy character varying,
    invoice_policy character varying,
    sale_line_warn_msg text,
    service_to_purchase jsonb
);


--
-- Name: TABLE product_template; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.product_template IS 'Product';


--
-- Name: COLUMN product_template.sequence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.sequence IS 'Sequence';


--
-- Name: COLUMN product_template.categ_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.categ_id IS 'Product Category';


--
-- Name: COLUMN product_template.uom_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.uom_id IS 'Unit';


--
-- Name: COLUMN product_template.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.company_id IS 'Company';


--
-- Name: COLUMN product_template.color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.color IS 'Color Index';


--
-- Name: COLUMN product_template.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.create_uid IS 'Created by';


--
-- Name: COLUMN product_template.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.write_uid IS 'Last Updated by';


--
-- Name: COLUMN product_template.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.type IS 'Product Type';


--
-- Name: COLUMN product_template.service_tracking; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.service_tracking IS 'Create on Order';


--
-- Name: COLUMN product_template.default_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.default_code IS 'Internal Reference';


--
-- Name: COLUMN product_template.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.name IS 'Name';


--
-- Name: COLUMN product_template.description; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.description IS 'Description';


--
-- Name: COLUMN product_template.description_purchase; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.description_purchase IS 'Purchase Description';


--
-- Name: COLUMN product_template.description_sale; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.description_sale IS 'Sales Description';


--
-- Name: COLUMN product_template.product_properties; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.product_properties IS 'Properties';


--
-- Name: COLUMN product_template.list_price; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.list_price IS 'Sales Price';


--
-- Name: COLUMN product_template.volume; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.volume IS 'Volume';


--
-- Name: COLUMN product_template.weight; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.weight IS 'Weight';


--
-- Name: COLUMN product_template.sale_ok; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.sale_ok IS 'Sales';


--
-- Name: COLUMN product_template.purchase_ok; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.purchase_ok IS 'Purchase';


--
-- Name: COLUMN product_template.active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.active IS 'Active';


--
-- Name: COLUMN product_template.can_image_1024_be_zoomed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.can_image_1024_be_zoomed IS 'Can Image 1024 be zoomed';


--
-- Name: COLUMN product_template.has_configurable_attributes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.has_configurable_attributes IS 'Is a configurable product';


--
-- Name: COLUMN product_template.is_favorite; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.is_favorite IS 'Favorite';


--
-- Name: COLUMN product_template.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.create_date IS 'Created on';


--
-- Name: COLUMN product_template.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.write_date IS 'Last Updated on';


--
-- Name: COLUMN product_template.property_account_income_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.property_account_income_id IS 'Income Account';


--
-- Name: COLUMN product_template.property_account_expense_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.property_account_expense_id IS 'Expense Account';


--
-- Name: COLUMN product_template.sale_delay; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.sale_delay IS 'Customer Lead Time';


--
-- Name: COLUMN product_template.lot_sequence_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.lot_sequence_id IS 'Serial/Lot Numbers Sequence';


--
-- Name: COLUMN product_template.tracking; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.tracking IS 'Tracking';


--
-- Name: COLUMN product_template.responsible_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.responsible_id IS 'Responsible';


--
-- Name: COLUMN product_template.property_stock_production; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.property_stock_production IS 'Production Location';


--
-- Name: COLUMN product_template.property_stock_inventory; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.property_stock_inventory IS 'Inventory Location';


--
-- Name: COLUMN product_template.description_picking; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.description_picking IS 'Description on Picking';


--
-- Name: COLUMN product_template.description_pickingout; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.description_pickingout IS 'Description on Delivery Orders';


--
-- Name: COLUMN product_template.description_pickingin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.description_pickingin IS 'Description on Receptions';


--
-- Name: COLUMN product_template.is_storable; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.is_storable IS 'Track Inventory';


--
-- Name: COLUMN product_template.purchase_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.purchase_method IS 'Control Policy';


--
-- Name: COLUMN product_template.purchase_line_warn_msg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.purchase_line_warn_msg IS 'Message for Purchase Order Line';


--
-- Name: COLUMN product_template.property_price_difference_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.property_price_difference_account_id IS 'Price Difference Account';


--
-- Name: COLUMN product_template.lot_valuated; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.lot_valuated IS 'Valuation by Lot/Serial';


--
-- Name: COLUMN product_template.service_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.service_type IS 'Track Service';


--
-- Name: COLUMN product_template.expense_policy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.expense_policy IS 'Re-Invoice Costs';


--
-- Name: COLUMN product_template.invoice_policy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.invoice_policy IS 'Invoicing Policy';


--
-- Name: COLUMN product_template.sale_line_warn_msg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.sale_line_warn_msg IS 'Sales Order Line Warning';


--
-- Name: COLUMN product_template.service_to_purchase; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.product_template.service_to_purchase IS 'Subcontract Service';


--
-- Name: product_template_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.product_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: product_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.product_template_id_seq OWNED BY public.product_template.id;


--
-- Name: purchase_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order (
    id integer NOT NULL,
    partner_id integer NOT NULL,
    dest_address_id integer,
    currency_id integer NOT NULL,
    invoice_count integer,
    fiscal_position_id integer,
    payment_term_id integer,
    incoterm_id integer,
    user_id integer,
    company_id integer NOT NULL,
    reminder_date_before_receipt integer,
    create_uid integer,
    write_uid integer,
    access_token character varying,
    name character varying NOT NULL,
    priority character varying,
    origin character varying,
    partner_ref character varying,
    state character varying,
    invoice_status character varying,
    note text,
    amount_untaxed numeric,
    amount_tax numeric,
    amount_total numeric,
    amount_total_cc numeric,
    currency_rate numeric,
    locked boolean,
    acknowledged boolean,
    receipt_reminder_email boolean,
    date_order timestamp without time zone NOT NULL,
    date_approve timestamp without time zone,
    date_planned timestamp without time zone,
    date_calendar_start timestamp without time zone,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    picking_type_id integer NOT NULL,
    incoterm_location character varying,
    receipt_status character varying,
    effective_date timestamp without time zone
);


--
-- Name: TABLE purchase_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.purchase_order IS 'Purchase Order';


--
-- Name: COLUMN purchase_order.partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.partner_id IS 'Vendor';


--
-- Name: COLUMN purchase_order.dest_address_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.dest_address_id IS 'Dropship Address';


--
-- Name: COLUMN purchase_order.currency_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.currency_id IS 'Currency';


--
-- Name: COLUMN purchase_order.invoice_count; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.invoice_count IS 'Bill Count';


--
-- Name: COLUMN purchase_order.fiscal_position_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.fiscal_position_id IS 'Fiscal Position';


--
-- Name: COLUMN purchase_order.payment_term_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.payment_term_id IS 'Payment Terms';


--
-- Name: COLUMN purchase_order.incoterm_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.incoterm_id IS 'Incoterm';


--
-- Name: COLUMN purchase_order.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.user_id IS 'Buyer';


--
-- Name: COLUMN purchase_order.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.company_id IS 'Company';


--
-- Name: COLUMN purchase_order.reminder_date_before_receipt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.reminder_date_before_receipt IS 'Days Before Receipt';


--
-- Name: COLUMN purchase_order.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.create_uid IS 'Created by';


--
-- Name: COLUMN purchase_order.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.write_uid IS 'Last Updated by';


--
-- Name: COLUMN purchase_order.access_token; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.access_token IS 'Security Token';


--
-- Name: COLUMN purchase_order.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.name IS 'Order Reference';


--
-- Name: COLUMN purchase_order.priority; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.priority IS 'Priority';


--
-- Name: COLUMN purchase_order.origin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.origin IS 'Source';


--
-- Name: COLUMN purchase_order.partner_ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.partner_ref IS 'Vendor Reference';


--
-- Name: COLUMN purchase_order.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.state IS 'Status';


--
-- Name: COLUMN purchase_order.invoice_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.invoice_status IS 'Billing Status';


--
-- Name: COLUMN purchase_order.note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.note IS 'Terms and Conditions';


--
-- Name: COLUMN purchase_order.amount_untaxed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.amount_untaxed IS 'Untaxed Amount';


--
-- Name: COLUMN purchase_order.amount_tax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.amount_tax IS 'Taxes';


--
-- Name: COLUMN purchase_order.amount_total; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.amount_total IS 'Total';


--
-- Name: COLUMN purchase_order.amount_total_cc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.amount_total_cc IS 'Total in currency';


--
-- Name: COLUMN purchase_order.currency_rate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.currency_rate IS 'Currency Rate';


--
-- Name: COLUMN purchase_order.locked; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.locked IS 'Locked';


--
-- Name: COLUMN purchase_order.acknowledged; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.acknowledged IS 'Acknowledged';


--
-- Name: COLUMN purchase_order.receipt_reminder_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.receipt_reminder_email IS 'Receipt Reminder Email';


--
-- Name: COLUMN purchase_order.date_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.date_order IS 'Order Deadline';


--
-- Name: COLUMN purchase_order.date_approve; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.date_approve IS 'Confirmation Date';


--
-- Name: COLUMN purchase_order.date_planned; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.date_planned IS 'Expected Arrival';


--
-- Name: COLUMN purchase_order.date_calendar_start; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.date_calendar_start IS 'Date Calendar Start';


--
-- Name: COLUMN purchase_order.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.create_date IS 'Created on';


--
-- Name: COLUMN purchase_order.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.write_date IS 'Last Updated on';


--
-- Name: COLUMN purchase_order.picking_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.picking_type_id IS 'Deliver To';


--
-- Name: COLUMN purchase_order.incoterm_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.incoterm_location IS 'Incoterm Location';


--
-- Name: COLUMN purchase_order.receipt_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.receipt_status IS 'Receipt Status';


--
-- Name: COLUMN purchase_order.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order.effective_date IS 'Arrival';


--
-- Name: purchase_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_order_id_seq OWNED BY public.purchase_order.id;


--
-- Name: purchase_order_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_line (
    id integer NOT NULL,
    sequence integer,
    product_uom_id integer,
    product_id integer,
    order_id integer NOT NULL,
    company_id integer,
    partner_id integer,
    create_uid integer,
    write_uid integer,
    qty_received_method character varying,
    display_type character varying,
    analytic_distribution jsonb,
    name text NOT NULL,
    product_qty numeric NOT NULL,
    discount numeric,
    price_unit numeric NOT NULL,
    price_subtotal numeric,
    price_total numeric,
    qty_invoiced numeric,
    qty_received numeric,
    qty_received_manual numeric,
    qty_to_invoice numeric,
    is_downpayment boolean,
    date_planned timestamp without time zone,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    product_uom_qty double precision,
    price_tax double precision,
    technical_price_unit double precision,
    orderpoint_id integer,
    location_final_id integer,
    product_description_variants character varying,
    propagate_cancel boolean,
    sale_line_id integer,
    CONSTRAINT purchase_order_line_accountable_required_fields CHECK (((display_type IS NOT NULL) OR is_downpayment OR ((product_id IS NOT NULL) AND (product_uom_id IS NOT NULL) AND (date_planned IS NOT NULL)))),
    CONSTRAINT purchase_order_line_non_accountable_null_fields CHECK (((display_type IS NULL) OR ((product_id IS NULL) AND (price_unit = (0)::numeric) AND (product_uom_qty = (0)::double precision) AND (product_uom_id IS NULL) AND (date_planned IS NULL))))
);


--
-- Name: TABLE purchase_order_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.purchase_order_line IS 'Purchase Order Line';


--
-- Name: COLUMN purchase_order_line.sequence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.sequence IS 'Sequence';


--
-- Name: COLUMN purchase_order_line.product_uom_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.product_uom_id IS 'Unit';


--
-- Name: COLUMN purchase_order_line.product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.product_id IS 'Product';


--
-- Name: COLUMN purchase_order_line.order_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.order_id IS 'Order Reference';


--
-- Name: COLUMN purchase_order_line.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.company_id IS 'Company';


--
-- Name: COLUMN purchase_order_line.partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.partner_id IS 'Partner';


--
-- Name: COLUMN purchase_order_line.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.create_uid IS 'Created by';


--
-- Name: COLUMN purchase_order_line.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.write_uid IS 'Last Updated by';


--
-- Name: COLUMN purchase_order_line.qty_received_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.qty_received_method IS 'Received Qty Method';


--
-- Name: COLUMN purchase_order_line.display_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.display_type IS 'Display Type';


--
-- Name: COLUMN purchase_order_line.analytic_distribution; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.analytic_distribution IS 'Analytic Distribution';


--
-- Name: COLUMN purchase_order_line.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.name IS 'Description';


--
-- Name: COLUMN purchase_order_line.product_qty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.product_qty IS 'Quantity';


--
-- Name: COLUMN purchase_order_line.discount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.discount IS 'Discount (%)';


--
-- Name: COLUMN purchase_order_line.price_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.price_unit IS 'Unit Price';


--
-- Name: COLUMN purchase_order_line.price_subtotal; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.price_subtotal IS 'Subtotal';


--
-- Name: COLUMN purchase_order_line.price_total; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.price_total IS 'Total';


--
-- Name: COLUMN purchase_order_line.qty_invoiced; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.qty_invoiced IS 'Billed Qty';


--
-- Name: COLUMN purchase_order_line.qty_received; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.qty_received IS 'Received Qty';


--
-- Name: COLUMN purchase_order_line.qty_received_manual; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.qty_received_manual IS 'Manual Received Qty';


--
-- Name: COLUMN purchase_order_line.qty_to_invoice; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.qty_to_invoice IS 'To Invoice Quantity';


--
-- Name: COLUMN purchase_order_line.is_downpayment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.is_downpayment IS 'Is Downpayment';


--
-- Name: COLUMN purchase_order_line.date_planned; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.date_planned IS 'Expected Arrival';


--
-- Name: COLUMN purchase_order_line.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.create_date IS 'Created on';


--
-- Name: COLUMN purchase_order_line.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.write_date IS 'Last Updated on';


--
-- Name: COLUMN purchase_order_line.product_uom_qty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.product_uom_qty IS 'Total Quantity';


--
-- Name: COLUMN purchase_order_line.price_tax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.price_tax IS 'Tax';


--
-- Name: COLUMN purchase_order_line.technical_price_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.technical_price_unit IS 'Technical Price Unit';


--
-- Name: COLUMN purchase_order_line.orderpoint_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.orderpoint_id IS 'Orderpoint';


--
-- Name: COLUMN purchase_order_line.location_final_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.location_final_id IS 'Location from procurement';


--
-- Name: COLUMN purchase_order_line.product_description_variants; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.product_description_variants IS 'Custom Description';


--
-- Name: COLUMN purchase_order_line.propagate_cancel; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.propagate_cancel IS 'Propagate cancellation';


--
-- Name: COLUMN purchase_order_line.sale_line_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.purchase_order_line.sale_line_id IS 'Origin Sale Item';


--
-- Name: CONSTRAINT purchase_order_line_accountable_required_fields ON purchase_order_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT purchase_order_line_accountable_required_fields ON public.purchase_order_line IS 'CHECK(display_type IS NOT NULL OR is_downpayment OR (product_id IS NOT NULL AND product_uom_id IS NOT NULL AND date_planned IS NOT NULL))';


--
-- Name: CONSTRAINT purchase_order_line_non_accountable_null_fields ON purchase_order_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT purchase_order_line_non_accountable_null_fields ON public.purchase_order_line IS 'CHECK(display_type IS NULL OR (product_id IS NULL AND price_unit = 0 AND product_uom_qty = 0 AND product_uom_id IS NULL AND date_planned is NULL))';


--
-- Name: purchase_order_line_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.purchase_order_line_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: purchase_order_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.purchase_order_line_id_seq OWNED BY public.purchase_order_line.id;


--
-- Name: res_company; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_company (
    id integer NOT NULL,
    name character varying NOT NULL,
    partner_id integer NOT NULL,
    currency_id integer NOT NULL,
    sequence integer,
    create_date timestamp without time zone,
    parent_path character varying,
    parent_id integer,
    paperformat_id integer,
    external_report_layout_id integer,
    create_uid integer,
    write_uid integer,
    email character varying,
    phone character varying,
    font character varying,
    primary_color character varying,
    secondary_color character varying,
    layout_background character varying NOT NULL,
    report_header jsonb,
    report_footer jsonb,
    company_details jsonb,
    active boolean,
    uses_default_logo boolean,
    write_date timestamp without time zone,
    logo_web bytea,
    nomenclature_id integer,
    resource_calendar_id integer,
    alias_domain_id integer,
    email_primary_color character varying,
    email_secondary_color character varying,
    iap_enrich_auto_done boolean,
    snailmail_color boolean,
    snailmail_cover boolean,
    snailmail_duplex boolean,
    fiscalyear_last_day integer NOT NULL,
    transfer_account_id integer,
    default_cash_difference_income_account_id integer,
    default_cash_difference_expense_account_id integer,
    account_journal_suspense_account_id integer,
    account_journal_early_pay_discount_gain_account_id integer,
    account_journal_early_pay_discount_loss_account_id integer,
    account_sale_tax_id integer,
    account_purchase_tax_id integer,
    account_purchase_receipt_fiscal_position_id integer,
    currency_exchange_journal_id integer,
    income_currency_exchange_account_id integer,
    expense_currency_exchange_account_id integer,
    incoterm_id integer,
    batch_payment_sequence_id integer,
    account_opening_move_id integer,
    account_default_pos_receivable_account_id integer,
    expense_accrual_account_id integer,
    revenue_accrual_account_id integer,
    automatic_entry_default_journal_id integer,
    domestic_fiscal_position_id integer,
    account_fiscal_country_id integer,
    tax_cash_basis_journal_id integer,
    account_cash_basis_base_account_id integer,
    account_discount_income_allocation_id integer,
    account_discount_expense_allocation_id integer,
    income_account_id integer,
    expense_account_id integer,
    price_difference_account_id integer,
    fiscalyear_last_month character varying NOT NULL,
    chart_template character varying,
    bank_account_code_prefix character varying,
    cash_account_code_prefix character varying,
    transfer_account_code_prefix character varying,
    tax_calculation_rounding_method character varying,
    terms_type character varying,
    quick_edit_mode character varying,
    account_price_include character varying NOT NULL,
    fiscalyear_lock_date date,
    tax_lock_date date,
    sale_lock_date date,
    purchase_lock_date date,
    hard_lock_date date,
    account_opening_date date,
    invoice_terms jsonb,
    invoice_terms_html jsonb,
    expects_chart_of_accounts boolean,
    anglo_saxon_accounting boolean,
    qr_code boolean,
    link_qr_code boolean,
    display_invoice_amount_total_words boolean,
    display_invoice_tax_company_currency boolean,
    account_use_credit_limit boolean,
    tax_exigibility boolean,
    account_storno boolean,
    restrictive_audit_trail boolean,
    autopost_bills boolean,
    internal_transit_location_id integer,
    stock_mail_confirmation_template_id integer,
    annual_inventory_day integer,
    annual_inventory_month character varying,
    stock_confirmation_type character varying,
    stock_move_email_validation boolean,
    stock_text_confirmation boolean,
    horizon_days double precision NOT NULL,
    po_lock character varying,
    po_double_validation character varying,
    po_double_validation_amount numeric,
    account_stock_journal_id integer,
    account_stock_valuation_id integer,
    account_production_wip_account_id integer,
    account_production_wip_overhead_account_id integer,
    inventory_period character varying NOT NULL,
    inventory_valuation character varying,
    cost_method character varying NOT NULL,
    stock_sms_confirmation_template_id integer,
    has_received_warning_stock_sms boolean,
    days_to_purchase double precision,
    quotation_validity_days integer,
    sale_discount_product_id integer,
    downpayment_account_id integer,
    sale_onboarding_payment_method character varying,
    portal_confirmation_sign boolean,
    portal_confirmation_pay boolean,
    prepayment_percent double precision,
    sale_order_template_id integer,
    security_lead double precision NOT NULL,
    CONSTRAINT res_company_check_quotation_validity_days CHECK ((quotation_validity_days >= 0))
);


--
-- Name: COLUMN res_company.parent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.parent_id IS 'Parent Company';


--
-- Name: COLUMN res_company.paperformat_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.paperformat_id IS 'Paper format';


--
-- Name: COLUMN res_company.external_report_layout_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.external_report_layout_id IS 'Document Template';


--
-- Name: COLUMN res_company.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.create_uid IS 'Created by';


--
-- Name: COLUMN res_company.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.write_uid IS 'Last Updated by';


--
-- Name: COLUMN res_company.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.email IS 'Email';


--
-- Name: COLUMN res_company.phone; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.phone IS 'Phone';


--
-- Name: COLUMN res_company.font; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.font IS 'Font';


--
-- Name: COLUMN res_company.primary_color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.primary_color IS 'Primary Color';


--
-- Name: COLUMN res_company.secondary_color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.secondary_color IS 'Secondary Color';


--
-- Name: COLUMN res_company.layout_background; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.layout_background IS 'Layout Background';


--
-- Name: COLUMN res_company.report_header; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.report_header IS 'Company Tagline';


--
-- Name: COLUMN res_company.report_footer; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.report_footer IS 'Report Footer';


--
-- Name: COLUMN res_company.company_details; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.company_details IS 'Company Details';


--
-- Name: COLUMN res_company.active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.active IS 'Active';


--
-- Name: COLUMN res_company.uses_default_logo; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.uses_default_logo IS 'Uses Default Logo';


--
-- Name: COLUMN res_company.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.write_date IS 'Last Updated on';


--
-- Name: COLUMN res_company.logo_web; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.logo_web IS 'Logo Web';


--
-- Name: COLUMN res_company.nomenclature_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.nomenclature_id IS 'Nomenclature';


--
-- Name: COLUMN res_company.resource_calendar_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.resource_calendar_id IS 'Default Working Hours';


--
-- Name: COLUMN res_company.alias_domain_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.alias_domain_id IS 'Email Domain';


--
-- Name: COLUMN res_company.email_primary_color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.email_primary_color IS 'Email Button Text';


--
-- Name: COLUMN res_company.email_secondary_color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.email_secondary_color IS 'Email Button Color';


--
-- Name: COLUMN res_company.iap_enrich_auto_done; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.iap_enrich_auto_done IS 'Enrich Done';


--
-- Name: COLUMN res_company.snailmail_color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.snailmail_color IS 'Snailmail Color';


--
-- Name: COLUMN res_company.snailmail_cover; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.snailmail_cover IS 'Add a Cover Page';


--
-- Name: COLUMN res_company.snailmail_duplex; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.snailmail_duplex IS 'Both sides';


--
-- Name: COLUMN res_company.fiscalyear_last_day; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.fiscalyear_last_day IS 'Fiscalyear Last Day';


--
-- Name: COLUMN res_company.transfer_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.transfer_account_id IS 'Inter-Banks Transfer Account';


--
-- Name: COLUMN res_company.default_cash_difference_income_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.default_cash_difference_income_account_id IS 'Cash Difference Income';


--
-- Name: COLUMN res_company.default_cash_difference_expense_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.default_cash_difference_expense_account_id IS 'Cash Difference Expense';


--
-- Name: COLUMN res_company.account_journal_suspense_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_journal_suspense_account_id IS 'Journal Suspense Account';


--
-- Name: COLUMN res_company.account_journal_early_pay_discount_gain_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_journal_early_pay_discount_gain_account_id IS 'Cash Discount Write-Off Gain Account';


--
-- Name: COLUMN res_company.account_journal_early_pay_discount_loss_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_journal_early_pay_discount_loss_account_id IS 'Cash Discount Write-Off Loss Account';


--
-- Name: COLUMN res_company.account_sale_tax_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_sale_tax_id IS 'Default Sale Tax';


--
-- Name: COLUMN res_company.account_purchase_tax_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_purchase_tax_id IS 'Default Purchase Tax';


--
-- Name: COLUMN res_company.account_purchase_receipt_fiscal_position_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_purchase_receipt_fiscal_position_id IS 'Default Purchase Receipt Fiscal Position';


--
-- Name: COLUMN res_company.currency_exchange_journal_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.currency_exchange_journal_id IS 'Exchange Gain or Loss Journal';


--
-- Name: COLUMN res_company.income_currency_exchange_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.income_currency_exchange_account_id IS 'Gain Exchange Rate Account';


--
-- Name: COLUMN res_company.expense_currency_exchange_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.expense_currency_exchange_account_id IS 'Loss Exchange Rate Account';


--
-- Name: COLUMN res_company.incoterm_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.incoterm_id IS 'Default incoterm';


--
-- Name: COLUMN res_company.batch_payment_sequence_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.batch_payment_sequence_id IS 'Batch Payment Sequence';


--
-- Name: COLUMN res_company.account_opening_move_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_opening_move_id IS 'Opening Journal Entry';


--
-- Name: COLUMN res_company.account_default_pos_receivable_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_default_pos_receivable_account_id IS 'Default PoS Receivable Account';


--
-- Name: COLUMN res_company.expense_accrual_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.expense_accrual_account_id IS 'Expense Accrual Account';


--
-- Name: COLUMN res_company.revenue_accrual_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.revenue_accrual_account_id IS 'Revenue Accrual Account';


--
-- Name: COLUMN res_company.automatic_entry_default_journal_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.automatic_entry_default_journal_id IS 'Automatic Entry Default Journal';


--
-- Name: COLUMN res_company.domestic_fiscal_position_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.domestic_fiscal_position_id IS 'Domestic Fiscal Position';


--
-- Name: COLUMN res_company.account_fiscal_country_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_fiscal_country_id IS 'Fiscal Country';


--
-- Name: COLUMN res_company.tax_cash_basis_journal_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.tax_cash_basis_journal_id IS 'Cash Basis Journal';


--
-- Name: COLUMN res_company.account_cash_basis_base_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_cash_basis_base_account_id IS 'Base Tax Received Account';


--
-- Name: COLUMN res_company.account_discount_income_allocation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_discount_income_allocation_id IS 'Separate account for income discount';


--
-- Name: COLUMN res_company.account_discount_expense_allocation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_discount_expense_allocation_id IS 'Separate account for expense discount';


--
-- Name: COLUMN res_company.income_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.income_account_id IS 'Income Account';


--
-- Name: COLUMN res_company.expense_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.expense_account_id IS 'Expense Account';


--
-- Name: COLUMN res_company.price_difference_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.price_difference_account_id IS 'Price Difference Account';


--
-- Name: COLUMN res_company.fiscalyear_last_month; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.fiscalyear_last_month IS 'Fiscalyear Last Month';


--
-- Name: COLUMN res_company.chart_template; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.chart_template IS 'Chart Template';


--
-- Name: COLUMN res_company.bank_account_code_prefix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.bank_account_code_prefix IS 'Prefix of the bank accounts';


--
-- Name: COLUMN res_company.cash_account_code_prefix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.cash_account_code_prefix IS 'Prefix of the cash accounts';


--
-- Name: COLUMN res_company.transfer_account_code_prefix; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.transfer_account_code_prefix IS 'Prefix of the transfer accounts';


--
-- Name: COLUMN res_company.tax_calculation_rounding_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.tax_calculation_rounding_method IS 'Tax Calculation Rounding Method';


--
-- Name: COLUMN res_company.terms_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.terms_type IS 'Terms & Conditions format';


--
-- Name: COLUMN res_company.quick_edit_mode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.quick_edit_mode IS 'Quick encoding';


--
-- Name: COLUMN res_company.account_price_include; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_price_include IS 'Default Sales Price Include';


--
-- Name: COLUMN res_company.fiscalyear_lock_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.fiscalyear_lock_date IS 'Global Lock Date';


--
-- Name: COLUMN res_company.tax_lock_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.tax_lock_date IS 'Tax Return Lock Date';


--
-- Name: COLUMN res_company.sale_lock_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.sale_lock_date IS 'Sales Lock Date';


--
-- Name: COLUMN res_company.purchase_lock_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.purchase_lock_date IS 'Purchase Lock date';


--
-- Name: COLUMN res_company.hard_lock_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.hard_lock_date IS 'Hard Lock Date';


--
-- Name: COLUMN res_company.account_opening_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_opening_date IS 'Opening Entry';


--
-- Name: COLUMN res_company.invoice_terms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.invoice_terms IS 'Default Terms and Conditions';


--
-- Name: COLUMN res_company.invoice_terms_html; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.invoice_terms_html IS 'Default Terms and Conditions as a Web page';


--
-- Name: COLUMN res_company.expects_chart_of_accounts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.expects_chart_of_accounts IS 'Expects a Chart of Accounts';


--
-- Name: COLUMN res_company.anglo_saxon_accounting; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.anglo_saxon_accounting IS 'Use anglo-saxon accounting';


--
-- Name: COLUMN res_company.qr_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.qr_code IS 'Display QR-code on invoices';


--
-- Name: COLUMN res_company.link_qr_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.link_qr_code IS 'Display Link QR-code';


--
-- Name: COLUMN res_company.display_invoice_amount_total_words; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.display_invoice_amount_total_words IS 'Total amount of invoice in letters';


--
-- Name: COLUMN res_company.display_invoice_tax_company_currency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.display_invoice_tax_company_currency IS 'Taxes in company currency';


--
-- Name: COLUMN res_company.account_use_credit_limit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_use_credit_limit IS 'Sales Credit Limit';


--
-- Name: COLUMN res_company.tax_exigibility; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.tax_exigibility IS 'Use Cash Basis';


--
-- Name: COLUMN res_company.account_storno; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_storno IS 'Storno accounting';


--
-- Name: COLUMN res_company.restrictive_audit_trail; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.restrictive_audit_trail IS 'Restrictive Audit Trail';


--
-- Name: COLUMN res_company.autopost_bills; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.autopost_bills IS 'Auto-validate bills';


--
-- Name: COLUMN res_company.internal_transit_location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.internal_transit_location_id IS 'Internal Transit Location';


--
-- Name: COLUMN res_company.stock_mail_confirmation_template_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.stock_mail_confirmation_template_id IS 'Email Template confirmation picking';


--
-- Name: COLUMN res_company.annual_inventory_day; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.annual_inventory_day IS 'Day of the month';


--
-- Name: COLUMN res_company.annual_inventory_month; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.annual_inventory_month IS 'Annual Inventory Month';


--
-- Name: COLUMN res_company.stock_confirmation_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.stock_confirmation_type IS 'Stock Confirmation Type';


--
-- Name: COLUMN res_company.stock_move_email_validation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.stock_move_email_validation IS 'Email Confirmation picking';


--
-- Name: COLUMN res_company.stock_text_confirmation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.stock_text_confirmation IS 'Stock Text Confirmation';


--
-- Name: COLUMN res_company.horizon_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.horizon_days IS 'Replenishment Horizon';


--
-- Name: COLUMN res_company.po_lock; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.po_lock IS 'Purchase Order Modification';


--
-- Name: COLUMN res_company.po_double_validation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.po_double_validation IS 'Levels of Approvals';


--
-- Name: COLUMN res_company.po_double_validation_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.po_double_validation_amount IS 'Double validation amount';


--
-- Name: COLUMN res_company.account_stock_journal_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_stock_journal_id IS 'Stock Journal';


--
-- Name: COLUMN res_company.account_stock_valuation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_stock_valuation_id IS 'Stock Valuation Account';


--
-- Name: COLUMN res_company.account_production_wip_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_production_wip_account_id IS 'Production WIP Account';


--
-- Name: COLUMN res_company.account_production_wip_overhead_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.account_production_wip_overhead_account_id IS 'Production WIP Overhead Account';


--
-- Name: COLUMN res_company.inventory_period; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.inventory_period IS 'Inventory Period';


--
-- Name: COLUMN res_company.inventory_valuation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.inventory_valuation IS 'Valuation';


--
-- Name: COLUMN res_company.cost_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.cost_method IS 'Cost Method';


--
-- Name: COLUMN res_company.stock_sms_confirmation_template_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.stock_sms_confirmation_template_id IS 'SMS Template';


--
-- Name: COLUMN res_company.has_received_warning_stock_sms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.has_received_warning_stock_sms IS 'Has Received Warning Stock Sms';


--
-- Name: COLUMN res_company.days_to_purchase; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.days_to_purchase IS 'Days to Purchase';


--
-- Name: COLUMN res_company.quotation_validity_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.quotation_validity_days IS 'Default Quotation Validity';


--
-- Name: COLUMN res_company.sale_discount_product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.sale_discount_product_id IS 'Discount Product';


--
-- Name: COLUMN res_company.downpayment_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.downpayment_account_id IS 'Downpayment Account';


--
-- Name: COLUMN res_company.sale_onboarding_payment_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.sale_onboarding_payment_method IS 'Sale onboarding selected payment method';


--
-- Name: COLUMN res_company.portal_confirmation_sign; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.portal_confirmation_sign IS 'Online Signature';


--
-- Name: COLUMN res_company.portal_confirmation_pay; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.portal_confirmation_pay IS 'Online Payment';


--
-- Name: COLUMN res_company.prepayment_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.prepayment_percent IS 'Prepayment percentage';


--
-- Name: COLUMN res_company.sale_order_template_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.sale_order_template_id IS 'Default Sale Template';


--
-- Name: COLUMN res_company.security_lead; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_company.security_lead IS 'Sales Safety Days';


--
-- Name: CONSTRAINT res_company_check_quotation_validity_days ON res_company; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT res_company_check_quotation_validity_days ON public.res_company IS 'CHECK(quotation_validity_days >= 0)';


--
-- Name: res_company_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.res_company_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.res_company_id_seq OWNED BY public.res_company.id;


--
-- Name: res_partner; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_partner (
    id integer NOT NULL,
    company_id integer,
    create_date timestamp without time zone,
    name character varying,
    parent_id integer,
    user_id integer,
    state_id integer,
    country_id integer,
    industry_id integer,
    color integer,
    commercial_partner_id integer,
    create_uid integer,
    write_uid integer,
    complete_name character varying,
    ref character varying,
    lang character varying,
    tz character varying,
    vat character varying,
    company_registry character varying,
    website character varying,
    function character varying,
    type character varying,
    street character varying,
    street2 character varying,
    zip character varying,
    city character varying,
    email character varying,
    phone character varying,
    commercial_company_name character varying,
    company_name character varying,
    properties jsonb,
    barcode jsonb,
    comment text,
    partner_latitude numeric,
    partner_longitude numeric,
    active boolean,
    employee boolean,
    is_company boolean,
    partner_share boolean,
    write_date timestamp without time zone,
    message_bounce integer,
    email_normalized character varying,
    signup_type character varying,
    phone_sanitized character varying,
    specific_property_product_pricelist jsonb,
    invoice_template_pdf_report_id integer,
    supplier_rank integer,
    customer_rank integer,
    autopost_bills character varying NOT NULL,
    credit_limit jsonb,
    property_account_payable_id jsonb,
    property_account_receivable_id jsonb,
    property_account_position_id jsonb,
    property_payment_term_id jsonb,
    property_supplier_payment_term_id jsonb,
    trust jsonb,
    ignore_abnormal_invoice_date jsonb,
    ignore_abnormal_invoice_amount jsonb,
    invoice_sending_method jsonb,
    invoice_edi_format_store jsonb,
    property_outbound_payment_method_line_id jsonb,
    property_inbound_payment_method_line_id jsonb,
    property_stock_customer jsonb,
    property_stock_supplier jsonb,
    picking_warn_msg text,
    global_location_number character varying,
    peppol_endpoint character varying,
    peppol_eas character varying,
    buyer_id integer,
    property_purchase_currency_id jsonb,
    receipt_reminder_email jsonb,
    reminder_date_before_receipt jsonb,
    purchase_warn_msg text,
    suggest_days integer,
    suggest_percent integer,
    suggest_based_on character varying,
    group_rfq character varying NOT NULL,
    group_on character varying NOT NULL,
    sale_warn_msg text,
    CONSTRAINT res_partner_check_name CHECK (((((type)::text = 'contact'::text) AND (name IS NOT NULL)) OR ((type)::text <> 'contact'::text)))
);


--
-- Name: COLUMN res_partner.parent_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.parent_id IS 'Related Company';


--
-- Name: COLUMN res_partner.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.user_id IS 'Salesperson';


--
-- Name: COLUMN res_partner.state_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.state_id IS 'State';


--
-- Name: COLUMN res_partner.country_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.country_id IS 'Country';


--
-- Name: COLUMN res_partner.industry_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.industry_id IS 'Industry';


--
-- Name: COLUMN res_partner.color; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.color IS 'Color Index';


--
-- Name: COLUMN res_partner.commercial_partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.commercial_partner_id IS 'Commercial Entity';


--
-- Name: COLUMN res_partner.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.create_uid IS 'Created by';


--
-- Name: COLUMN res_partner.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.write_uid IS 'Last Updated by';


--
-- Name: COLUMN res_partner.complete_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.complete_name IS 'Complete Name';


--
-- Name: COLUMN res_partner.ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.ref IS 'Reference';


--
-- Name: COLUMN res_partner.lang; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.lang IS 'Language';


--
-- Name: COLUMN res_partner.tz; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.tz IS 'Timezone';


--
-- Name: COLUMN res_partner.vat; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.vat IS 'Tax ID';


--
-- Name: COLUMN res_partner.company_registry; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.company_registry IS 'Company ID';


--
-- Name: COLUMN res_partner.website; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.website IS 'Website Link';


--
-- Name: COLUMN res_partner.function; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.function IS 'Job Position';


--
-- Name: COLUMN res_partner.type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.type IS 'Address Type';


--
-- Name: COLUMN res_partner.street; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.street IS 'Street';


--
-- Name: COLUMN res_partner.street2; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.street2 IS 'Street2';


--
-- Name: COLUMN res_partner.zip; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.zip IS 'Zip';


--
-- Name: COLUMN res_partner.city; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.city IS 'City';


--
-- Name: COLUMN res_partner.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.email IS 'Email';


--
-- Name: COLUMN res_partner.phone; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.phone IS 'Phone';


--
-- Name: COLUMN res_partner.commercial_company_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.commercial_company_name IS 'Company Name Entity';


--
-- Name: COLUMN res_partner.company_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.company_name IS 'Company Name';


--
-- Name: COLUMN res_partner.properties; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.properties IS 'Properties';


--
-- Name: COLUMN res_partner.barcode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.barcode IS 'Barcode';


--
-- Name: COLUMN res_partner.comment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.comment IS 'Notes';


--
-- Name: COLUMN res_partner.partner_latitude; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.partner_latitude IS 'Geo Latitude';


--
-- Name: COLUMN res_partner.partner_longitude; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.partner_longitude IS 'Geo Longitude';


--
-- Name: COLUMN res_partner.active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.active IS 'Active';


--
-- Name: COLUMN res_partner.employee; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.employee IS 'Employee';


--
-- Name: COLUMN res_partner.is_company; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.is_company IS 'Is a Company';


--
-- Name: COLUMN res_partner.partner_share; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.partner_share IS 'Share Partner';


--
-- Name: COLUMN res_partner.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.write_date IS 'Last Updated on';


--
-- Name: COLUMN res_partner.message_bounce; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.message_bounce IS 'Bounce';


--
-- Name: COLUMN res_partner.email_normalized; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.email_normalized IS 'Normalized Email';


--
-- Name: COLUMN res_partner.signup_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.signup_type IS 'Signup Token Type';


--
-- Name: COLUMN res_partner.phone_sanitized; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.phone_sanitized IS 'Sanitized Number';


--
-- Name: COLUMN res_partner.specific_property_product_pricelist; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.specific_property_product_pricelist IS 'Specific Property Product Pricelist';


--
-- Name: COLUMN res_partner.invoice_template_pdf_report_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.invoice_template_pdf_report_id IS 'Invoice report';


--
-- Name: COLUMN res_partner.supplier_rank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.supplier_rank IS 'Supplier Rank';


--
-- Name: COLUMN res_partner.customer_rank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.customer_rank IS 'Customer Rank';


--
-- Name: COLUMN res_partner.autopost_bills; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.autopost_bills IS 'Auto-post bills';


--
-- Name: COLUMN res_partner.credit_limit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.credit_limit IS 'Credit Limit';


--
-- Name: COLUMN res_partner.property_account_payable_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_account_payable_id IS 'Account Payable';


--
-- Name: COLUMN res_partner.property_account_receivable_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_account_receivable_id IS 'Account Receivable';


--
-- Name: COLUMN res_partner.property_account_position_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_account_position_id IS 'Fiscal Position';


--
-- Name: COLUMN res_partner.property_payment_term_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_payment_term_id IS 'Customer Payment Terms';


--
-- Name: COLUMN res_partner.property_supplier_payment_term_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_supplier_payment_term_id IS 'Vendor Payment Terms';


--
-- Name: COLUMN res_partner.trust; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.trust IS 'Degree of trust you have in this debtor';


--
-- Name: COLUMN res_partner.ignore_abnormal_invoice_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.ignore_abnormal_invoice_date IS 'Ignore Abnormal Invoice Date';


--
-- Name: COLUMN res_partner.ignore_abnormal_invoice_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.ignore_abnormal_invoice_amount IS 'Ignore Abnormal Invoice Amount';


--
-- Name: COLUMN res_partner.invoice_sending_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.invoice_sending_method IS 'Invoice sending';


--
-- Name: COLUMN res_partner.invoice_edi_format_store; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.invoice_edi_format_store IS 'Invoice Edi Format Store';


--
-- Name: COLUMN res_partner.property_outbound_payment_method_line_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_outbound_payment_method_line_id IS 'Property Outbound Payment Method Line';


--
-- Name: COLUMN res_partner.property_inbound_payment_method_line_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_inbound_payment_method_line_id IS 'Property Inbound Payment Method Line';


--
-- Name: COLUMN res_partner.property_stock_customer; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_stock_customer IS 'Customer Location';


--
-- Name: COLUMN res_partner.property_stock_supplier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_stock_supplier IS 'Vendor Location';


--
-- Name: COLUMN res_partner.picking_warn_msg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.picking_warn_msg IS 'Message for Stock Picking';


--
-- Name: COLUMN res_partner.global_location_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.global_location_number IS 'GLN';


--
-- Name: COLUMN res_partner.peppol_endpoint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.peppol_endpoint IS 'Peppol Endpoint';


--
-- Name: COLUMN res_partner.peppol_eas; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.peppol_eas IS 'Peppol e-address (EAS)';


--
-- Name: COLUMN res_partner.buyer_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.buyer_id IS 'Buyer';


--
-- Name: COLUMN res_partner.property_purchase_currency_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.property_purchase_currency_id IS 'Supplier Currency';


--
-- Name: COLUMN res_partner.receipt_reminder_email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.receipt_reminder_email IS 'Receipt Reminder';


--
-- Name: COLUMN res_partner.reminder_date_before_receipt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.reminder_date_before_receipt IS 'Days Before Receipt';


--
-- Name: COLUMN res_partner.purchase_warn_msg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.purchase_warn_msg IS 'Message for Purchase Order';


--
-- Name: COLUMN res_partner.suggest_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.suggest_days IS 'Suggest Days';


--
-- Name: COLUMN res_partner.suggest_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.suggest_percent IS 'Suggest Percent';


--
-- Name: COLUMN res_partner.suggest_based_on; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.suggest_based_on IS 'Suggest Based On';


--
-- Name: COLUMN res_partner.group_rfq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.group_rfq IS 'Group RFQ';


--
-- Name: COLUMN res_partner.group_on; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.group_on IS 'Week Day';


--
-- Name: COLUMN res_partner.sale_warn_msg; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.res_partner.sale_warn_msg IS 'Message for Sales Order';


--
-- Name: CONSTRAINT res_partner_check_name ON res_partner; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT res_partner_check_name ON public.res_partner IS 'CHECK( (type=''contact'' AND name IS NOT NULL) or (type!=''contact'') )';


--
-- Name: res_partner_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.res_partner_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: res_partner_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.res_partner_id_seq OWNED BY public.res_partner.id;


--
-- Name: res_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.res_users (
    id integer,
    partner_id integer,
    company_id integer,
    active boolean,
    share boolean
);


--
-- Name: sale_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order (
    id integer NOT NULL,
    campaign_id integer,
    source_id integer,
    medium_id integer,
    company_id integer NOT NULL,
    partner_id integer NOT NULL,
    pending_email_template_id integer,
    journal_id integer,
    partner_invoice_id integer NOT NULL,
    partner_shipping_id integer NOT NULL,
    fiscal_position_id integer,
    payment_term_id integer,
    preferred_payment_method_line_id integer,
    pricelist_id integer,
    currency_id integer,
    user_id integer,
    team_id integer,
    create_uid integer,
    write_uid integer,
    access_token character varying,
    name character varying NOT NULL,
    state character varying,
    client_order_ref character varying,
    origin character varying,
    reference character varying,
    signed_by character varying,
    invoice_status character varying,
    validity_date date,
    note text,
    currency_rate numeric,
    amount_untaxed numeric,
    amount_tax numeric,
    amount_total numeric,
    locked boolean,
    require_signature boolean,
    require_payment boolean,
    create_date timestamp without time zone,
    commitment_date timestamp without time zone,
    date_order timestamp without time zone NOT NULL,
    signed_on timestamp without time zone,
    write_date timestamp without time zone,
    prepayment_percent double precision,
    sale_order_template_id integer,
    incoterm integer,
    warehouse_id integer,
    incoterm_location character varying,
    picking_policy character varying NOT NULL,
    delivery_status character varying,
    effective_date timestamp without time zone,
    customizable_pdf_form_fields jsonb,
    CONSTRAINT sale_order_date_order_conditional_required CHECK (((((state)::text = 'sale'::text) AND (date_order IS NOT NULL)) OR ((state)::text <> 'sale'::text)))
);


--
-- Name: TABLE sale_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sale_order IS 'Sales Order';


--
-- Name: COLUMN sale_order.campaign_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.campaign_id IS 'Campaign';


--
-- Name: COLUMN sale_order.source_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.source_id IS 'Source';


--
-- Name: COLUMN sale_order.medium_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.medium_id IS 'Medium';


--
-- Name: COLUMN sale_order.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.company_id IS 'Company';


--
-- Name: COLUMN sale_order.partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.partner_id IS 'Customer';


--
-- Name: COLUMN sale_order.pending_email_template_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.pending_email_template_id IS 'Pending Email Template';


--
-- Name: COLUMN sale_order.journal_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.journal_id IS 'Invoicing Journal';


--
-- Name: COLUMN sale_order.partner_invoice_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.partner_invoice_id IS 'Invoice Address';


--
-- Name: COLUMN sale_order.partner_shipping_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.partner_shipping_id IS 'Delivery Address';


--
-- Name: COLUMN sale_order.fiscal_position_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.fiscal_position_id IS 'Fiscal Position';


--
-- Name: COLUMN sale_order.payment_term_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.payment_term_id IS 'Payment Terms';


--
-- Name: COLUMN sale_order.preferred_payment_method_line_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.preferred_payment_method_line_id IS 'Payment Method';


--
-- Name: COLUMN sale_order.pricelist_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.pricelist_id IS 'Pricelist';


--
-- Name: COLUMN sale_order.currency_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.currency_id IS 'Currency';


--
-- Name: COLUMN sale_order.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.user_id IS 'Salesperson';


--
-- Name: COLUMN sale_order.team_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.team_id IS 'Sales Team';


--
-- Name: COLUMN sale_order.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.create_uid IS 'Created by';


--
-- Name: COLUMN sale_order.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.write_uid IS 'Last Updated by';


--
-- Name: COLUMN sale_order.access_token; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.access_token IS 'Security Token';


--
-- Name: COLUMN sale_order.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.name IS 'Order Reference';


--
-- Name: COLUMN sale_order.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.state IS 'Status';


--
-- Name: COLUMN sale_order.client_order_ref; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.client_order_ref IS 'Customer Reference';


--
-- Name: COLUMN sale_order.origin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.origin IS 'Source Document';


--
-- Name: COLUMN sale_order.reference; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.reference IS 'Payment Ref.';


--
-- Name: COLUMN sale_order.signed_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.signed_by IS 'Signed By';


--
-- Name: COLUMN sale_order.invoice_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.invoice_status IS 'Invoice Status';


--
-- Name: COLUMN sale_order.validity_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.validity_date IS 'Expiration';


--
-- Name: COLUMN sale_order.note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.note IS 'Terms and conditions';


--
-- Name: COLUMN sale_order.currency_rate; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.currency_rate IS 'Currency Rate';


--
-- Name: COLUMN sale_order.amount_untaxed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.amount_untaxed IS 'Untaxed Amount';


--
-- Name: COLUMN sale_order.amount_tax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.amount_tax IS 'Taxes';


--
-- Name: COLUMN sale_order.amount_total; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.amount_total IS 'Total';


--
-- Name: COLUMN sale_order.locked; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.locked IS 'Locked';


--
-- Name: COLUMN sale_order.require_signature; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.require_signature IS 'Online signature';


--
-- Name: COLUMN sale_order.require_payment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.require_payment IS 'Online payment';


--
-- Name: COLUMN sale_order.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.create_date IS 'Creation Date';


--
-- Name: COLUMN sale_order.commitment_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.commitment_date IS 'Delivery Date';


--
-- Name: COLUMN sale_order.date_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.date_order IS 'Order Date';


--
-- Name: COLUMN sale_order.signed_on; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.signed_on IS 'Signed On';


--
-- Name: COLUMN sale_order.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.write_date IS 'Last Updated on';


--
-- Name: COLUMN sale_order.prepayment_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.prepayment_percent IS 'Prepayment percentage';


--
-- Name: COLUMN sale_order.incoterm; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.incoterm IS 'Incoterm';


--
-- Name: COLUMN sale_order.warehouse_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.warehouse_id IS 'Warehouse';


--
-- Name: COLUMN sale_order.incoterm_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.incoterm_location IS 'Incoterm Location';


--
-- Name: COLUMN sale_order.picking_policy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.picking_policy IS 'Shipping Policy';


--
-- Name: COLUMN sale_order.delivery_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.delivery_status IS 'Delivery Status';


--
-- Name: COLUMN sale_order.effective_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.effective_date IS 'Effective Date';


--
-- Name: COLUMN sale_order.customizable_pdf_form_fields; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order.customizable_pdf_form_fields IS 'Customizable PDF Form Fields';


--
-- Name: CONSTRAINT sale_order_date_order_conditional_required ON sale_order; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT sale_order_date_order_conditional_required ON public.sale_order IS 'CHECK((state = ''sale'' AND date_order IS NOT NULL) OR state != ''sale'')';


--
-- Name: sale_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_id_seq OWNED BY public.sale_order.id;


--
-- Name: sale_order_line; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_order_line (
    id integer NOT NULL,
    order_id integer NOT NULL,
    sequence integer,
    company_id integer,
    currency_id integer,
    order_partner_id integer,
    salesman_id integer,
    product_id integer,
    product_uom_id integer,
    linked_line_id integer,
    combo_item_id integer,
    create_uid integer,
    write_uid integer,
    state character varying,
    display_type character varying,
    virtual_id character varying,
    linked_virtual_id character varying,
    qty_delivered_method character varying,
    invoice_status character varying,
    analytic_distribution jsonb,
    extra_tax_data jsonb,
    name text NOT NULL,
    product_uom_qty numeric NOT NULL,
    price_unit numeric NOT NULL,
    discount numeric,
    price_subtotal numeric,
    price_total numeric,
    price_reduce_taxexcl numeric,
    price_reduce_taxinc numeric,
    qty_delivered numeric,
    qty_invoiced numeric,
    qty_to_invoice numeric,
    untaxed_amount_invoiced numeric,
    untaxed_amount_to_invoice numeric,
    is_downpayment boolean,
    is_expense boolean,
    collapse_prices boolean,
    collapse_composition boolean,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    technical_price_unit double precision,
    price_tax double precision,
    customer_lead double precision NOT NULL,
    is_optional boolean,
    warehouse_id integer,
    CONSTRAINT sale_order_line_accountable_required_fields CHECK (((display_type IS NOT NULL) OR is_downpayment OR ((product_id IS NOT NULL) AND (product_uom_id IS NOT NULL)))),
    CONSTRAINT sale_order_line_non_accountable_null_fields CHECK (((display_type IS NULL) OR ((product_id IS NULL) AND (price_unit = (0)::numeric) AND (product_uom_qty = (0)::numeric) AND (product_uom_id IS NULL) AND (customer_lead = (0)::double precision))))
);


--
-- Name: TABLE sale_order_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sale_order_line IS 'Sales Order Line';


--
-- Name: COLUMN sale_order_line.order_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.order_id IS 'Order Reference';


--
-- Name: COLUMN sale_order_line.sequence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.sequence IS 'Sequence';


--
-- Name: COLUMN sale_order_line.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.company_id IS 'Company';


--
-- Name: COLUMN sale_order_line.currency_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.currency_id IS 'Currency';


--
-- Name: COLUMN sale_order_line.order_partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.order_partner_id IS 'Customer';


--
-- Name: COLUMN sale_order_line.salesman_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.salesman_id IS 'Salesperson';


--
-- Name: COLUMN sale_order_line.product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.product_id IS 'Product';


--
-- Name: COLUMN sale_order_line.product_uom_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.product_uom_id IS 'Unit';


--
-- Name: COLUMN sale_order_line.linked_line_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.linked_line_id IS 'Linked Order Line';


--
-- Name: COLUMN sale_order_line.combo_item_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.combo_item_id IS 'Combo Item';


--
-- Name: COLUMN sale_order_line.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.create_uid IS 'Created by';


--
-- Name: COLUMN sale_order_line.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.write_uid IS 'Last Updated by';


--
-- Name: COLUMN sale_order_line.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.state IS 'Order Status';


--
-- Name: COLUMN sale_order_line.display_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.display_type IS 'Display Type';


--
-- Name: COLUMN sale_order_line.virtual_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.virtual_id IS 'Virtual';


--
-- Name: COLUMN sale_order_line.linked_virtual_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.linked_virtual_id IS 'Linked Virtual';


--
-- Name: COLUMN sale_order_line.qty_delivered_method; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.qty_delivered_method IS 'Method to update delivered qty';


--
-- Name: COLUMN sale_order_line.invoice_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.invoice_status IS 'Invoice Status';


--
-- Name: COLUMN sale_order_line.analytic_distribution; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.analytic_distribution IS 'Analytic Distribution';


--
-- Name: COLUMN sale_order_line.extra_tax_data; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.extra_tax_data IS 'Extra Tax Data';


--
-- Name: COLUMN sale_order_line.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.name IS 'Description';


--
-- Name: COLUMN sale_order_line.product_uom_qty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.product_uom_qty IS 'Quantity';


--
-- Name: COLUMN sale_order_line.price_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.price_unit IS 'Unit Price';


--
-- Name: COLUMN sale_order_line.discount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.discount IS 'Discount (%)';


--
-- Name: COLUMN sale_order_line.price_subtotal; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.price_subtotal IS 'Subtotal';


--
-- Name: COLUMN sale_order_line.price_total; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.price_total IS 'Total';


--
-- Name: COLUMN sale_order_line.price_reduce_taxexcl; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.price_reduce_taxexcl IS 'Price Reduce Tax excl';


--
-- Name: COLUMN sale_order_line.price_reduce_taxinc; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.price_reduce_taxinc IS 'Price Reduce Tax incl';


--
-- Name: COLUMN sale_order_line.qty_delivered; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.qty_delivered IS 'Delivery Quantity';


--
-- Name: COLUMN sale_order_line.qty_invoiced; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.qty_invoiced IS 'Invoiced Quantity';


--
-- Name: COLUMN sale_order_line.qty_to_invoice; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.qty_to_invoice IS 'Quantity To Invoice';


--
-- Name: COLUMN sale_order_line.untaxed_amount_invoiced; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.untaxed_amount_invoiced IS 'Untaxed Invoiced Amount';


--
-- Name: COLUMN sale_order_line.untaxed_amount_to_invoice; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.untaxed_amount_to_invoice IS 'Untaxed Amount To Invoice';


--
-- Name: COLUMN sale_order_line.is_downpayment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.is_downpayment IS 'Is a down payment';


--
-- Name: COLUMN sale_order_line.is_expense; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.is_expense IS 'Is expense';


--
-- Name: COLUMN sale_order_line.collapse_prices; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.collapse_prices IS 'Collapse Prices';


--
-- Name: COLUMN sale_order_line.collapse_composition; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.collapse_composition IS 'Collapse Composition';


--
-- Name: COLUMN sale_order_line.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.create_date IS 'Created on';


--
-- Name: COLUMN sale_order_line.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.write_date IS 'Last Updated on';


--
-- Name: COLUMN sale_order_line.technical_price_unit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.technical_price_unit IS 'Technical Price Unit';


--
-- Name: COLUMN sale_order_line.price_tax; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.price_tax IS 'Total Tax';


--
-- Name: COLUMN sale_order_line.customer_lead; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.customer_lead IS 'Lead Time';


--
-- Name: COLUMN sale_order_line.is_optional; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.is_optional IS 'Optional Line';


--
-- Name: COLUMN sale_order_line.warehouse_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.sale_order_line.warehouse_id IS 'Warehouse';


--
-- Name: CONSTRAINT sale_order_line_accountable_required_fields ON sale_order_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT sale_order_line_accountable_required_fields ON public.sale_order_line IS 'CHECK(display_type IS NOT NULL OR is_downpayment OR (product_id IS NOT NULL AND product_uom_id IS NOT NULL))';


--
-- Name: CONSTRAINT sale_order_line_non_accountable_null_fields ON sale_order_line; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT sale_order_line_non_accountable_null_fields ON public.sale_order_line IS 'CHECK(display_type IS NULL OR (product_id IS NULL AND price_unit = 0 AND product_uom_qty = 0 AND product_uom_id IS NULL AND customer_lead = 0))';


--
-- Name: sale_order_line_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sale_order_line_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sale_order_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sale_order_line_id_seq OWNED BY public.sale_order_line.id;


--
-- Name: stock_location; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_location (
    id integer NOT NULL,
    location_id integer,
    company_id integer,
    removal_strategy_id integer,
    cyclic_inventory_frequency integer,
    warehouse_id integer,
    storage_category_id integer,
    create_uid integer,
    write_uid integer,
    name character varying NOT NULL,
    complete_name character varying,
    usage character varying NOT NULL,
    parent_path character varying,
    barcode character varying,
    last_inventory_date date,
    next_inventory_date date,
    active boolean,
    replenish_location boolean,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    valuation_account_id integer,
    CONSTRAINT stock_location_inventory_freq_nonneg CHECK ((cyclic_inventory_frequency >= 0))
);


--
-- Name: TABLE stock_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.stock_location IS 'Inventory Locations';


--
-- Name: COLUMN stock_location.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.location_id IS 'Parent Location';


--
-- Name: COLUMN stock_location.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.company_id IS 'Company';


--
-- Name: COLUMN stock_location.removal_strategy_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.removal_strategy_id IS 'Removal Strategy';


--
-- Name: COLUMN stock_location.cyclic_inventory_frequency; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.cyclic_inventory_frequency IS 'Inventory Frequency';


--
-- Name: COLUMN stock_location.warehouse_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.warehouse_id IS 'Warehouse';


--
-- Name: COLUMN stock_location.storage_category_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.storage_category_id IS 'Storage Category';


--
-- Name: COLUMN stock_location.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.create_uid IS 'Created by';


--
-- Name: COLUMN stock_location.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.write_uid IS 'Last Updated by';


--
-- Name: COLUMN stock_location.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.name IS 'Location Name';


--
-- Name: COLUMN stock_location.complete_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.complete_name IS 'Full Location Name';


--
-- Name: COLUMN stock_location.usage; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.usage IS 'Location Type';


--
-- Name: COLUMN stock_location.parent_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.parent_path IS 'Parent Path';


--
-- Name: COLUMN stock_location.barcode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.barcode IS 'Barcode';


--
-- Name: COLUMN stock_location.last_inventory_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.last_inventory_date IS 'Last Inventory';


--
-- Name: COLUMN stock_location.next_inventory_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.next_inventory_date IS 'Next Expected';


--
-- Name: COLUMN stock_location.active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.active IS 'Active';


--
-- Name: COLUMN stock_location.replenish_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.replenish_location IS 'Replenishments';


--
-- Name: COLUMN stock_location.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.create_date IS 'Created on';


--
-- Name: COLUMN stock_location.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.write_date IS 'Last Updated on';


--
-- Name: COLUMN stock_location.valuation_account_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_location.valuation_account_id IS 'Stock Valuation Account';


--
-- Name: CONSTRAINT stock_location_inventory_freq_nonneg ON stock_location; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT stock_location_inventory_freq_nonneg ON public.stock_location IS 'check(cyclic_inventory_frequency >= 0)';


--
-- Name: stock_location_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_location_id_seq OWNED BY public.stock_location.id;


--
-- Name: stock_picking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_picking (
    id integer NOT NULL,
    backorder_id integer,
    return_id integer,
    location_id integer NOT NULL,
    location_dest_id integer NOT NULL,
    picking_type_id integer NOT NULL,
    partner_id integer,
    company_id integer,
    user_id integer,
    owner_id integer,
    create_uid integer,
    write_uid integer,
    name character varying,
    origin character varying,
    move_type character varying NOT NULL,
    state character varying,
    priority character varying,
    picking_properties jsonb,
    note text,
    shipping_weight numeric,
    has_deadline_issue boolean,
    printed boolean,
    is_locked boolean,
    scheduled_date timestamp without time zone,
    date_deadline timestamp without time zone,
    date_done timestamp without time zone,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    sale_id integer
);


--
-- Name: TABLE stock_picking; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.stock_picking IS 'Transfer';


--
-- Name: COLUMN stock_picking.backorder_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.backorder_id IS 'Back Order of';


--
-- Name: COLUMN stock_picking.return_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.return_id IS 'Return of';


--
-- Name: COLUMN stock_picking.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.location_id IS 'Source Location';


--
-- Name: COLUMN stock_picking.location_dest_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.location_dest_id IS 'Destination Location';


--
-- Name: COLUMN stock_picking.picking_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.picking_type_id IS 'Operation Type';


--
-- Name: COLUMN stock_picking.partner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.partner_id IS 'Contact';


--
-- Name: COLUMN stock_picking.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.company_id IS 'Company';


--
-- Name: COLUMN stock_picking.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.user_id IS 'Responsible';


--
-- Name: COLUMN stock_picking.owner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.owner_id IS 'Assign Owner';


--
-- Name: COLUMN stock_picking.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.create_uid IS 'Created by';


--
-- Name: COLUMN stock_picking.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.write_uid IS 'Last Updated by';


--
-- Name: COLUMN stock_picking.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.name IS 'Reference';


--
-- Name: COLUMN stock_picking.origin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.origin IS 'Source Document';


--
-- Name: COLUMN stock_picking.move_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.move_type IS 'Shipping Policy';


--
-- Name: COLUMN stock_picking.state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.state IS 'Status';


--
-- Name: COLUMN stock_picking.priority; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.priority IS 'Priority';


--
-- Name: COLUMN stock_picking.picking_properties; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.picking_properties IS 'Properties';


--
-- Name: COLUMN stock_picking.note; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.note IS 'Notes';


--
-- Name: COLUMN stock_picking.shipping_weight; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.shipping_weight IS 'Weight for Shipping';


--
-- Name: COLUMN stock_picking.has_deadline_issue; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.has_deadline_issue IS 'Is late';


--
-- Name: COLUMN stock_picking.printed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.printed IS 'Printed';


--
-- Name: COLUMN stock_picking.is_locked; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.is_locked IS 'Is Locked';


--
-- Name: COLUMN stock_picking.scheduled_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.scheduled_date IS 'Scheduled Date';


--
-- Name: COLUMN stock_picking.date_deadline; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.date_deadline IS 'Deadline';


--
-- Name: COLUMN stock_picking.date_done; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.date_done IS 'Date of Transfer';


--
-- Name: COLUMN stock_picking.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.create_date IS 'Created on';


--
-- Name: COLUMN stock_picking.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_picking.write_date IS 'Last Updated on';


--
-- Name: stock_picking_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_picking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_picking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_picking_id_seq OWNED BY public.stock_picking.id;


--
-- Name: stock_quant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_quant (
    id integer NOT NULL,
    product_id integer NOT NULL,
    company_id integer,
    location_id integer NOT NULL,
    lot_id integer,
    package_id integer,
    owner_id integer,
    user_id integer,
    create_uid integer,
    write_uid integer,
    inventory_date date,
    quantity numeric,
    reserved_quantity numeric NOT NULL,
    inventory_quantity numeric,
    inventory_diff_quantity numeric,
    inventory_quantity_set boolean,
    in_date timestamp without time zone NOT NULL,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    accounting_date date
);


--
-- Name: TABLE stock_quant; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.stock_quant IS 'Quants';


--
-- Name: COLUMN stock_quant.product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.product_id IS 'Product';


--
-- Name: COLUMN stock_quant.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.company_id IS 'Company';


--
-- Name: COLUMN stock_quant.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.location_id IS 'Location';


--
-- Name: COLUMN stock_quant.lot_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.lot_id IS 'Lot/Serial Number';


--
-- Name: COLUMN stock_quant.package_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.package_id IS 'Package';


--
-- Name: COLUMN stock_quant.owner_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.owner_id IS 'Owner';


--
-- Name: COLUMN stock_quant.user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.user_id IS 'Assigned To';


--
-- Name: COLUMN stock_quant.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.create_uid IS 'Created by';


--
-- Name: COLUMN stock_quant.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.write_uid IS 'Last Updated by';


--
-- Name: COLUMN stock_quant.inventory_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.inventory_date IS 'Scheduled';


--
-- Name: COLUMN stock_quant.quantity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.quantity IS 'Quantity';


--
-- Name: COLUMN stock_quant.reserved_quantity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.reserved_quantity IS 'Reserved Quantity';


--
-- Name: COLUMN stock_quant.inventory_quantity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.inventory_quantity IS 'Counted';


--
-- Name: COLUMN stock_quant.inventory_diff_quantity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.inventory_diff_quantity IS 'Difference';


--
-- Name: COLUMN stock_quant.inventory_quantity_set; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.inventory_quantity_set IS 'Inventory Quantity Set';


--
-- Name: COLUMN stock_quant.in_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.in_date IS 'Incoming Date';


--
-- Name: COLUMN stock_quant.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.create_date IS 'Created on';


--
-- Name: COLUMN stock_quant.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.write_date IS 'Last Updated on';


--
-- Name: COLUMN stock_quant.accounting_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_quant.accounting_date IS 'Accounting Date';


--
-- Name: stock_quant_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_quant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_quant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_quant_id_seq OWNED BY public.stock_quant.id;


--
-- Name: stock_warehouse_orderpoint; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_warehouse_orderpoint (
    id integer NOT NULL,
    warehouse_id integer NOT NULL,
    location_id integer NOT NULL,
    product_id integer NOT NULL,
    replenishment_uom_id integer,
    company_id integer NOT NULL,
    route_id integer,
    create_uid integer,
    write_uid integer,
    name character varying NOT NULL,
    trigger character varying NOT NULL,
    snoozed_until date,
    deadline_date date,
    product_min_qty numeric NOT NULL,
    product_max_qty numeric NOT NULL,
    qty_to_order_computed numeric,
    qty_to_order_manual numeric,
    active boolean,
    create_date timestamp without time zone,
    write_date timestamp without time zone,
    supplier_id integer
);


--
-- Name: TABLE stock_warehouse_orderpoint; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.stock_warehouse_orderpoint IS 'Minimum Inventory Rule';


--
-- Name: COLUMN stock_warehouse_orderpoint.warehouse_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.warehouse_id IS 'Warehouse';


--
-- Name: COLUMN stock_warehouse_orderpoint.location_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.location_id IS 'Location';


--
-- Name: COLUMN stock_warehouse_orderpoint.product_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.product_id IS 'Product';


--
-- Name: COLUMN stock_warehouse_orderpoint.replenishment_uom_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.replenishment_uom_id IS 'Multiple';


--
-- Name: COLUMN stock_warehouse_orderpoint.company_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.company_id IS 'Company';


--
-- Name: COLUMN stock_warehouse_orderpoint.route_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.route_id IS 'Route';


--
-- Name: COLUMN stock_warehouse_orderpoint.create_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.create_uid IS 'Created by';


--
-- Name: COLUMN stock_warehouse_orderpoint.write_uid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.write_uid IS 'Last Updated by';


--
-- Name: COLUMN stock_warehouse_orderpoint.name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.name IS 'Name';


--
-- Name: COLUMN stock_warehouse_orderpoint.trigger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.trigger IS 'Trigger';


--
-- Name: COLUMN stock_warehouse_orderpoint.snoozed_until; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.snoozed_until IS 'Snoozed';


--
-- Name: COLUMN stock_warehouse_orderpoint.deadline_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.deadline_date IS 'Deadline';


--
-- Name: COLUMN stock_warehouse_orderpoint.product_min_qty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.product_min_qty IS 'Min Quantity';


--
-- Name: COLUMN stock_warehouse_orderpoint.product_max_qty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.product_max_qty IS 'Max Quantity';


--
-- Name: COLUMN stock_warehouse_orderpoint.qty_to_order_computed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.qty_to_order_computed IS 'To Order Computed';


--
-- Name: COLUMN stock_warehouse_orderpoint.qty_to_order_manual; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.qty_to_order_manual IS 'To Order Manual';


--
-- Name: COLUMN stock_warehouse_orderpoint.active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.active IS 'Active';


--
-- Name: COLUMN stock_warehouse_orderpoint.create_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.create_date IS 'Created on';


--
-- Name: COLUMN stock_warehouse_orderpoint.write_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.write_date IS 'Last Updated on';


--
-- Name: COLUMN stock_warehouse_orderpoint.supplier_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.stock_warehouse_orderpoint.supplier_id IS 'Vendor Pricelist';


--
-- Name: stock_warehouse_orderpoint_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_warehouse_orderpoint_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_warehouse_orderpoint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_warehouse_orderpoint_id_seq OWNED BY public.stock_warehouse_orderpoint.id;


--
-- Name: account_move id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_move ALTER COLUMN id SET DEFAULT nextval('public.account_move_id_seq'::regclass);


--
-- Name: product_product id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_product ALTER COLUMN id SET DEFAULT nextval('public.product_product_id_seq'::regclass);


--
-- Name: product_template id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.product_template ALTER COLUMN id SET DEFAULT nextval('public.product_template_id_seq'::regclass);


--
-- Name: purchase_order id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order ALTER COLUMN id SET DEFAULT nextval('public.purchase_order_id_seq'::regclass);


--
-- Name: purchase_order_line id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_line ALTER COLUMN id SET DEFAULT nextval('public.purchase_order_line_id_seq'::regclass);


--
-- Name: res_company id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_company ALTER COLUMN id SET DEFAULT nextval('public.res_company_id_seq'::regclass);


--
-- Name: res_partner id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.res_partner ALTER COLUMN id SET DEFAULT nextval('public.res_partner_id_seq'::regclass);


--
-- Name: sale_order id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order ALTER COLUMN id SET DEFAULT nextval('public.sale_order_id_seq'::regclass);


--
-- Name: sale_order_line id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_order_line ALTER COLUMN id SET DEFAULT nextval('public.sale_order_line_id_seq'::regclass);


--
-- Name: stock_location id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_location ALTER COLUMN id SET DEFAULT nextval('public.stock_location_id_seq'::regclass);


--
-- Name: stock_picking id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_picking ALTER COLUMN id SET DEFAULT nextval('public.stock_picking_id_seq'::regclass);


--
-- Name: stock_quant id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_quant ALTER COLUMN id SET DEFAULT nextval('public.stock_quant_id_seq'::regclass);


--
-- Name: stock_warehouse_orderpoint id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_warehouse_orderpoint ALTER COLUMN id SET DEFAULT nextval('public.stock_warehouse_orderpoint_id_seq'::regclass);


--
-- Data for Name: account_move; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_move (id, sequence_number, message_main_attachment_id, journal_id, company_id, origin_payment_id, statement_line_id, tax_cash_basis_rec_id, tax_cash_basis_origin_move_id, auto_post_origin_id, secure_sequence_number, invoice_payment_term_id, partner_id, commercial_partner_id, partner_shipping_id, partner_bank_id, fiscal_position_id, preferred_payment_method_line_id, currency_id, reversed_entry_id, invoice_user_id, invoice_incoterm_id, invoice_cash_rounding_id, create_uid, write_uid, sequence_prefix, access_token, name, ref, state, move_type, auto_post, inalterable_hash, payment_reference, qr_code_method, payment_state, invoice_source_email, invoice_partner_display_name, invoice_origin, incoterm_location, date, auto_post_until, invoice_date, invoice_date_due, delivery_date, taxable_supply_date, sending_data, narration, invoice_currency_rate, amount_untaxed, amount_tax, amount_total, amount_residual, amount_untaxed_signed, amount_untaxed_in_currency_signed, amount_tax_signed, amount_total_signed, amount_total_in_currency_signed, amount_residual_signed, quick_edit_total_amount, always_tax_exigible, checked, posted_before, made_sequence_gap, is_manually_modified, is_move_sent, create_date, write_date, campaign_id, source_id, medium_id, team_id) FROM stdin;
19	1	\N	6	1	\N	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00001	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-09-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	850.00	0.00	0.00	0.00	0.00	850.00	850.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
22	2	\N	6	1	\N	4	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00002	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-09-24	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	2000.00	0.00	0.00	0.00	0.00	2000.00	2000.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
20	3	\N	6	1	\N	2	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00003	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-10-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	850.00	0.00	0.00	0.00	0.00	850.00	850.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
21	4	\N	6	1	\N	3	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00004	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-10-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	1275.00	0.00	0.00	0.00	0.00	1275.00	1275.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
24	6	\N	6	1	\N	6	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00006	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	850.00	0.00	0.00	0.00	0.00	850.00	850.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
25	7	\N	6	1	\N	7	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00007	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	650.00	0.00	0.00	0.00	0.00	650.00	650.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
26	8	\N	6	1	\N	8	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00008	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	102.78	0.00	0.00	0.00	0.00	102.78	102.78	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
28	10	\N	6	1	\N	10	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00010	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	96.67	0.00	0.00	0.00	0.00	96.67	96.67	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
23	5	\N	6	1	\N	5	\N	\N	\N	\N	\N	10	10	\N	\N	2	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00005	\N	posted	entry	no	\N	\N	\N	not_paid	\N	Gemini Furniture	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	622.27	0.00	0.00	0.00	0.00	622.27	622.27	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
27	9	\N	6	1	\N	9	\N	\N	\N	\N	\N	13	13	\N	\N	2	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00009	\N	posted	entry	no	\N	\N	\N	not_paid	\N	LightsUp	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	738.75	0.00	0.00	0.00	0.00	738.75	738.75	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
2	2	\N	1	1	\N	\N	\N	\N	\N	\N	\N	9	9	9	\N	1	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00002	\N	posted	out_invoice	no	\N	INV/2026/00002	\N	not_paid	\N	Acme Corporation	\N	\N	2026-11-01	\N	2026-11-01	2026-11-03	2026-11-01	\N	\N	\N	1.0	41750.00	4500.00	46250.00	46250.00	41750.00	41750.00	4500.00	46250.00	46250.00	46250.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:37.287963	\N	\N	\N	1
3	3	\N	1	1	\N	\N	\N	\N	\N	\N	\N	9	9	9	\N	1	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00003	\N	posted	out_invoice	no	\N	INV/2026/00003	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-31	\N	2026-10-31	2026-11-03	2026-10-31	\N	\N	\N	1.0	19250.00	1125.00	20375.00	20375.00	19250.00	19250.00	1125.00	20375.00	20375.00	20375.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:37.287963	\N	\N	\N	1
8	1	889	2	1	\N	\N	\N	\N	\N	\N	6	11	11	11	\N	1	\N	1	\N	\N	\N	\N	1	1	BILL/2026/11/	\N	BILL/2026/11/0001	\N	posted	in_invoice	no	\N	\N	\N	not_paid	\N	Ready Mat	\N	\N	2026-11-03	\N	2026-11-01	2026-12-31	2026-11-01	\N	\N	\N	1.0	30.00	0.00	30.00	30.00	-30.00	-30.00	0.00	-30.00	-30.00	-30.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
9	1	890	2	1	\N	\N	\N	\N	\N	\N	\N	10	10	10	\N	2	\N	1	\N	\N	\N	\N	1	1	BILL/2026/10/	\N	BILL/2026/10/0001	INV/2026/0057	posted	in_invoice	no	\N	\N	\N	not_paid	\N	Gemini Furniture	\N	\N	2026-10-31	\N	2026-10-14	2026-11-03	2026-10-14	\N	\N	\N	1.0	622.27	0.00	622.27	622.27	-622.27	-622.27	0.00	-622.27	-622.27	-622.27	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
14	1	889	2	1	\N	\N	\N	\N	\N	\N	\N	11	11	11	\N	1	\N	1	\N	\N	\N	\N	1	1	RBILL/2026/11/	\N	RBILL/2026/11/0001	\N	posted	in_refund	no	\N	\N	\N	not_paid	\N	Ready Mat	\N	\N	2026-11-03	\N	2026-11-01	2026-11-03	2026-11-01	\N	\N	\N	1.0	30.00	0.00	30.00	30.00	30.00	30.00	0.00	30.00	30.00	30.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
17	1	\N	3	1	\N	\N	\N	\N	\N	\N	\N	9	9	\N	\N	1	\N	1	\N	\N	\N	\N	1	1	MISC/2026/10/	\N	MISC/2026/10/0001	\N	posted	entry	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-14	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	2500.00	0.00	0.00	0.00	0.00	2500.00	2500.00	0.00	\N	t	t	t	\N	f	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
18	2	\N	3	1	\N	\N	\N	\N	\N	\N	\N	9	9	\N	\N	1	\N	1	\N	\N	\N	\N	1	1	MISC/2026/10/	\N	MISC/2026/10/0002	\N	posted	entry	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-14	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	2500.00	0.00	0.00	0.00	0.00	2500.00	2500.00	0.00	\N	t	t	t	\N	f	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:25.878704	\N	\N	\N	\N
10	8	\N	1	1	\N	\N	\N	\N	\N	\N	\N	13	13	13	\N	2	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00008	\N	posted	out_invoice	no	\N	INV/2026/00008	\N	not_paid	\N	LightsUp	\N	\N	2026-11-03	\N	2026-11-03	2026-11-03	2026-11-03	\N	\N	\N	1.0	750.00	0.00	750.00	750.00	750.00	750.00	0.00	750.00	750.00	750.00	\N	f	t	t	\N	f	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:37.287963	\N	\N	\N	1
11	9	\N	1	1	\N	\N	\N	\N	\N	\N	\N	12	12	12	\N	2	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00009	\N	posted	out_invoice	no	\N	INV/2026/00009	\N	not_paid	\N	OpenWood	\N	\N	2026-10-29	\N	2026-10-29	2026-11-03	2026-10-29	\N	\N	\N	1.0	1799.00	0.00	1799.00	1799.00	1799.00	1799.00	0.00	1799.00	1799.00	1799.00	\N	f	t	t	\N	f	\N	2026-11-03 11:48:25.878704	2026-11-03 11:48:37.287963	\N	\N	\N	1
47	1	\N	12	2	\N	11	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00001	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-09-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	850.00	0.00	0.00	0.00	0.00	850.00	850.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
50	2	\N	12	2	\N	14	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00002	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-09-24	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	2000.00	0.00	0.00	0.00	0.00	2000.00	2000.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
48	3	\N	12	2	\N	12	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00003	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-10-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	850.00	0.00	0.00	0.00	0.00	850.00	850.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
49	4	\N	12	2	\N	13	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00004	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-10-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	1275.00	0.00	0.00	0.00	0.00	1275.00	1275.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
52	6	\N	12	2	\N	16	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00006	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	850.00	0.00	0.00	0.00	0.00	850.00	850.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
53	7	\N	12	2	\N	17	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00007	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	650.00	0.00	0.00	0.00	0.00	650.00	650.00	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
54	8	\N	12	2	\N	18	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00008	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	102.78	0.00	0.00	0.00	0.00	102.78	102.78	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
56	10	\N	12	2	\N	20	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00010	\N	posted	entry	no	\N	\N	\N	not_paid	\N	#Created by: OdooBot	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	96.67	0.00	0.00	0.00	0.00	96.67	96.67	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
51	5	\N	12	2	\N	15	\N	\N	\N	\N	\N	10	10	\N	\N	4	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00005	\N	posted	entry	no	\N	\N	\N	not_paid	\N	Gemini Furniture	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	622.27	0.00	0.00	0.00	0.00	622.27	622.27	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
55	9	\N	12	2	\N	19	\N	\N	\N	\N	\N	13	13	\N	\N	4	\N	1	\N	\N	\N	\N	1	1	BNK1/2026/	\N	BNK1/2026/00009	\N	posted	entry	no	\N	\N	\N	not_paid	\N	LightsUp	\N	\N	2026-11-03	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	738.75	0.00	0.00	0.00	0.00	738.75	738.75	0.00	\N	t	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
30	2	\N	7	2	\N	\N	\N	\N	\N	\N	\N	9	9	9	2	3	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00002	\N	posted	out_invoice	no	\N	INV/2026/00002	\N	not_paid	\N	Acme Corporation	\N	\N	2026-11-01	\N	2026-11-01	2026-11-03	2026-11-01	\N	\N	\N	1.0	41750.00	1725.00	43475.00	43475.00	41750.00	41750.00	1725.00	43475.00	43475.00	43475.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:37.287963	\N	\N	\N	1
31	3	\N	7	2	\N	\N	\N	\N	\N	\N	\N	9	9	9	2	3	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00003	\N	posted	out_invoice	no	\N	INV/2026/00003	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-31	\N	2026-10-31	2026-11-03	2026-10-31	\N	\N	\N	1.0	19250.00	431.25	19681.25	19681.25	19250.00	19250.00	431.25	19681.25	19681.25	19681.25	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:37.287963	\N	\N	\N	1
36	1	910	8	2	\N	\N	\N	\N	\N	\N	6	11	11	11	\N	3	\N	1	\N	\N	\N	\N	1	1	BILL/2026/11/	\N	BILL/2026/11/0001	\N	posted	in_invoice	no	\N	\N	\N	not_paid	\N	Ready Mat	\N	\N	2026-11-03	\N	2026-11-01	2026-12-31	2026-11-01	\N	\N	\N	1.0	30.00	0.00	30.00	30.00	-30.00	-30.00	0.00	-30.00	-30.00	-30.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
37	1	911	8	2	\N	\N	\N	\N	\N	\N	\N	10	10	10	\N	4	\N	1	\N	\N	\N	\N	1	1	BILL/2026/10/	\N	BILL/2026/10/0001	INV/2026/0057	posted	in_invoice	no	\N	\N	\N	not_paid	\N	Gemini Furniture	\N	\N	2026-10-31	\N	2026-10-14	2026-11-03	2026-10-14	\N	\N	\N	1.0	622.27	0.00	622.27	622.27	-622.27	-622.27	0.00	-622.27	-622.27	-622.27	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
42	1	910	8	2	\N	\N	\N	\N	\N	\N	\N	11	11	11	2	3	\N	1	\N	\N	\N	\N	1	1	RBILL/2026/11/	\N	RBILL/2026/11/0001	\N	posted	in_refund	no	\N	\N	\N	not_paid	\N	Ready Mat	\N	\N	2026-11-03	\N	2026-11-01	2026-11-03	2026-11-01	\N	\N	\N	1.0	30.00	0.00	30.00	30.00	30.00	30.00	0.00	30.00	30.00	30.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
45	1	\N	9	2	\N	\N	\N	\N	\N	\N	\N	9	9	\N	\N	3	\N	1	\N	\N	\N	\N	1	1	MISC/2026/10/	\N	MISC/2026/10/0001	\N	posted	entry	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-14	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	2500.00	0.00	0.00	0.00	0.00	2500.00	2500.00	0.00	\N	t	t	t	\N	f	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
46	2	\N	9	2	\N	\N	\N	\N	\N	\N	\N	9	9	\N	\N	3	\N	1	\N	\N	\N	\N	1	1	MISC/2026/10/	\N	MISC/2026/10/0002	\N	posted	entry	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-14	\N	\N	2026-11-03	\N	\N	\N	\N	0.0	0.00	0.00	2500.00	0.00	0.00	0.00	0.00	2500.00	2500.00	0.00	\N	t	t	t	\N	f	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:32.831653	\N	\N	\N	\N
38	8	\N	7	2	\N	\N	\N	\N	\N	\N	\N	13	13	13	2	4	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00008	\N	posted	out_invoice	no	\N	INV/2026/00008	\N	not_paid	\N	LightsUp	\N	\N	2026-11-03	\N	2026-11-03	2026-11-03	2026-11-03	\N	\N	\N	1.0	750.00	0.00	750.00	750.00	750.00	750.00	0.00	750.00	750.00	750.00	\N	f	t	t	\N	f	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:37.287963	\N	\N	\N	1
39	9	\N	7	2	\N	\N	\N	\N	\N	\N	\N	12	12	12	2	4	\N	1	\N	\N	\N	\N	1	1	INV/2026/	\N	INV/2026/00009	\N	posted	out_invoice	no	\N	INV/2026/00009	\N	not_paid	\N	OpenWood	\N	\N	2026-10-29	\N	2026-10-29	2026-11-03	2026-10-29	\N	\N	\N	1.0	1799.00	0.00	1799.00	1799.00	1799.00	1799.00	0.00	1799.00	1799.00	1799.00	\N	f	t	t	\N	f	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:37.287963	\N	\N	\N	1
16	4	\N	1	1	\N	\N	\N	\N	\N	\N	\N	9	9	9	\N	1	\N	1	\N	5	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00004	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-11-01	\N	2026-11-01	2026-11-03	2026-11-01	\N	\N	\N	1.0	19250.00	1125.00	20375.00	20375.00	-19250.00	-19250.00	-1125.00	-20375.00	-20375.00	-20375.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	4
1	1	\N	1	1	\N	\N	\N	\N	\N	\N	6	15	15	15	\N	1	\N	1	\N	5	\N	\N	1	1	INV/2026/	\N	INV/2026/00001	\N	posted	out_invoice	no	\N	INV/2026/00001	\N	not_paid	\N	Azure Interior	\N	\N	2026-11-01	\N	2026-11-01	2026-12-31	2026-11-01	\N	\N	\N	1.0	31750.00	0.00	31750.00	31750.00	31750.00	31750.00	0.00	31750.00	31750.00	31750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	4
4	4	\N	1	1	\N	\N	\N	\N	\N	\N	1	9	9	9	\N	1	\N	1	\N	7	\N	\N	1	1	INV/2026/	\N	INV/2026/00004	\N	posted	out_invoice	no	\N	INV/2026/00004	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-19	\N	2026-10-19	2026-10-19	2026-10-19	\N	\N	\N	1.0	31750.00	0.00	31750.00	31750.00	31750.00	31750.00	0.00	31750.00	31750.00	31750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	1
5	5	\N	1	1	\N	\N	\N	\N	\N	\N	6	12	12	12	\N	2	\N	1	\N	8	\N	\N	1	1	INV/2026/	\N	INV/2026/00005	\N	posted	out_invoice	no	\N	INV/2026/00005	\N	not_paid	\N	OpenWood	\N	\N	2026-09-24	\N	2026-09-24	2026-10-31	2026-09-24	\N	\N	\N	1.0	2000.00	0.00	2000.00	2000.00	2000.00	2000.00	0.00	2000.00	2000.00	2000.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	1
7	7	\N	1	1	\N	\N	\N	\N	\N	\N	6	12	12	12	\N	2	\N	1	\N	5	\N	\N	1	1	INV/2026/	\N	INV/2026/00007	\N	posted	out_invoice	no	\N	INV/2026/00007	\N	not_paid	\N	OpenWood	\N	\N	2026-10-03	\N	2026-10-03	2026-11-30	2026-10-03	\N	\N	\N	1.0	275.00	0.00	275.00	275.00	275.00	275.00	0.00	275.00	275.00	275.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	4
12	1	\N	1	1	\N	\N	\N	\N	\N	\N	\N	15	15	15	\N	1	\N	1	\N	7	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00001	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Azure Interior	\N	\N	2026-10-02	\N	2026-10-02	2026-11-03	2026-10-02	\N	\N	\N	1.0	11750.00	0.00	11750.00	11750.00	-11750.00	-11750.00	0.00	-11750.00	-11750.00	-11750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	1
13	2	\N	1	1	\N	\N	\N	\N	\N	\N	\N	15	15	15	\N	1	\N	1	\N	8	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00002	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Azure Interior	\N	\N	2026-10-03	\N	2026-10-03	2026-11-03	2026-10-03	\N	\N	\N	1.0	20000.00	0.00	20000.00	20000.00	-20000.00	-20000.00	0.00	-20000.00	-20000.00	-20000.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	1
15	3	\N	1	1	\N	\N	\N	\N	\N	\N	\N	9	9	9	\N	1	\N	1	\N	9	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00003	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-24	\N	2026-10-24	2026-11-03	2026-10-24	\N	\N	\N	1.0	31750.00	0.00	31750.00	31750.00	-31750.00	-31750.00	0.00	-31750.00	-31750.00	-31750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	1
6	6	\N	1	1	\N	\N	\N	\N	\N	\N	6	12	12	12	\N	2	\N	1	\N	9	\N	\N	1	1	INV/2026/	\N	INV/2026/00006	\N	posted	out_invoice	no	\N	INV/2026/00006	\N	not_paid	\N	OpenWood	\N	\N	2026-09-29	\N	2026-09-29	2026-10-31	2026-09-29	\N	\N	\N	1.0	1000.00	0.00	1000.00	1000.00	1000.00	1000.00	0.00	1000.00	1000.00	1000.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:25.878704	2026-11-06 10:24:54.97385	\N	\N	\N	1
34	6	\N	7	2	\N	\N	\N	\N	\N	\N	6	12	12	12	2	4	\N	1	\N	5	\N	\N	1	1	INV/2026/	\N	INV/2026/00006	\N	posted	out_invoice	no	\N	INV/2026/00006	\N	not_paid	\N	OpenWood	\N	\N	2026-09-29	\N	2026-09-29	2026-10-31	2026-09-29	\N	\N	\N	1.0	1000.00	0.00	1000.00	1000.00	1000.00	1000.00	0.00	1000.00	1000.00	1000.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	4
29	1	\N	7	2	\N	\N	\N	\N	\N	\N	6	15	15	15	2	3	\N	1	\N	7	\N	\N	1	1	INV/2026/	\N	INV/2026/00001	\N	posted	out_invoice	no	\N	INV/2026/00001	\N	not_paid	\N	Azure Interior	\N	\N	2026-11-01	\N	2026-11-01	2026-12-31	2026-11-01	\N	\N	\N	1.0	31750.00	0.00	31750.00	31750.00	31750.00	31750.00	0.00	31750.00	31750.00	31750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	1
32	4	\N	7	2	\N	\N	\N	\N	\N	\N	1	9	9	9	2	3	\N	1	\N	8	\N	\N	1	1	INV/2026/	\N	INV/2026/00004	\N	posted	out_invoice	no	\N	INV/2026/00004	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-19	\N	2026-10-19	2026-10-19	2026-10-19	\N	\N	\N	1.0	31750.00	0.00	31750.00	31750.00	31750.00	31750.00	0.00	31750.00	31750.00	31750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	1
33	5	\N	7	2	\N	\N	\N	\N	\N	\N	6	12	12	12	2	4	\N	1	\N	9	\N	\N	1	1	INV/2026/	\N	INV/2026/00005	\N	posted	out_invoice	no	\N	INV/2026/00005	\N	not_paid	\N	OpenWood	\N	\N	2026-09-24	\N	2026-09-24	2026-10-31	2026-09-24	\N	\N	\N	1.0	2000.00	0.00	2000.00	2000.00	2000.00	2000.00	0.00	2000.00	2000.00	2000.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	1
35	7	\N	7	2	\N	\N	\N	\N	\N	\N	6	12	12	12	2	4	\N	1	\N	7	\N	\N	1	1	INV/2026/	\N	INV/2026/00007	\N	posted	out_invoice	no	\N	INV/2026/00007	\N	not_paid	\N	OpenWood	\N	\N	2026-10-03	\N	2026-10-03	2026-11-30	2026-10-03	\N	\N	\N	1.0	275.00	0.00	275.00	275.00	275.00	275.00	0.00	275.00	275.00	275.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	1
40	1	\N	7	2	\N	\N	\N	\N	\N	\N	\N	15	15	15	\N	3	\N	1	\N	8	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00001	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Azure Interior	\N	\N	2026-10-02	\N	2026-10-02	2026-11-03	2026-10-02	\N	\N	\N	1.0	11750.00	0.00	11750.00	11750.00	-11750.00	-11750.00	0.00	-11750.00	-11750.00	-11750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	1
41	2	\N	7	2	\N	\N	\N	\N	\N	\N	\N	15	15	15	\N	3	\N	1	\N	9	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00002	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Azure Interior	\N	\N	2026-10-03	\N	2026-10-03	2026-11-03	2026-10-03	\N	\N	\N	1.0	20000.00	0.00	20000.00	20000.00	-20000.00	-20000.00	0.00	-20000.00	-20000.00	-20000.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	1
44	4	\N	7	2	\N	\N	\N	\N	\N	\N	\N	9	9	9	\N	3	\N	1	\N	7	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00004	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-11-01	\N	2026-11-01	2026-11-03	2026-11-01	\N	\N	\N	1.0	19250.00	431.25	19681.25	19681.25	-19250.00	-19250.00	-431.25	-19681.25	-19681.25	-19681.25	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	1
43	3	\N	7	2	\N	\N	\N	\N	\N	\N	\N	9	9	9	\N	3	\N	1	\N	5	\N	\N	1	1	RINV/2026/	\N	RINV/2026/00003	\N	posted	out_refund	no	\N	\N	\N	not_paid	\N	Acme Corporation	\N	\N	2026-10-24	\N	2026-10-24	2026-11-03	2026-10-24	\N	\N	\N	1.0	31750.00	0.00	31750.00	31750.00	-31750.00	-31750.00	0.00	-31750.00	-31750.00	-31750.00	\N	f	t	t	\N	t	\N	2026-11-03 11:48:32.831653	2026-11-06 10:24:54.97385	\N	\N	\N	4
\.


--
-- Data for Name: product_product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_product (id, product_tmpl_id, create_uid, write_uid, default_code, barcode, combination_indices, standard_price, volume, weight, active, can_image_variant_1024_be_zoomed, is_favorite, is_in_selected_section_of_order, write_date, create_date, lot_properties_definition) FROM stdin;
1	1	1	1	\N	\N		{"1": 8.0}	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
2	2	1	1	\N	\N		{"1": 400.0}	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
3	3	1	1	\N	\N		{"1": 20.5}	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
4	4	1	1	\N	\N		{"1": 25.5}	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
7	7	1	1	FURN_9999	\N		{"1": 235.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
8	8	1	1	FURN_7800	\N		{"1": 300.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
20	11	1	1	E-COM07	\N		{"1": 800.0}	\N	0.33	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
21	12	1	1	E-COM08	\N		{"1": 14.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
23	13	1	1	\N	\N	10	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
24	13	1	1	\N	\N	11	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
25	13	1	1	\N	\N	12	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
27	15	1	1	E-COM11	\N		{"1": 120.5}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
5	5	1	1	FURN_7777	\N		{"1": 55.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
6	6	1	1	FURN_8888	40164785534112		{"1": 35.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
19	10	1	1	E-COM06	\N		{"1": 600.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
26	14	1	1	E-COM10	\N		{"1": 10.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
46	28	1	1	Delivery_010	\N		\N	\N	\N	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:19.323438	\N
47	29	1	1	\N	\N		{"1": 2500.0}	\N	\N	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:19.323438	\N
48	30	1	1	\N	\N		\N	\N	\N	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:19.323438	\N
52	34	1	1	\N	\N		\N	\N	\N	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:19.323438	\N
49	31	1	1	FURN_0001	2300001000008		\N	\N	0.01	t	f	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:19.323438	\N
50	32	1	1	FURN_0002	\N		\N	\N	0.01	t	f	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:19.323438	\N
51	33	1	1	FURN_0006	\N		\N	\N	0.01	t	f	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:19.323438	\N
31	17	1	1	FURN_0269	\N		{"1": 180.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
32	18	1	1	FURN_1118	\N		{"1": 78.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
33	19	1	1	FURN_8900	\N		{"1": 20.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
34	20	1	1	FURN_9001	40164785512001		{"1": 1700.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
29	16	1	1	E-COM12	\N	13	\N	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
30	16	1	1	E-COM13	\N	14	\N	\N	0.01	t	t	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
35	21	1	1	FURN_7888	\N		{"1": 2010.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
36	22	1	1	FURN_0789	\N		{"1": 876.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
39	24	1	1	FURN_8855	\N		{"1": 100.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
40	25	1	1	FURN_8220	\N		{"1": 2500.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
41	26	1	1	FURN_6741	\N		{"1": 4500.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
13	9	1	1	FURN_0096	\N	1,4	{"1": 500.0}	\N	0.01	t	f	f	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:19.323438	\N
14	9	1	1	FURN_0098	\N	2,4	{"1": 500.0}	\N	0.01	t	t	f	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:19.323438	\N
16	9	1	1	FURN_0097	\N	1,5	{"1": 500.0}	\N	0.01	t	t	f	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:19.323438	\N
15	9	1	1	DESK0005	\N	3,4	\N	\N	0.01	t	f	f	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:19.323438	\N
18	9	1	1	DESK0006	\N	3,5	\N	\N	0.01	t	f	f	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:19.323438	\N
53	35	1	1	FURN_5555	\N		{"1": 70.0}	\N	1.00	t	f	f	\N	2026-11-03 11:48:32.831653	2026-11-03 11:48:29.494074	\N
43	27	1	1	\N	\N	22	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
44	27	1	1	\N	\N	23	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
45	27	1	1	\N	\N	24	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
38	23	1	1	FURN_6667	\N	20	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
37	23	1	1	FURN_6666	\N	19	\N	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:19.323438	\N
54	36	1	1	\N	\N		{"1": 100.0}	\N	\N	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:37.287963	\N
55	37	1	1	\N	\N		\N	\N	0.01	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:37.287963	\N
\.


--
-- Data for Name: product_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.product_template (id, sequence, categ_id, uom_id, company_id, color, create_uid, write_uid, type, service_tracking, default_code, name, description, description_purchase, description_sale, product_properties, list_price, volume, weight, sale_ok, purchase_ok, active, can_image_1024_be_zoomed, has_configurable_attributes, is_favorite, create_date, write_date, property_account_income_id, property_account_expense_id, sale_delay, lot_sequence_id, tracking, responsible_id, property_stock_production, property_stock_inventory, description_picking, description_pickingout, description_pickingin, is_storable, purchase_method, purchase_line_warn_msg, property_price_difference_account_id, lot_valuated, service_type, expense_policy, invoice_policy, sale_line_warn_msg, service_to_purchase) FROM stdin;
1	1	2	1	\N	\N	1	1	service	no	\N	{"en_US": "Restaurant Expenses"}	\N	\N	\N	\N	14.0	0.00	0.00	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	purchase	\N	\N	f	manual	sales_price	order	\N	\N
3	1	3	4	\N	\N	1	1	service	no	\N	{"en_US": "Virtual Interior Design"}	\N	\N	\N	\N	30.75	0.00	0.00	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	purchase	\N	\N	f	manual	no	delivery	\N	\N
4	1	3	4	\N	\N	1	1	service	no	\N	{"en_US": "Virtual Home Staging"}	\N	\N	\N	\N	38.25	0.00	0.00	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	purchase	\N	\N	f	manual	no	delivery	\N	\N
2	1	2	5	\N	\N	1	1	service	no	\N	{"en_US": "Hotel Accommodation"}	\N	\N	\N	\N	400.0	0.00	0.00	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	purchase	\N	\N	f	manual	cost	delivery	\N	\N
21	1	5	1	\N	\N	1	1	consu	no	FURN_7888	{"en_US": "Desk Stand with Screen"}	\N	\N	\N	\N	2100.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
25	1	5	1	\N	\N	1	1	consu	no	FURN_8220	{"en_US": "Four Person Desk"}	\N	\N	\N	\N	2350.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
18	1	5	1	\N	\N	1	1	consu	no	FURN_1118	{"en_US": "Corner Desk Left Sit"}	\N	\N	{"en_US": "Left-sided workspace with storage"}	\N	85.0	0.00	0.01	t	t	t	t	t	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
23	1	5	1	\N	\N	1	1	consu	no	\N	{"en_US": "Acoustic Bloc Screens"}	\N	\N	{"en_US": "Noise-reducing panels for open spaces"}	\N	295.0	0.00	0.01	t	t	t	f	t	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
20	1	5	1	\N	\N	1	1	consu	no	FURN_9001	{"en_US": "Flipover"}	\N	\N	\N	\N	1950.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	lot	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	t	manual	no	delivery	\N	\N
22	1	5	1	\N	\N	1	1	consu	no	FURN_0789	{"en_US": "Individual Workplace"}	\N	\N	{"en_US": "Private pod with desk and chair"}	\N	885.0	0.00	0.01	t	t	t	t	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	order	\N	\N
19	1	5	1	\N	\N	1	1	consu	no	FURN_8900	{"en_US": "Drawer Black"}	\N	\N	\N	\N	25.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	order	\N	\N
29	1	7	4	\N	\N	1	1	service	no	\N	{"en_US": "Furniture Assembly"}	\N	\N	\N	\N	2000.0	0.00	0.00	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	purchase	\N	\N	f	manual	no	order	\N	\N
30	1	6	1	\N	\N	1	1	consu	no	\N	{"en_US": "Outdoor dining table"}	\N	\N	\N	\N	589.0	0.00	0.00	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	receive	\N	\N	f	manual	no	order	\N	\N
34	1	5	1	\N	\N	1	1	combo	no	\N	{"en_US": "Office Combo"}	\N	\N	\N	\N	160.0	0.00	0.00	t	f	t	t	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	receive	\N	\N	f	manual	no	order	\N	\N
27	1	5	1	\N	\N	1	1	consu	no	\N	{"en_US": "Two-Seat Sofa"}	\N	\N	{"en_US": "Two-Seater Sofa with Oak Wood Frame"}	\N	1500.0	0.00	0.00	t	t	t	f	t	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	order	\N	\N
12	1	5	1	\N	\N	1	1	consu	no	E-COM08	{"en_US": "Storage Box"}	\N	\N	{"en_US": "Blue plastic bin for flexible office storage"}	\N	15.8	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
13	1	5	1	\N	\N	1	1	consu	no	\N	{"en_US": "Large Desk"}	\N	\N	{"en_US": "Minimalist wooden desk for executive use"}	\N	1799.0	0.00	0.00	t	t	t	t	t	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
32	1	5	1	\N	\N	1	1	consu	no	FURN_0002	{"en_US": "Desk Pad"}	\N	\N	\N	\N	1.98	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	order	\N	\N
35	1	5	1	\N	\N	1	1	consu	no	FURN_5555	{"en_US": "Cable Management Box"}	\N	\N	\N	\N	100.0	0.00	1.00	t	t	t	t	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:37.287963	\N	\N	0	16	lot	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	\N	manual	no	order	\N	\N
7	1	5	1	\N	\N	1	1	consu	no	FURN_9999	{"en_US": "Office Design Software"}	\N	\N	{"en_US": "Design and plan smart offices with ease"}	\N	280.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	order	\N	\N
33	1	5	1	\N	\N	1	1	consu	no	FURN_0006	{"en_US": "Monitor Stand"}	\N	\N	\N	\N	3.19	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	order	\N	\N
15	1	5	1	\N	\N	1	1	consu	no	E-COM11	{"en_US": "Cabinet with Doors"}	\N	\N	\N	\N	140.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
16	1	5	1	\N	\N	1	1	consu	no	\N	{"en_US": "Conference Chair"}	\N	\N	\N	\N	33.0	0.00	0.00	t	t	t	t	t	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
10	1	5	1	\N	\N	1	1	consu	no	E-COM06	{"en_US": "Corner Desk Right Sit"}	\N	\N	{"en_US": "Right-aligned desk with storage"}	\N	147.0	0.00	0.01	t	t	t	t	t	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
14	1	5	1	\N	\N	1	1	consu	no	E-COM10	{"en_US": "Pedal Bin"}	\N	\N	{"en_US": "Soft-close pedal bin for office use"}	\N	47.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
17	1	5	1	\N	\N	1	1	consu	no	FURN_0269	{"en_US": "Office Chair Black"}	\N	\N	{"en_US": "High-back office chair with great support"}	\N	120.5	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
6	1	5	1	\N	\N	1	1	consu	no	FURN_8888	{"en_US": "Office Lamp"}	\N	\N	\N	\N	40.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
31	1	5	1	\N	\N	1	1	consu	no	FURN_0001	{"en_US": "Desk Organizer"}	\N	\N	{"en_US": "The desk organiser is perfect for storing all kinds of small things and since the 5 boxes are loose, you can move and place them in the way that suits you and your things best."}	\N	5.1	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	order	\N	\N
28	1	3	1	\N	\N	1	1	service	no	Delivery_010	{"en_US": "Local Delivery"}	\N	\N	\N	\N	10.0	0.00	0.00	f	f	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	\N	purchase	\N	\N	f	manual	no	order	\N	\N
36	1	3	1	\N	\N	1	1	service	no	\N	{"en_US": "Deposit"}	\N	\N	\N	\N	150.0	0.00	0.00	t	t	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:37.287963	\N	\N	0	16	none	\N	\N	\N	\N	\N	\N	f	purchase	\N	\N	f	manual	no	order	\N	\N
11	1	5	1	\N	\N	1	1	consu	no	E-COM07	{"en_US": "Large Cabinet"}	\N	\N	\N	\N	320.0	0.00	0.33	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
24	1	5	1	\N	\N	1	1	consu	no	FURN_8855	{"en_US": "Drawer"}	{"en_US": "<p>Drawer with two routing possiblities</p>"}	\N	\N	\N	110.5	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	lot	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	\N	manual	no	delivery	\N	\N
26	1	5	1	\N	\N	1	1	consu	no	FURN_6741	{"en_US": "Large Meeting Table"}	\N	\N	{"en_US": "Big table seats 10–12 for team discussions"}	\N	4000.0	0.00	0.01	t	t	t	t	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
5	1	5	1	\N	\N	1	1	consu	no	FURN_7777	{"en_US": "Office Chair"}	\N	\N	{"en_US": "Comfortable yellow chair for daily work"}	\N	70.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
8	1	5	1	\N	\N	1	1	consu	no	FURN_7800	{"en_US": "Desk Combination"}	\N	\N	{"en_US": "Desk combination, black-brown: chair + desk + drawer"}	\N	450.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:37.287963	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	cost	delivery	\N	\N
37	1	5	1	\N	\N	1	1	consu	no	\N	{"en_US": "Chair floor protection"}	\N	\N	{"en_US": "Office chairs can harm your floor: protect it"}	\N	12.0	0.00	0.01	t	t	t	f	f	\N	2026-11-03 11:48:37.287963	2026-11-03 11:48:37.287963	\N	\N	0	16	none	\N	\N	\N	\N	\N	\N	f	receive	\N	\N	f	manual	no	order	\N	\N
9	1	5	1	\N	\N	1	1	consu	no	\N	{"en_US": "Customizable Desk"}	\N	\N	{"en_US": "160x80cm, with large legs"}	\N	750.0	0.00	0.00	t	t	t	t	t	\N	2026-11-03 11:48:19.323438	2026-11-03 11:48:39.293035	\N	\N	0	\N	none	\N	\N	\N	\N	\N	\N	t	receive	\N	\N	f	manual	no	delivery	\N	\N
\.


--
-- Data for Name: purchase_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order (id, partner_id, dest_address_id, currency_id, invoice_count, fiscal_position_id, payment_term_id, incoterm_id, user_id, company_id, reminder_date_before_receipt, create_uid, write_uid, access_token, name, priority, origin, partner_ref, state, invoice_status, note, amount_untaxed, amount_tax, amount_total, amount_total_cc, currency_rate, locked, acknowledged, receipt_reminder_email, date_order, date_approve, date_planned, date_calendar_start, create_date, write_date, picking_type_id, incoterm_location, receipt_status, effective_date) FROM stdin;
1	8	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00001	0	\N	\N	draft	no	\N	3026.50	0.00	3026.50	3026.50	1.0	f	\N	t	2026-11-03 11:48:34	\N	2026-11-06 11:48:34.793433	2026-11-03 11:48:34	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	1	\N	\N	\N
3	15	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00003	0	\N	\N	draft	no	\N	255.00	0.00	255.00	255.00	1.0	f	\N	t	2026-11-03 11:48:34	\N	2026-11-04 11:48:34.828979	2026-11-03 11:48:34	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	1	\N	\N	\N
8	8	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00008	0	\N	\N	purchase	no	\N	6465.50	0.00	6465.50	6465.50	1.0	f	\N	t	2026-10-29 11:48:34.881028	2026-10-25 11:48:34.881077	2026-11-03 00:00:00	2026-10-25 11:48:34.881077	2026-10-14 11:48:34.880963	2026-11-03 11:48:36.241642	1	\N	\N	\N
9	10	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00009	0	\N	\N	purchase	no	\N	12500.00	0.00	12500.00	12500.00	1.0	f	\N	f	2026-10-19 11:48:34.897381	2026-10-29 11:48:34.897432	2026-11-03 00:00:00	2026-10-29 11:48:34.897432	2026-10-14 11:48:34.897315	2026-11-03 11:48:36.241642	1	\N	\N	\N
10	15	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00010	0	\N	\N	purchase	no	\N	2505.00	0.00	2505.00	2505.00	1.0	f	\N	t	2026-10-19 11:48:34.914078	2026-10-16 11:48:34.914124	2026-11-03 00:00:00	2026-10-16 11:48:34.914124	2026-10-14 11:48:34.91402	2026-11-03 11:48:36.241642	1	\N	\N	\N
2	10	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00002	0	\N	\N	draft	no	\N	3095.00	0.00	3095.00	3095.00	1.0	f	\N	f	2026-11-03 11:48:34	\N	2026-11-04 11:48:34.81844	2026-11-03 11:48:34	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	1	\N	\N	\N
5	9	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00005	0	\N	\N	draft	no	\N	8658.00	0.00	8658.00	8658.00	1.0	f	\N	t	2026-11-03 11:48:34	\N	2026-11-03 11:48:34.850744	2026-11-03 11:48:34	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	1	\N	\N	\N
6	8	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00006	0	\N	\N	draft	no	\N	1335.00	92.70	1427.70	1427.70	1.0	f	\N	t	2026-11-03 11:48:34	\N	2026-11-03 11:48:34.860071	2026-11-03 11:48:34	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	1	\N	\N	\N
7	11	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00007	0	\N	\N	draft	no	\N	1222.50	0.00	1222.50	1222.50	1.0	f	\N	f	2026-11-03 11:48:34	\N	2026-11-03 11:48:34.874279	2026-11-03 11:48:34	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	1	\N	\N	\N
4	11	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00004	0	\N	\N	sent	no	\N	14563.00	0.00	14563.00	14563.00	1.0	f	\N	f	2026-11-03 11:48:34	\N	2026-11-08 11:48:34.834772	2026-11-03 11:48:34	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	1	\N	\N	\N
11	11	\N	1	0	\N	\N	\N	2	1	1	1	1	\N	P00011	0	\N	\N	purchase	no	\N	6936.00	0.00	6936.00	6936.00	1.0	f	\N	f	2026-11-05 11:48:36	2026-11-03 11:48:36	2026-11-05 11:48:36	2026-11-03 11:48:36	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	1	\N	pending	\N
\.


--
-- Data for Name: purchase_order_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_line (id, sequence, product_uom_id, product_id, order_id, company_id, partner_id, create_uid, write_uid, qty_received_method, display_type, analytic_distribution, name, product_qty, discount, price_unit, price_subtotal, price_total, qty_invoiced, qty_received, qty_received_manual, qty_to_invoice, is_downpayment, date_planned, create_date, write_date, product_uom_qty, price_tax, technical_price_unit, orderpoint_id, location_final_id, product_description_variants, propagate_cancel, sale_line_id) FROM stdin;
6	10	4	4	3	1	15	1	1	manual	\N	\N	Virtual Home Staging	10.00	\N	25.5	255.00	255.00	0.00	0.00	\N	0.00	\N	2026-11-04 11:48:34.828979	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	10	0	25.5	\N	\N	\N	t	\N
7	10	1	6	4	1	11	1	1	stock_moves	\N	\N	[FURN_8888] Office Lamp	6.00	\N	85.5	513.00	513.00	0.00	0.00	\N	0.00	\N	2026-11-08 11:48:34.834772	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	6	0	85.5	\N	\N	\N	t	\N
4	10	1	6	2	1	10	1	1	stock_moves	\N	\N	[FURN_8888] Office Lamp	20.00	\N	132.5	2650.00	2650.00	0.00	0.00	\N	0.00	\N	2026-11-04 11:48:34.81844	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	20	0	132.5	\N	\N	\N	t	\N
5	10	1	5	2	1	10	1	1	stock_moves	\N	\N	[FURN_7777] Office Chair	5.00	\N	89.0	445.00	445.00	0.00	0.00	\N	0.00	\N	2026-11-04 11:48:34.818559	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	5	0	89	\N	\N	\N	t	\N
1	10	1	5	1	1	8	1	1	stock_moves	\N	\N	[FURN_7777] Office Chair	15.00	\N	79.8	1197.00	1197.00	0.00	0.00	\N	0.00	\N	2026-11-06 11:48:34.793433	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	15	0	79.8	\N	\N	\N	t	\N
2	10	1	38	1	1	8	1	1	stock_moves	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)	5.00	\N	286.7	1433.50	1433.50	0.00	0.00	\N	0.00	\N	2026-11-06 11:48:34.796636	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	5	0	286.7	\N	\N	\N	t	\N
3	10	1	39	1	1	8	1	1	stock_moves	\N	\N	[FURN_8855] Drawer	4.00	\N	99.0	396.00	396.00	0.00	0.00	\N	0.00	\N	2026-11-06 11:48:34.798415	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	4	0	99	\N	\N	\N	t	\N
17	10	3	33	8	1	8	1	1	manual	\N	\N	Drawer Black	15.00	\N	280.8	4212.00	4212.00	0.00	0.00	\N	0.00	\N	2026-11-03 00:00:00	2026-11-03 11:48:34.234095	2026-11-03 11:48:34.234095	180	0	280.8	\N	\N	\N	t	\N
18	10	3	34	8	1	8	1	1	manual	\N	\N	Flipover	5.00	\N	450.7	2253.50	2253.50	0.00	0.00	\N	0.00	\N	2026-11-03 00:00:00	2026-11-03 11:48:34.234095	2026-11-03 11:48:34.234095	60	0	450.7	\N	\N	\N	t	\N
19	10	3	23	9	1	10	1	1	manual	\N	\N	Large Desk	20.00	\N	500.0	10000.00	10000.00	0.00	0.00	\N	0.00	\N	2026-11-03 00:00:00	2026-11-03 11:48:34.234095	2026-11-03 11:48:34.234095	240	0	500	\N	\N	\N	t	\N
20	10	3	19	9	1	10	1	1	manual	\N	\N	Corner Desk Right Sit	5.00	\N	500.0	2500.00	2500.00	0.00	0.00	\N	0.00	\N	2026-11-03 00:00:00	2026-11-03 11:48:34.234095	2026-11-03 11:48:34.234095	60	0	500	\N	\N	\N	t	\N
21	10	3	31	10	1	15	1	1	manual	\N	\N	Office Chair Black	10.00	\N	250.5	2505.00	2505.00	0.00	0.00	\N	0.00	\N	2026-11-03 00:00:00	2026-11-03 11:48:34.234095	2026-11-03 11:48:34.234095	120	0	250.5	\N	\N	\N	t	\N
15	10	1	31	7	1	11	1	1	stock_moves	\N	\N	[FURN_0269] Office Chair Black	5.00	\N	130.5	652.50	652.50	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:34.874279	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	5	0	130.5	\N	\N	\N	t	\N
16	10	1	6	7	1	11	1	1	stock_moves	\N	\N	[FURN_8888] Office Lamp	15.00	\N	38.0	570.00	570.00	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:34.874388	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	15	0	38	\N	\N	\N	t	\N
12	10	1	6	6	1	8	1	1	stock_moves	\N	\N	[FURN_8888] Office Lamp	9.00	\N	58.0	522.00	522.00	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:34.860071	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	9	0	58	\N	\N	\N	t	\N
13	10	1	5	6	1	8	1	1	stock_moves	\N	\N	[FURN_7777] Office Chair	3.00	\N	65.0	195.00	195.00	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:34.860168	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	3	0	65	\N	\N	\N	t	\N
14	10	1	43	6	1	8	1	1	stock_moves	\N	\N	Two-Seat Sofa (Linen)	4.00	\N	154.5	618.00	710.70	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:34.863211	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	4	92.70000000000005	154.5	\N	\N	\N	t	\N
10	10	1	35	5	1	9	1	1	stock_moves	\N	\N	[FURN_7888] Desk Stand with Screen	3.00	\N	2010.0	6030.00	6030.00	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:34.850744	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	3	0	2010	\N	\N	\N	t	\N
11	10	1	36	5	1	9	1	1	stock_moves	\N	\N	[FURN_0789] Individual Workplace	3.00	\N	876.0	2628.00	2628.00	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:34.852542	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	3	0	876	\N	\N	\N	t	\N
8	10	1	34	4	1	11	1	1	stock_moves	\N	\N	[FURN_9001] Flipover	5.00	\N	1690.0	8450.00	8450.00	0.00	0.00	\N	0.00	\N	2026-11-08 11:48:34.836724	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	5	0	1690	\N	\N	\N	t	\N
9	10	1	20	4	1	11	1	1	stock_moves	\N	\N	[E-COM07] Large Cabinet	7.00	\N	800.0	5600.00	5600.00	0.00	0.00	\N	0.00	\N	2026-11-08 11:48:34.838493	2026-11-03 11:48:34.234095	2026-11-03 11:48:36.241642	7	0	800	\N	\N	\N	t	\N
22	10	1	38	11	1	11	1	1	stock_moves	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)	20.00	\N	286.8	5736.00	5736.00	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:36.627901	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	20	0	286.8	\N	\N	\N	t	\N
23	10	1	34	11	1	11	1	1	stock_moves	\N	\N	[FURN_9001] Flipover	10.00	\N	120.0	1200.00	1200.00	0.00	0.00	\N	0.00	\N	2026-11-03 11:48:36.629107	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	10	0	120	\N	\N	\N	t	\N
\.


--
-- Data for Name: res_company; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_company (id, name, partner_id, currency_id, sequence, create_date, parent_path, parent_id, paperformat_id, external_report_layout_id, create_uid, write_uid, email, phone, font, primary_color, secondary_color, layout_background, report_header, report_footer, company_details, active, uses_default_logo, write_date, logo_web, nomenclature_id, resource_calendar_id, alias_domain_id, email_primary_color, email_secondary_color, iap_enrich_auto_done, snailmail_color, snailmail_cover, snailmail_duplex, fiscalyear_last_day, transfer_account_id, default_cash_difference_income_account_id, default_cash_difference_expense_account_id, account_journal_suspense_account_id, account_journal_early_pay_discount_gain_account_id, account_journal_early_pay_discount_loss_account_id, account_sale_tax_id, account_purchase_tax_id, account_purchase_receipt_fiscal_position_id, currency_exchange_journal_id, income_currency_exchange_account_id, expense_currency_exchange_account_id, incoterm_id, batch_payment_sequence_id, account_opening_move_id, account_default_pos_receivable_account_id, expense_accrual_account_id, revenue_accrual_account_id, automatic_entry_default_journal_id, domestic_fiscal_position_id, account_fiscal_country_id, tax_cash_basis_journal_id, account_cash_basis_base_account_id, account_discount_income_allocation_id, account_discount_expense_allocation_id, income_account_id, expense_account_id, price_difference_account_id, fiscalyear_last_month, chart_template, bank_account_code_prefix, cash_account_code_prefix, transfer_account_code_prefix, tax_calculation_rounding_method, terms_type, quick_edit_mode, account_price_include, fiscalyear_lock_date, tax_lock_date, sale_lock_date, purchase_lock_date, hard_lock_date, account_opening_date, invoice_terms, invoice_terms_html, expects_chart_of_accounts, anglo_saxon_accounting, qr_code, link_qr_code, display_invoice_amount_total_words, display_invoice_tax_company_currency, account_use_credit_limit, tax_exigibility, account_storno, restrictive_audit_trail, autopost_bills, internal_transit_location_id, stock_mail_confirmation_template_id, annual_inventory_day, annual_inventory_month, stock_confirmation_type, stock_move_email_validation, stock_text_confirmation, horizon_days, po_lock, po_double_validation, po_double_validation_amount, account_stock_journal_id, account_stock_valuation_id, account_production_wip_account_id, account_production_wip_overhead_account_id, inventory_period, inventory_valuation, cost_method, stock_sms_confirmation_template_id, has_received_warning_stock_sms, days_to_purchase, quotation_validity_days, sale_discount_product_id, downpayment_account_id, sale_onboarding_payment_method, portal_confirmation_sign, portal_confirmation_pay, prepayment_percent, sale_order_template_id, security_lead) FROM stdin;
3	My Company (Chicago)	43	1	10	2026-11-03 11:48:29.494074	3/	\N	1	\N	1	1	chicago@yourcompany.com	+1 312 349 3030	Lato	\N	\N	Blank	\N	\N	\N	t	t	2026-11-03 11:48:36.079836	\\x6956424f5277304b47676f414141414e5355684555674141414c514141414177434159414141433437464438414141666b456c455156523432745639655a5255316258336235397a68787036486d6c6f415673454c49526757685448526756466a54696c5347496d6f39456b6d766465346b7679586f61585372313861795676765a65566c3377766d70414a5938416c7052676a47715948564b4b474544764767585a6961756d6d3657366736614747652b385a766a2b36437175624271717170655737613955436d6a35317a396e37642f62353758333232596344384148516d55382b6a7748414173417a2f3836336e5a6e545475585a686a4a745441437377485a327068304b614d637a3759787879435466646a524b4a6f573079387145436867627937537a6970424a396e316e504536796770514664444b72624646414f7a4e48615636424375655a39346769326f6e4d4a312f46475a6e325868457951655a64716b695a71447a486c6e32664b6d42734c476343544b524d4a68496e444941796975796b56344469636858676e6d5977733879377867506d5168544133775046465373547277435a5a4d45734335534a6d544e527a335363434143436e3259725a4752655745776e7378536a6b4a6c715a64706c4656344d6d417456654b474b4d334d55586f684d6a4a786c324333514d724d437763787971456b684d6e6b2f63534941614b4d416853507a7374506453574f6359425946674a6d4e736b4b6e473878474561734f7872444d4b464468587046674c6f526d6e4245344d517159635956616f554b585268706e75304956783473453833686c6f677577586d5035413458536a474b6f56364667506d4e775970774759702f4c685534336d4e6b4567336b305a7936555a716743486342697745796a4f4c4e587045784f74774e34576e4269354d6d465a42474b4f39334f5471356c4c675355624e54594367477a5653416f3379755a6943496d654b45794765397164556267684534785577766c517355344f385536674e6e4246637350692b484d6863686b74434e587a45517442737855424a694c3563786e4845364d6b335379474334304554516a3177453855384763625a664c6d536369396a35657931774d6d4d386f6e504178764d31437542417462467a6f64327a48544361546368794b4b34517a573055364f2b4d4238336843633856736d68546b414459324e767238666a2b7671616c52313135377257787261394d46794b5359545a4e4363544b3633576b7a656a51474679706b536333646571585454444e4f7767393164696a364a4b416b6f466b4172626c67316e6b6f5842646f6d5366536a386a36412f6e4770636537576857446b2f484b7043436355444764314e424549495361516d646450767661534d4962656d5056706c2f38703961616945696652707052714f65654f776e6330387750637a6e7a52506752575444624e31353863334f4a763449445146716d55302f393662472f6e4753732f7a3978356f4a7859685154686c71455258596b456e4766577631555a64415876437370456e2b505243492f694d5669787978324a4249357a75466375584b6c6c55366e6558643374346478624a6f73573761736445704a79456832646d6c5042716938484e6878634d64516132757264774a36346f5858414455506636477976783949384b53754c3630322b6737745438533278314c764d57645745304339736a4952776671677636616934596c796630555651426849396830454d414e41596f78566b343369766f5743756442775a5a5a6d544e522b684656552f44434f75427550786c565451314e66796b304a6148556f476f324f474751304768327245326b41694344436f6f6a71484d716a38346b7a687848574d6351673032796d564b6b4e676449614a725141597859503154533374714a31535351533064466f4e4373554e44633369396257567546622b646e664d364f3070615463455255555a49354f482b6b583769494148546c394741396e4c6d6254784544786d79594d6744527377774d6834516d76416943414b48474b475070454a52704e4a4a697a71785552386b2f4c7a484c6d796b39662b3458666c50724b616833587352696e4479696c42686c345738414f386f364258512f62504e42655531722f62306b6e4b556d4441356f3053484e75734636763831655072332f3077556845733269554b514c773763693347614a4146434d6d78576a4f374146414f4c794778324c4c355233583350584432724a4a583071374b524149706d6d694d3758764d327333504c61797672342b324e33644c57664d6d4b46333764726c334c34342f4c4747594e4e714954316f4464695768514e44375a392f664e4f6a50777548777a775769386e3349633663425571786955594b6746732b74627a79317650756544566742616341684b51377448666c686f666d6a724c513777566e396959497a4d5836566752414767557154694d494c726d33514a75796c704547424945627246517937324a74436e676b742f6b454f615a684c7a41384634797859664f6e415561454771756865646b314878364b52756b524149594731476a72506b595936686956694d57577130676b776c5a756933373936745239317757736b746c4375454a4b5a5653776d76387a663862385a317a4c37612b75726b61344c537a577a6c3162576561722b5a355753696d6c684733367243504a336a2b4d41655a434c54506c574c324a326b677969677a4e76562b3547524f5a39694141654559426e5279654f516b63365750374c6a74712b62677a3445773978353637506945472f337134624f2b646a50474b6779556448624f536c34526431354643535545716b39476e695451304f4f4f387a6d72343956314c372f3861514f44456f5569386339445a3938566e2f76655a5057474565517978334b5652484f655441745165522f72775651632f62357654746845784a70516e532b79794b65644f447a305132377a363635467778497132526456484a6e2f696d3256473562536b6d7841474d3432554742726f5472357a50344551436f5830364a68714f42796d55452f496d464d33522b2f7332556e62734133786546794e5575677843397651304543544a3039575455314e4c42514c36564772444d4c683849694d786c67736c7558617371576c5264585631544541434956434f6a4f784b64495334585071357567595973684d4f426f567276517739716259695a6269592f48696c705957597845574954752b74726f3248597646314367416a5a5543537546776d49563651675141327744453431475a5851484334544339394e4a4c787544676f4e48643353314f4d4d4750665566322f657547316c46726179764479437a4a51674d46783342435263793459776f4c4e59536d586e3352683971504a767332374476382b6a64445a313277326f4f726d544c724447575751304d7a786e676d4d674b74744e54516a42456a67772f4c57576b4e762b314854374c7a795565652f6556746a59324e2f6f364f4475415557584e5a367647784a5a2f366356334a6c4839494f6b6c684d4a4f35326b6e75476e727a676d337844627576762f4c362b56504c5a6d356e326a5155704c4a4e322b684b7648502f34357365665444542f746a4b30397a63724559356c574f394c3674344d7964636c712f46797a342b6e4341464e4f4e6271464d3578626c6830704e516a6953475439384167416948312b6859624c6b383866694f5736324f576652494a4d4c4757455648747a7670633472663434324e4336324f6a75314f4161766a6d4e6d5652703567486a467a49693052413475674e6a322b7964525364784f6f4f30426c5a5146574e744d564c705353344977444448413878324845504b6c6b49474148754363384b4b57304b31773933444f536a70746d515a524e417741705a5862476e5451306c365565713161742b7459564d356463487a524b7a3347464b3071736b704a70397654764575686a6e777a632b774d66443170704e2b6e36624c39314a4e32373966464e6a7a36344a7279474c3438747a31705a33644c5349755078754144416c79315a646c6b7071372f41533666725447346c70656e746562332f35542f47597373374d362b327334494d68554c6c6b36736d583841735377486163464b694b2f376e5461396c7752594f672f66314c4c3745494d4d575568754f53487037392f2f707a78306438454b686b44577059744c466c6d565a576d76535369656a6634712b4d487632374f6f4c7031353575314c69374a51593276666b746a557255647832396f6763373168734f5a706e4e7a664d4f476657356159626e4f473636524b2f50396a62703370652f76334774632f46596a45764641705a625731744c4e63427a41477a38644872506e574449617835556d746d42505465747134584e7364697361354c4c377830567341666d414641434931307838463932336674327555636d366a44337947506b3639687052306b32312f706266335457363973333576546435576e55337a63436d34557734576938616841484a67326256706e6c586a39707253525467664b4b69353068614f46464d49305454506c4a66634f7076712b74362f6a37625537337468785a50486c4e357862727962644665526c587a613561516b7051455145445130433135414b41494c42594c35785a7231753354706a31363564412b644f4f752f4c3036764f665a71424d5563343275612b6d38505833764754674247384b6931537975416d54346e6b554539712f333045776e2f452f6f4e6c64306d626d3574565042345874312f316b6475714176582f786f6a507430776238414d4567745143467870583970312f66664d6a7a37583962365339765832777672376531393364375456556e6a567665766e4d7a61514a50737550772b7a516b77427569375245654451654655656e7a764e4e635a7565394d755347684351776d4350504b396e52736576337453653664564f4c6d6c36707351714c6557635979673939484c4c677059375a39544f57787577676d646233454a5073724d443156694e7730686d39484471705667663435564f316841314c6f532f7066547566772b594a58655a686c6c6c6d435a3055494e413845732f37763751463138646349393850375a783965724d436a6e434d69397475576e68354e4b70442f6c35594c3742544769744962584167696c4c443030762b2b413348433831362b796157662f7365673653336c436974364c7250414437416242494a494a6f4e4b724356332f303167702f336266486b7538567670712b425764642f73694c7535372f31707476766a6c346b6b32365532377873324938397767694441447179732b61576f584a4736617957532f55426963394a4b54514672664d7445793874694d64767953326566585071365a5654627674317474754f61494f44713365384f742f37657276754555706d57534d363246584d614d4854515141482f2f34782f50654e476c746265587a367563462f2f4463302b754f4f6b642b62746b3256306f707867782f6e612f7876737952546d30594a7539334433316e59337a6a472b664d4f4d6475525773577a4c4b317464554c332f4352723953584e543568632f39384b456a50636157554171357749447a68576d525631766f612f72466c39744b744330494c61712b3838736f30414243524a6e444e796651597544615a4f614c76626b71517751795877445670726a6b7a584e50484e51417778725442544a6542613631494738776f6e56593136374553712b78737a334d68704143424461436b49456375522f455245596c455250506935764b72617a2b3773625a6b306c634d5a6c524a543771753530424b41646431704a4a612b466c676272322f6364587456332f737578306448616c494a4b4c44345443505271507168705962356b38706d62362b684a664f4635346e553237536354784861365668614c756d4b6c43376f7161302f714f6535796b2b4c4175584d5a5a6479566b30476c584c622f7a6f50396557546c6c374d766e573251332f75504473526473756e3339357259592b687245543049775472754473464848486b784a305133466d6b622f637834496c70725a7349675a584f364a33734f4d7a723231357266754f4f2b35346250723036613331395a505758686936384b337762654576726e762b695438636358742f61426f476733353361534569565944436a6d3051764e4c396968754a614859672f644c584270332b64797a44346c6f7235516c58515774706d7a342b6b447179666333477a682b46516d4672313635644c4d4f5a5a577472713766736d747357567874542f6c4d4c6b6f354943394d307555754f546a694a50593549487a4a4e30394a61492b6b4d755657426d766b7a7035322f49754e455a61636961536a53304b53684351446d314d3352414843304d32466f725269676166677a306d66523041516945744b447763326d636e2f567a495133674c5249376b3036513373636d5235414541714650353757333948526146544e346e502f70387173767a7a704a46796c6c545a4d77307172314a476b6b396a74777447326152757563495551516b3471612f7a57725576447430616a555a56782f6e694e37367948676d5a706564704c6579426974756d7a5065556b457537513370524d774f592b2b486c7769745343514342415565354b7675796132785a5838636e2f4e554b2b63444261766f6e306b467670722f6e6739495a7a66304848753361354f64346e5455686a4a77437a7a48386258416d7068565a51776a4a4d356b726e62372b502f2f3746634468386630314e7a58494155696b704c4e734b6c7061582f6d6a4a6b69764f5074527a344b47306d784c45474d2f2f464e4b5963556350674e665774707a69385a6550396f6e752b3458324642454252455445794a5870524f3951782b6542754468382b49395a436956656650464641594171724b71495252616b3971545039426b4a5a334262682f663268513976664f6744667a6d386257353338734144697054446942744a4e796e4b7a657162506e54357a56646e4a7547595a7a4a333975776b414e775a386e6965356c5278346a715248747a664b7a715872747a2b302b61662f2b4848462b7738384e49746144756d504a326e6264616f68695969766653614479306f73636f2f6b585a53676f674d496f612b5a4f383358753766506e666c786f632b73442b783734492b352f417a6c6d455a556b764e4e4e4e6c756a714b454b786f50437075767537324b344a32634b486a70695152475977784f707a712b652f647956317a483337687077733633583158444b6d2b485a7734534939686b5051492b53716636544f473067507866656e584c38724b747a66522b53575a493938797333725a6a53323374305152565a6b49555462736d4e66425a7a59475a79346b4732705972634d624e434169704654697255676b776f4c42306d7530316b4a72725141597275734b6e393948566257544c396e7938705a4f7a56552f41344f6d676841394f74744f5a6b4a68636b313444662f647869665770647a554d375a704d326a745771624e4270796a5033336d2b5764656e6c632f4c35674a4a336b52524451523655756272326f7934622f594559376d7a4c5153597544676e77382f3965474e477a652b544552446258397436346c742b7530502b37322b4279335459744351426a4e3164556e394c5144417552347a5372547572585557414737364441565158754d6a42756f6533503950543231597536463552764d5167494858586e75742b31524752516e467369744439716c5577336f74522f574e5068364167704b6d5962462b722f6358717a65742f4e354c4c3778304942774f707a66466e336e7474322f3934754d706d57673375575734776c552b7778634b4e3335364c6741455a4d6d314a7265314a69307377364a425a2b444a3152742b39655634664d4d374d775a6e444b3366764f36357664317633757a434f63675a5a7a7244494331544d6742592b4d475763334c6b61777835417a33787a72556632624a6c79393879386a3334324f5a565030724b2f7638375172372b366c73426f484a505a634535336979484d78643655424765634563346c566f44706d6c5752614e524a5431765032504d55456f70726256676a476d744e66556636652b635654327246416f2b6e5766634d4a384d735a30394f306c446b342f374f346749424767696743757a55304f5455434a7230565662754930416f4c51696344626e7a4e526153394d7734626e792b54662b657544777666662b7a4e526157395856316346774f4d775070512f2b50693153494d7273656b71614467416b523449314336795553444541737254654c2b675551395261677a4f444a357a456f5a64372f72596a4841377a31745a576c624d7a65394a48657449632f624f2b724a4667616f62574771534a74465a494a314a72772b45776e7a5a746d69385769316d7a5a7330717852373044346d424c515933414b326c795333754a62787047544c56704a556d3069436c466671474471324d5243497346416f46646d475864322f7a76576238722f47446732376642734d774b6573524b575554414652552b4a73345a3661476c715a686b75654a352f612b31744d6469577731744e6255334e787368734e6833705075666a6f74556d4245772f524d736d6b5a4f6d6d67774950504445556b58626468474242435370366a5453615667453848466c78303055566c76516436667a77774d4e415444415a743237594e76393976397666336231792f666e32386165377347797a7543306f6c46444c4f5941475a5869656371515453476d7145677155534e6f48306e4e6f3578314d6f41676349325178425273776c45463535397463474147355a6c67514172725372316274695564414d414f536f7a454b744e4e665156476158535143712b6342486958753254304f64464a6e454346446f3733693759794154713831474e505170644d637a5559305430512b65773046424941454179575453414b446e38586d4f317071306642637347674452734634315a5856446c447468703036644f6f7954357177385472683263774b42394c43634f484748514d4332625143676d357161464143514545497266657a376c565963414a4a65737542645559615236593535426256335949634a414a7978584b654f70425453623562554e6c576339373331573966766675667464793770367a7636594371522b6c3133562f63335636396576585471334b6d566453583133325a676f507957593561765135447069523470314f452b686d70443732344944653851496e476f66372b5355674977704251676a6f733074483937782f5a3051304d44335454354f31347346704d3176736b7466697349614169414e4f506f4241426e4b4a465353696f4154476b4654586f4b6766523135337a504136423339473272306c6f46744e62365a463549646a494253464a2b613959786d5443546561506c574a5564753051374d644b6174474c457757787a635377576b314f4e7161713575566e47326d4975456148454c4c31434b674741754e53654e6f4b735978686f72494d78706a56424d57496f72796a2f524451615665765872336549534b395973634a62734b426c55706c56635a3051336a4854784a696a4161442f63482b586c464b436875554c70692f573047593048685868634a694873515a6a7974665158514251366173737544424f556164755862674d41417a44457054626a6f69356e714d713764723737726a754c72647a2f2b352f2b38317a44392b662f65386c6c79365a33314231396b394b575558494661346d4967353930704255735565453368306c343865316955616a576b5054386e507054533978667075504238353352466f4572624a7a506e37395a783538592f637258323139712f585169713750345a596c74313866744d752b35673176424847704252314a6454384c414a37482b68695949434c4c45363471395a5664635033567479364a62726c71453662423131513937527557615675653845516d566666646c554e4968754b65455834454e3438663335484d6e77354c622f53452b793845346b4a3675697051632f394e5639332b38744e626e33674d5856424e5455336c433264642b56322f57584b654a7831686370734e65663137642b37662f436f414b4f357445394a376744514d56376936677456382b424e4c372f3742776348324832312b66764f52705974764f722f656e767a664e766b6d75644b56426a6547633749643067426f7439373939726d592b37715042304b4f534d735375377a706b7a66652f64416275312f356c316773646a6747476c4f2b50554d484e674a413355563148746f4c7937597a696b6b677357437058413659303534415455704a566532722f5a4a766575426a6a644f622f757734626d2b705654616277376a5978774b574b394b4b694c456337716e4873457a464a745563372f5750595261586835667a57417779664f334139387439356175343546703472717930367536633333544a6452664d764853506b7271554d7a62504a417565384e79414862434f70412f74324e503739724d416f63787664796c53523031516a64414b444e7963346d7438387535627674437130706a6b5934475a536d6f412b72686f682b666d6e55647a4d706d4d2f527942496843653342546239736b6237746c53626464646e55675075515933537159457036322b612b6c3958326347473951535a2f6b732f316d6563425742613234776c6b774e2f466462572b2f516d7641617676796c3552732f325854504b35582b6d6e6c704c2b55704b4b5053562f754153623537506e33747562324777632f323877423530674e6f3242386a55485a735a76637233596e45704948766c2f73726673736c6c384a7a5a626c5a632f6538365266663849455a433865576236713339665839723633543045537876454b3549337772566b773256447675644148415a2f68546e48474c68694d64476434335044746434516f66393964586d2f573354433664656b2b4a565861467953334c6b36346759746d644945314579694344484a34576f35595071786a4c724a57436868596145427061354d61365279554a795167694c4c5a783965704441373072664a62665a4d7a6772756534706d4533324d78336d632f777a325067516b6f704133625147704c3942377259336a766232747263652b2b397831792f592f31415176552f343750394445536556454a774d6f4f324c4c6d79784b36594b5348674b586541774d56776e37547730704979686f43512b5a6d4746675174437152654f544c4a2f5a353338366f4a55416348393331324d4e33664876435657464a4a7062583266475a77727333386c31726350737354777548456d632f326d623375775564696d34657a454c2b363436736d6473487253757a2f5846494d3966744d76366d31316f376e4f44617a53344a32734d6e48417551704430704c6b577551704a4163674e6653306d49387676485256596348442f3030482f6b4f7976367544757a2b64487437653572776e58794f394932653449495643756268686c4556695554596f6c735776705077426e3844306c416b4f556a5473512f5468744175556a4b466c4a654149394f516b414454527537764b564b6d49394c7559504c6f547746673362703175576d4c65547345322f5a747937597039317342772b4a6d6964384b4749414f6e71684e464645645173686176666c583933556d396e33646f33535062666b73693573674d44444734444e39426e48775075665168726454727933612f4f7a6d313445775837466942514e433170346a62333737634b4b3331572f3762647630475a5a6877754163726b37705876484f767961397762664b4175576d7a2f515a424b6f39306a356f355469787458347259506974674b474a61764945383469454b4b303036647a764157714848516d4e387843794e7631703037366442313963334364366677656d6d573336544d3459434177474e2b457a626475443133647761482f6b3057645733686c42424c46596a4c573374364f78736448652f507a36375231442b35594f75514e2f595a7778762b577a4c644d697a6a6b3853716536427a752b4c715238316554445551344672615357486741646a3864564242473261744d76763943563350653155386e3339594758727436365965744f494d4b41714d71484d343832656c51346d48507078664466463763735865697a6a45717475527132506f7145454962576d6a6a6e6b6e506a68425a576b57534a517750372f766a53483139483861637165414d6137433530756663732f59664c417236536d5936586c4c595a3450314468376576334c7a6931524e6b736d57322b47636f594a637a2b34725a4452665943323955576a567a6d39564c49644d576647386b76503574613765752b574e4f316c69754d2b3067684a4937476a397a68344b2b684c677567364339536570622b39544770313734314858334c43757a4b2b7339346245452b70302f3748377169634e76486b374d6d7a665050332f4b5a626558734b444e4f45504b545237393566722f6558774d71335279366a554439716562507666686f4b38304144416b334d5467772b742f6b763065733647686758563164535542344b62464e793073513930316b72775173356c667074516867396c2f662b5049333961317472612b5179426f3642475655567461576e676d6351764c7272747463616d717573427a6e5772444d727137784c364e5737647533586e6e64666674446c6a424a6b416a365359365632352f36487a30342b6937474e45456b42354c766c796262772b4b76766a5457352f636b7050496c412b5943385a4a64752f636e2b4f456e4c616e425331474a7258536835486c46664c78626e325a4c4c684332706d5a646c596d6e356566664564553037446c674a58543771524749524b4a6e436931674172677a4f4f564363745962447056656d654f544f7a634f5067316c31797a594e363865574f756445735758582f5a50522f364a2b397a4e7a776776726a73612b6f7a4e393733346c6a764b30432b3435494a6e634979353355634a74765a5058763273414d484470684343425949424d524646313255567a43384a395a446363534c4b63393133496e3163446a4d73306e6f41494246593536494f5647744f57707069664437362b626f6e614764757132746a5549396f64776b2b424f7556693074455635584e306548516a76316e4c59356c45334f623235754e72304f7a334b4577784c2b537448527354326462646653456a45575a536e543845454363594a6f786b6e7a726e4f2f5a31586e582f69755865734a593577427a4d716d4c64505074725935464f725a536446345647486b365273766d7957335a4d6d53733665614d397545556d385036454e66627a327738595633587533765179314b62706937624d466b65396f4b322f5450384954722b69792f315a33712b4f466a47783535494a4f694f377250724b556c776859422b4f5875583571653537485a76746d79377149364c352b63617552786c49774b70426e354a6c3058576a68785050575a433432436a4c64796672465651497370767a43653277534b50516a724156435253495246313058354a2b727565627243724c704f615155464163644c377a584a5075497074355162624b624e2f5843464b77786d4d454775366b793950752f5a7a5a746650776c3147452b427a565069684e35444d4f6657592f4e4f4d79694c7252492f305556674a724c57584c4646594936727a397a53306d4c4534334678383158684f3571715a36357930673645466f4930616336356d615847556b6d6874595a705741596a777348426a692f4674717a3630556e41664e7078776f756c475365777a424e644a4c43594b77384b4c555831586852636c4763346d45644d31506232646732417a703357314f56704d63415a503864675a7056742b54694277496a41694d50674a744e4d4d512f4f322f314452372f79324a62662f43776344764d4848337851765638346f6665515a67675558347634644a6169476e3352546a48316d5364434a7356576554727471315674714c626b69736d4c7279786c6c65636c336637704d46436d4a4b5838687457524d684a2f66364c7a7361313442596c54574f594a77306d7830597a7331576c2b6e507073346f6d3831454c61465273464d544e39744173636d7a6c4f6d5a67465269587349735a577245794d484a6d634c4c4a417034704f354248466d464363354d366338537970703973796a7935464e56454f344868756d7972454d702f705257425959324f6a485577466a55702f70546a726b6764634141696475417a432b345954777276483669657950764e4546516b734f4d63623735364f794a37617958647375626d37736f684a4d42476365627856514173746d547a684f44456d714a506a7662396a764a7935454441583672534d74396a346547764e46564e7366467858703533424f4e4846584d6c627a4977724a6e7a315874773256516a4e794c324f74314446465874427a305465304771672b4d716f453757436a78636e7773447076664a67504a736d373858567571637a6d6a47615a6852374e324b78567a4158326d366972396962534a77636f7964556f425761694a3238596a6c7a4d6677516f3578697477687255757a46507356654133476d632b6233465363387a3036794365356b7352613230453254597135535a754f775173586361564a737366466937784d33786b4739336e656347486e4f31474b4976555a687532546a755363365677484630497a547a66504765304e724d63584778374f37575779373978306e2f772f39534d4843726e70554b6741414141424a52553545726b4a6767673d3d	1	6	\N	#FFFFFF	#875A7B	\N	t	f	f	31	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	20	\N	\N	\N	\N	\N	\N	233	\N	\N	\N	\N	\N	\N	\N	12	\N	\N	\N	\N	round_globally	plain	\N	tax_excluded	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	\N	\N	\N	t	\N	\N	f	\N	t	22	15	31	12	sms	f	t	365	edit	one_step	5000.0	\N	\N	\N	\N	manual	periodic	standard	2	\N	\N	30	\N	\N	\N	t	\N	1	\N	0
2	My US Company	42	1	10	2026-11-03 11:48:14.323106	2/	\N	2	\N	1	1	\N	+1 555-555-5556	Lato	\N	\N	Blank	\N	\N	\N	t	t	2026-11-03 11:48:36.079836	\\x6956424f5277304b47676f414141414e5355684555674141414c514141414177434159414141433437464438414141666b456c455156523432745639655a5255316258336235397a68787036486d6c6f415673454c49526757685448526756466a54696c5347496d6f39456b6d766465346b7679586f61585372313861795676765a65566c3377766d70414a5938416c7052676a47715948564b4b474544764767585a6961756d6d3657366736614747652b385a766a2b36437175624271717170655737613955436d6a35317a396e37642f62353758333232596344384148516d55382b6a7748414173417a2f3836336e5a6e545475585a686a4a745441437377485a327068304b614d637a3759787879435466646a524b4a6f573079387145436867627937537a6970424a396e316e504536796770514664444b72624646414f7a4e48615636424375655a39346769326f6e4d4a312f46475a6e325868457951655a64716b695a71447a486c6e32664b6d42734c476343544b524d4a68496e444941796975796b56344469636858676e6d5977733879377867506d5168544133775046465373547277435a5a4d45734335534a6d544e527a335363434143436e3259725a4752655745776e7378536a6b4a6c715a64706c4656344d6d417456654b474b4d334d55586f684d6a4a786c324333514d724d437763787971456b684d6e6b2f63534941614b4d416853507a7374506453574f6359425946674a6d4e736b4b6e473878474561734f7872444d4b464468587046674c6f526d6e4245344d517159635956616f554b585268706e75304956783473453833686c6f677577586d5035413458536a474b6f56364667506d4e775970774759702f4c685534336d4e6b4567336b305a7936555a716743486342697745796a4f4c4e587045784f74774e34576e4269354d6d465a42474b4f39334f5471356c4c675355624e54594367477a5653416f3379755a6943496d654b45794765397164556267684534785577766c517355344f385536674e6e4246637350692b484d6863686b74434e587a45517442737855424a694c3563786e4845364d6b335379474334304554516a3177453855384763625a664c6d536369396a35657931774d6d4d386f6e504178764d31437542417462467a6f64327a48544361546368794b4b34517a573055364f2b4d4238336843633856736d68546b414459324e767238666a2b7671616c52313135377257787261394d46794b5359545a4e4363544b3633576b7a656a51474679706b536333646571585454444e4f7767393164696a364a4b416b6f466b4172626c67316e6b6f5842646f6d5366536a386a36412f6e4770636537576857446b2f484b7043436355444764314e424549495361516d646450767661534d4962656d5056706c2f38703961616945696652707052714f65654f776e6330387750637a6e7a52506752575444624e31353863334f4a763449445146716d55302f393662472f6e4753732f7a3978356f4a7859685154686c71455258596b456e4766577631555a64415876437370456e2b505243492f694d5669787978324a4249357a75466375584b6c6c55366e6558643374346478624a6f73573761736445704a79456832646d6c5042716938484e6878634d64516132757264774a36346f5858414455506636477976783949384b53754c3630322b6737745438533278314c764d57645745304339736a4952776671677636616934596c796630555651426849396830454d414e41596f78566b343369766f5743756442775a5a5a6d544e522b684656552f44434f75427550786c565451314e66796b304a6148556f476f324f474751304768327245326b41694344436f6f6a71484d716a38346b7a687848574d6351673032796d564b6b4e676449614a725141597859503154533374714a31535351533064466f4e4373554e44633369396257567546622b646e664d364f3070615463455255555a49354f482b6b583769494148546c394741396e4c6d6254784544786d79594d6744527377774d6834516d76416943414b48474b475070454a52704e4a4a697a71785552386b2f4c7a484c6d796b39662b3458666c50724b616833587352696e4479696c42686c345738414f386f364258512f62504e42655531722f62306b6e4b556d4441356f3053484e75734636763831655072332f3077556845733269554b514c773763693347614a4146434d6d78576a4f374146414f4c794778324c4c355233583350584432724a4a583071374b524149706d6d694d3758764d327333504c61797672342b324e33644c57664d6d4b46333764726c334c34342f4c4747594e4e714954316f4464695768514e44375a392f664e4f6a50777548777a775769386e3349633663425571786955594b6746732b74627a79317650756544566742616341684b51377448666c686f666d6a724c513777566e396959497a4d5836566752414767557154694d494c726d33514a75796c704547424945627246517937324a74436e676b742f6b454f615a684c7a41384634797859664f6e415561454771756865646b314878364b52756b524149594731476a72506b595936686956694d57577130676b776c5a756933373936745239317757736b746c4375454a4b5a5653776d76387a663862385a317a4c37612b75726b61344c537a577a6c3162576561722b5a355753696d6c684733367243504a336a2b4d41655a434c54506c574c324a326b677969677a4e76562b3547524f5a39694141654559426e5279654f516b63365750374c6a74712b62677a3445773978353637506945472f337134624f2b646a50474b6779556448624f536c34526431354643535545716b39476e695451304f4f4f387a6d72343956314c372f3861514f44456f5569386339445a3938566e2f76655a5057474565517978334b5652484f655441745165522f72775651632f62357654746845784a70516e532b79794b65644f447a305132377a363635467778497132526456484a6e2f696d3256473562536b6d7841474d3432554742726f5472357a50344551436f5830364a68714f42796d55452f496d464d33522b2f7332556e62734133786546794e5575677843397651304543544a3039575455314e4c42514c36564772444d4c683849694d786c67736c7558617371576c5264585631544541434956434f6a4f784b64495334585071357567595973684d4f426f567276517739716259695a6269592f48696c705957597845574954752b74726f3248597646314367416a5a5543537546776d49563651675141327744453431475a5851484334544339394e4a4c787544676f4e48643353314f4d4d4750665566322f657547316c46726179764479437a4a51674d46783342435263793459776f4c4e59536d586e3352683971504a767332374476382b6a64445a313277326f4f726d544c724447575751304d7a786e676d4d674b74744e54516a42456a67772f4c57576b4e762b314854374c7a795565652f6556746a59324e2f6f364f4475415557584e5a367647784a5a2f366356334a6c4839494f6b6c684d4a4f35326b6e75476e727a676d337844627576762f4c362b56504c5a6d356e326a5155704c4a4e322b684b7648502f34357365665444542f746a4b30397a63724559356c574f394c3674344d7964636c712f46797a342b6e4341464e4f4e6271464d3578626c6830704e516a6953475439384167416948312b6859624c6b383866694f5736324f576652494a4d4c4757455648747a7670633472663434324e4336324f6a75314f4161766a6d4e6d5652703567486a467a49693052413475674e6a322b7964525364784f6f4f30426c5a5146574e744d564c705353344977444448413878324845504b6c6b49474148754363384b4b57304b31773933444f536a70746d515a524e417741705a5862476e5451306c365565713161742b7459564d356463487a524b7a3347464b3071736b704a70397654764575686a6e777a632b774d66443170704e2b6e36624c39314a4e32373966464e6a7a36344a7279474c3438747a31705a33644c5349755078754144416c79315a646c6b7071372f41533666725447346c70656e746562332f35542f47597373374d362b327334494d68554c6c6b36736d583841735377486163464b694b2f376e5461396c7752594f672f66314c4c3745494d4d575568754f53487037392f2f707a78306438454b686b44577059744c466c6d565a576d76535369656a6634712b4d487632374f6f4c7031353575314c69374a51593276666b746a557255647832396f6763373168734f5a706e4e7a664d4f476657356159626e4f473636524b2f50396a62703370652f76334774632f46596a45764641705a625731744c4e63427a41477a38644872506e574449617835556d746d42505465747134584e7364697361354c4c377830567341666d414641434931307838463932336674327555636d366a44337947506b3639687052306b32312f706266335457363973333576546435576e55337a63436d34557734576938616841484a67326256706e6c586a39707253525467664b4b69353068614f46464d49305454506c4a66634f7076712b74362f6a37625537337468785a50486c4e357862727962644665526c587a613561516b7051455145445130433135414b41494c42594c35785a7231753354706a31363564412b644f4f752f4c3036764f665a71424d5563343275612b6d38505833764754674247384b6931537975416d54346e6b554539712f333045776e2f452f6f4e6c64306d626d3574565042345874312f316b6475714176582f786f6a507430776238414d4567745143467870583970312f66664d6a7a37583962365339765832777672376531393364375456556e6a567665766e4d7a61514a50737550772b7a516b77427569375245654451654655656e7a764e4e635a7565394d755347684351776d4350504b396e52736576337453653664564f4c6d6c36707351714c6557635979673939484c4c677059375a39544f57787577676d646233454a5073724d443156694e7730686d39484471705667663435564f316841314c6f532f7066547566772b594a58655a686c6c6c6d435a3055494e413845732f37763751463138646349393850375a783965724d436a6e434d69397475576e68354e4b70442f6c35594c3742544769744962584167696c4c443030762b2b413348433831362b796157662f7365673653336c436974364c7250414437416242494a494a6f4e4b724356332f303167702f336266486b7538567670712b425764642f73694c7535372f31707476766a6c346b6b32365532377873324938397767694441447179732b61576f584a4736617957532f55426963394a4b54514672664d7445793874694d64767953326566585071365a5654627674317474754f61494f44713365384f742f37657276754555706d57534d363246584d614d4854515141482f2f34782f50654e476c746265587a367563462f2f4463302b754f4f6b642b62746b3256306f707867782f6e612f7876737952546d30594a7539334433316e59337a6a472b664d4f4d6475525773577a4c4b317464554c332f4352723953584e543568632f39384b456a50636157554171357749447a68576d525631766f612f72466c39744b744330494c61712b3838736f30414243524a6e444e796651597544615a4f614c76626b71517751795877445670726a6b7a584e50484e51417778725442544a6542613631494738776f6e56593136374553712b78737a334d68704143424461436b49456375522f455245596c455250506935764b72617a2b3773625a6b306c634d5a6c524a543771753530424b41646431704a4a612b466c676272322f6364587456332f737578306448616c494a4b4c44345443505271507168705962356b38706d62362b684a664f4635346e553237536354784861365668614c756d4b6c43376f7161302f714f6535796b2b4c4175584d5a5a6479566b30476c584c622f7a6f50396557546c6c374d766e573251332f75504473526473756e3339357259592b687245543049775472754473464848486b784a305133466d6b622f637834496c70725a7349675a584f364a33734f4d7a723231357266754f4f2b35346250723036613331395a505758686936384b337762654576726e762b695438636358742f61426f476733353361534569565944436a6d3051764e4c396968754a614859672f644c584270332b64797a44346c6f7235516c58515774706d7a342b6b447179666333477a682b46516d4672313635644c4d4f5a5a577472713766736d747357567874542f6c4d4c6b6f354943394d307555754f546a694a50593549487a4a4e30394a61492b6b4d755657426d766b7a7035322f49754e455a61636961536a53304b53684351446d314d3352414843304d32466f725269676166677a306d66523041516945744b447763326d636e2f567a495133674c5249376b3036513373636d5235414541714650353757333948526146544e346e502f70387173767a7a704a46796c6c545a4d77307172314a476b6b396a74777447326152757563495551516b3471612f7a57725576447430616a555a56782f6e694e37367948676d5a706564704c6579426974756d7a5065556b457537513370524d774f592b2b486c7769745343514342415565354b7675796132785a5838636e2f4e554b2b63444261766f6e306b467670722f6e6739495a7a66304848753361354f64346e5455686a4a77437a7a48386258416d7068565a51776a4a4d356b726e62372b502f2f3746634468386630314e7a58494155696b704c4e734b6c7061582f6d6a4a6b69764f5074527a344b47306d784c45474d2f2f464e4b5963556350674e665774707a69385a6550396f6e752b3458324642454252455445794a5870524f3951782b6542754468382b49395a436956656650464641594171724b71495252616b3971545039426b4a5a334262682f663268513976664f6744667a6d386257353338734144697054446942744a4e796e4b7a657162506e54357a56646e4a7547595a7a4a333975776b414e775a386e6965356c5278346a715248747a664b7a715872747a2b302b61662f2b4848462b7738384e49746144756d504a326e6264616f68695969766653614479306f73636f2f6b585a53676f674d496f612b5a4f383358753766506e666c786f632b73442b783734492b352f417a6c6d455a556b764e4e4e4e6c756a714b454b786f50437075767537324b344a32634b486a70695152475977784f707a712b652f647956317a483337687077733633583158444b6d2b485a7734534939686b5051492b53716636544f473067507866656e584c38724b747a66522b53575a493938797333725a6a53323374305152565a6b49555462736d4e66425a7a59475a79346b4732705972634d624e434169704654697255676b776f4c42306d7530316b4a72725141597275734b6e393948566257544c396e7938705a4f7a56552f41344f6d676841394f74744f5a6b4a68636b313444662f647869665770647a554d375a704d326a745771624e4270796a5033336d2b5764656e6c632f4c35674a4a336b52524451523655756272326f7934622f594559376d7a4c5153597544676e77382f3965474e477a652b544552446258397436346c742b7530502b37322b4279335459744351426a4e3164556e394c5144417552347a5372547572585557414737364441565158754d6a42756f6533503950543231597536463552764d5167494858586e75742b31524752516e467369744439716c5577336f74522f574e5068364167704b6d5962462b722f6358717a65742f4e354c4c3778304942774f707a66466e336e7474322f3934754d706d57673375575734776c552b7778634b4e3335364c6741455a4d6d314a7265314a69307377364a425a2b444a3152742b39655634664d4d374d775a6e444b3366764f36357664317633757a434f63675a5a7a7244494331544d6742592b4d475763334c6b61777835417a33787a72556632624a6c79393879386a3334324f5a565030724b2f7638375172372b366c73426f484a505a634535336979484d78643655424765634563346c566f44706d6c5752614e524a5431765032504d55456f70726256676a476d744e66556636652b635654327246416f2b6e5766634d4a384d735a30394f306c446b342f374f346749424767696743757a55304f5455434a7230565662754930416f4c51696344626e7a4e526153394d7734626e792b54662b657544777666662b7a4e526157395856316346774f4d775070512f2b50693153494d7273656b71614467416b523449314336795553444541737254654c2b675551395261677a4f444a357a456f5a64372f72596a4841377a31745a576c624d7a65394a48657449632f624f2b724a4667616f62574771534a74465a494a314a72772b45776e7a5a746d69385769316d7a5a7330717852373044346d424c515933414b326c795333754a62787047544c56704a556d3069436c466671474471324d5243497346416f46646d475864322f7a76576238722f47446732376642734d774b6573524b575554414652552b4a73345a3661476c715a686b75654a352f612b31744d6469577731744e6255334e787368734e6833705075666a6f74556d4245772f524d736d6b5a4f6d6d67774950504445556b58626468474242435370366a5453615667453848466c78303055566c76516436667a77774d4e415444415a743237594e76393976397666336231792f666e32386165377347797a7543306f6c46444c4f5941475a5869656371515453476d7145677155534e6f48306e4e6f3578314d6f41676349325178425273776c45463535397463474147355a6c67514172725372316274695564414d414f536f7a454b744e4e665156476158535143712b6342486958753254304f64464a6e454346446f3733693759794154713831474e505170644d637a5559305430512b65773046424941454179575453414b446e38586d4f317071306642637347674452734634315a5856446c447468703036644f6f7954357177385472683263774b42394c43634f484748514d4332625143676d357161464143514545497266657a376c565963414a4a65737542645559615236593535426256335949634a414a7978584b654f70425453623562554e6c576339373331573966766675667464793770367a7636594371522b6c3133562f63335636396576585471334b6d566453583133325a676f507957593561765135447069523470314f452b686d70443732344944653851496e476f66372b5355674977704251676a6f733074483937782f5a3051304d44335454354f31347346704d3176736b7466697349614169414e4f506f4241426e4b4a465353696f4154476b4654586f4b6766523135337a504136423339473272306c6f46744e62365a463549646a494253464a2b613959786d5443546561506c574a5564753051374d644b6174474c457757787a635377576b314f4e7161713575566e47326d4975456148454c4c31434b674741754e53654e6f4b735978686f72494d78706a56424d57496f72796a2f524451615665765872336549534b395973634a62734b426c55706c56635a3051336a4854784a696a4161442f63482b586c464b436875554c70692f573047593048685868634a694873515a6a7974665158514251366173737544424f556164755862674d41417a44457054626a6f69356e714d713764723737726a754c72647a2f2b352f2b38317a44392b662f65386c6c79365a33314231396b394b575558494661346d4967353930704255735565453368306c343865316955616a576b5054386e507054533978667075504238353352466f4572624a7a506e37395a783538592f637258323139712f585169713750345a596c74313866744d752b35673176424847704252314a6454384c414a37482b68695949434c4c45363471395a5664635033567479364a62726c71453662423131513937527557615675653845516d566666646c554e4968754b65455834454e3438663335484d6e77354c622f53452b793845346b4a3675697051632f394e5639332b38744e626e33674d5856424e5455336c433264642b56322f57584b654a7831686370734e65663137642b37662f436f414b4f357445394a376744514d56376936677456382b424e4c372f3742776348324832312b66764f52705974764f722f656e767a664e766b6d75644b56426a6547633749643067426f7439373939726d592b37715042304b4f534d735375377a706b7a66652f64416275312f356c316773646a6747476c4f2b50554d484e674a413355563148746f4c7937597a696b6b677357437058413659303534415455704a566532722f5a4a766575426a6a644f622f757734626d2b705654616277376a5978774b574b394b4b694c456337716e4873457a464a745563372f5750595261586835667a57417779664f334139387439356175343546703472717930367536633333544a6452664d764853506b7271554d7a62504a417565384e79414862434f70412f74324e503739724d416f63787664796c53523031516a64414b444e7963346d7438387535627674437130706a6b5934475a536d6f412b72686f682b666d6e55647a4d706d4d2f527942496843653342546239736b6237746c53626464646e55675075515933537159457036322b612b6c3958326347473951535a2f6b732f316d6563425742613234776c6b774e2f466462572b2f516d7641617676796c3552732f325854504b35582b6d6e6c704c2b55704b4b5053562f754153623537506e33747562324777632f323877423530674e6f3242386a55485a735a76637233596e45704948766c2f73726673736c6c384a7a5a626c5a632f6538365266663849455a433865576236713339665839723633543045537876454b3549337772566b773256447675644148415a2f68546e48474c68694d64476434335044746434516f66393964586d2f573354433664656b2b4a565861467953334c6b36346759746d644945314579694344484a34576f35595071786a4c724a57436868596145427061354d61365279554a795167694c4c5a783965704441373072664a62665a4d7a6772756534706d4533324d78336d632f777a325067516b6f704133625147704c3942377259336a766232747263652b2b397831792f592f31415176552f343750394445536556454a774d6f4f324c4c6d79784b36594b5348674b586541774d56776e37547730704979686f43512b5a6d4746675174437152654f544c4a2f5a353338366f4a55416348393331324d4e33664876435657464a4a7062583266475a77727333386c31726350737354777548456d632f326d623375775564696d34657a454c2b363436736d6473487253757a2f5846494d3966744d76366d31316f376e4f44617a53344a32734d6e48417551704430704c6b577551704a4163674e6653306d49387676485256596348442f3030482f6b4f7976367544757a2b64487437653572776e58794f394932653449495643756268686c4556695554596f6c735776705077426e3844306c416b4f556a5473512f5468744175556a4b466c4a654149394f516b414454527537764b564b6d49394c7559504c6f547746673362703175576d4c65547345322f5a747937597039317342772b4a6d6964384b4749414f6e71684e464645645173686176666c583933556d396e33646f33535062666b73693573674d44444734444e39426e48775075665168726454727933612f4f7a6d313445775837466942514e433170346a62333737634b4b3331572f3762647630475a5a6877754163726b37705876484f767961397762664b4175576d7a2f515a424b6f39306a356f355469787458347259506974674b474a61764945383469454b4b303036647a764157714848516d4e387843794e7631703037366442313963334364366677656d6d573336544d3459434177474e2b457a626475443133647761482f6b3057645733686c42424c46596a4c573374364f78736448652f507a36375231442b35594f75514e2f595a7778762b577a4c644d697a6a6b3853716536427a752b4c715238316554445551344672615357486741646a3864564242473261744d76763943563350653155386e3339594758727436365965744f494d4b41714d71484d343832656c51346d48507078664466463763735865697a6a45717475527132506f7145454962576d6a6a6e6b6e506a68425a576b57534a517750372f766a53483139483861637165414d6137433530756663732f59664c417236536d5936586c4c595a3450314468376576334c7a6931524e6b736d57322b47636f594a637a2b34725a4452665943323955576a567a6d39564c49644d576647386b76503574613765752b574e4f316c69754d2b3067684a4937476a397a68344b2b684c677567364339536570622b39544770313734314858334c43757a4b2b7339346245452b70302f3748377169634e76486b374d6d7a665050332f4b5a626558734b444e4f45504b545237393566722f6558774d71335279366a554439716562507666686f4b38304144416b334d5467772b742f6b763065733647686758563164535542344b62464e793073513930316b72775173356c667074516867396c2f662b5049333961317472612b5179426f3642475655567461576e676d6351764c7272747463616d717573427a6e5772444d727137784c364e5737647533586e6e64666674446c6a424a6b416a365359365632352f36487a30342b6937474e45456b42354c766c796262772b4b76766a5457352f636b7050496c412b5943385a4a64752f636e2b4f456e4c616e425331474a7258536835486c46664c78626e325a4c4c684332706d5a646c596d6e356566664564553037446c674a58543771524749524b4a6e436931674172677a4f4f564363745962447056656d654f544f7a634f5067316c31797a594e363865574f756445735758582f5a50522f364a2b397a4e7a776776726a73612b6f7a4e393733346c6a764b30432b3435494a6e634979353355634a74765a5058763273414d484470684343425949424d524646313255567a43384a395a446363534c4b63393133496e3163446a4d73306e6f41494246593536494f5647744f57707069664437362b626f6e614764757132746a5549396f64776b2b424f7556693074455635584e306548516a76316e4c59356c45334f623235754e72304f7a334b4577784c2b537448527354326462646653456a45575a536e543845454363594a6f786b6e7a726e4f2f5a31586e582f69755865734a593577427a4d716d4c64505074725935464f725a536446345647486b365273766d7957335a4d6d53733665614d397545556d385036454e66627a327738595633587533765179314b62706937624d466b65396f4b322f5450384954722b69792f315a33712b4f466a47783535494a4f694f377250724b556c776859422b4f5875583571653537485a76746d79377149364c352b63617552786c49774b70426e354a6c3058576a68785050575a433432436a4c64796672465651497370767a43653277534b50516a724156435253495246313058354a2b727565627243724c704f615155464163644c377a584a5075497074355162624b624e2f5843464b77786d4d454775366b793950752f5a7a5a746650776c3147452b427a565069684e35444d4f6657592f4e4f4d79694c7252492f305556674a724c57584c4646594936727a397a53306d4c4534334678383158684f3571715a36357930673645466f4930616336356d615847556b6d6874595a705741596a777348426a692f4674717a3630556e41664e7078776f756c475365777a424e644a4c43594b77384b4c555831586852636c4763346d45644d31506232646732417a703357314f56704d63415a503864675a7056742b54694277496a41694d50674a744e4d4d512f4f322f314452372f79324a62662f43776344764d4848337851765638346f6665515a67675558347634644a6169476e3352546a48316d5364434a7356576554727471315674714c626b69736d4c7279786c6c65636c336637704d46436d4a4b5838687457524d684a2f66364c7a7361313442596c54574f594a77306d7830597a7331576c2b6e507073346f6d3831454c61465273464d544e39744173636d7a6c4f6d5a67465269587349735a577245794d484a6d634c4c4a417034704f354248466d464363354d366338537970703973796a7935464e56454f344868756d7972454d702f705257425959324f6a485577466a55702f70546a726b6764634141696475417a432b345954777276483669657950764e4546516b734f4d63623735364f794a37617958647375626d37736f684a4d42476365627856514173746d547a684f44456d714a506a7662396a764a7935454441583672534d74396a346547764e46564e7366467858703533424f4e4846584d6c627a4977724a6e7a315874773256516a4e794c324f74314446465874427a305465304771672b4d716f453757436a78636e7773447076664a67504a736d373858567571637a6d6a47615a6852374e324b78567a4158326d366972396962534a77636f7964556f425761694a3238596a6c7a4d6677516f3578697477687255757a46507356654133476d632b6233465363387a3036794365356b7352613230453254597135535a754f775173586361564a737366466937784d33786b4739336e656347486e4f31474b4976555a687532546a755363365677484630497a547a66504765304e724d63584778374f37575779373978306e2f772f39534d4843726e70554b6741414141424a52553545726b4a6767673d3d	1	2	\N	#FFFFFF	#875A7B	\N	t	\N	\N	31	155	92	142	154	93	141	17	40	\N	10	91	143	\N	2	\N	53	\N	\N	\N	3	233	11	\N	\N	\N	90	140	\N	12	us	1014	1015	1017	round_globally	plain	\N	tax_excluded	\N	\N	\N	\N	\N	\N	\N	\N	t	t	\N	\N	\N	t	\N	\N	f	\N	t	10	15	31	12	sms	\N	t	365	edit	one_step	5000.0	14	54	\N	\N	manual	periodic	standard	2	\N	\N	30	\N	\N	\N	t	\N	1	\N	0
1	My Company (San Francisco)	1	1	\N	2026-11-03 11:48:09.907963	1/	\N	2	\N	\N	1	info@yourcompany.com	+1 555-555-5556	Lato	\N	\N	Blank	\N	\N	\N	t	t	2026-11-03 11:48:37.287963	\\x6956424f5277304b47676f414141414e5355684555674141414c514141414177434159414141433437464438414141666b456c455156523432745639655a5255316258336235397a68787036486d6c6f415673454c49526757685448526756466a54696c5347496d6f39456b6d766465346b7679586f61585372313861795676765a65566c3377766d70414a5938416c7052676a47715948564b4b474544764767585a6961756d6d3657366736614747652b385a766a2b36437175624271717170655737613955436d6a35317a396e37642f62353758333232596344384148516d55382b6a7748414173417a2f3836336e5a6e545475585a686a4a745441437377485a327068304b614d637a3759787879435466646a524b4a6f573079387145436867627937537a6970424a396e316e504536796770514664444b72624646414f7a4e48615636424375655a39346769326f6e4d4a312f46475a6e325868457951655a64716b695a71447a486c6e32664b6d42734c476343544b524d4a68496e444941796975796b56344469636858676e6d5977733879377867506d5168544133775046465373547277435a5a4d45734335534a6d544e527a335363434143436e3259725a4752655745776e7378536a6b4a6c715a64706c4656344d6d417456654b474b4d334d55586f684d6a4a786c324333514d724d437763787971456b684d6e6b2f63534941614b4d416853507a7374506453574f6359425946674a6d4e736b4b6e473878474561734f7872444d4b464468587046674c6f526d6e4245344d517159635956616f554b585268706e75304956783473453833686c6f677577586d5035413458536a474b6f56364667506d4e775970774759702f4c685534336d4e6b4567336b305a7936555a716743486342697745796a4f4c4e587045784f74774e34576e4269354d6d465a42474b4f39334f5471356c4c675355624e54594367477a5653416f3379755a6943496d654b45794765397164556267684534785577766c517355344f385536674e6e4246637350692b484d6863686b74434e587a45517442737855424a694c3563786e4845364d6b335379474334304554516a3177453855384763625a664c6d536369396a35657931774d6d4d386f6e504178764d31437542417462467a6f64327a48544361546368794b4b34517a573055364f2b4d4238336843633856736d68546b414459324e767238666a2b7671616c52313135377257787261394d46794b5359545a4e4363544b3633576b7a656a51474679706b536333646571585454444e4f7767393164696a364a4b416b6f466b4172626c67316e6b6f5842646f6d5366536a386a36412f6e4770636537576857446b2f484b7043436355444764314e424549495361516d646450767661534d4962656d5056706c2f38703961616945696652707052714f65654f776e6330387750637a6e7a52506752575444624e31353863334f4a763449445146716d55302f393662472f6e4753732f7a3978356f4a7859685154686c71455258596b456e4766577631555a64415876437370456e2b505243492f694d5669787978324a4249357a75466375584b6c6c55366e6558643374346478624a6f73573761736445704a79456832646d6c5042716938484e6878634d64516132757264774a36346f5858414455506636477976783949384b53754c3630322b6737745438533278314c764d57645745304339736a4952776671677636616934596c796630555651426849396830454d414e41596f78566b343369766f5743756442775a5a5a6d544e522b684656552f44434f75427550786c565451314e66796b304a6148556f476f324f474751304768327245326b41694344436f6f6a71484d716a38346b7a687848574d6351673032796d564b6b4e676449614a725141597859503154533374714a31535351533064466f4e4373554e44633369396257567546622b646e664d364f3070615463455255555a49354f482b6b583769494148546c394741396e4c6d6254784544786d79594d6744527377774d6834516d76416943414b48474b475070454a52704e4a4a697a71785552386b2f4c7a484c6d796b39662b3458666c50724b616833587352696e4479696c42686c345738414f386f364258512f62504e42655531722f62306b6e4b556d4441356f3053484e75734636763831655072332f3077556845733269554b514c773763693347614a4146434d6d78576a4f374146414f4c794778324c4c355233583350584432724a4a583071374b524149706d6d694d3758764d327333504c61797672342b324e33644c57664d6d4b46333764726c334c34342f4c4747594e4e714954316f4464695768514e44375a392f664e4f6a50777548777a775769386e3349633663425571786955594b6746732b74627a79317650756544566742616341684b51377448666c686f666d6a724c513777566e396959497a4d5836566752414767557154694d494c726d33514a75796c704547424945627246517937324a74436e676b742f6b454f615a684c7a41384634797859664f6e415561454771756865646b314878364b52756b524149594731476a72506b595936686956694d57577130676b776c5a756933373936745239317757736b746c4375454a4b5a5653776d76387a663862385a317a4c37612b75726b61344c537a577a6c3162576561722b5a355753696d6c684733367243504a336a2b4d41655a434c54506c574c324a326b677969677a4e76562b3547524f5a39694141654559426e5279654f516b63365750374c6a74712b62677a3445773978353637506945472f337134624f2b646a50474b6779556448624f536c34526431354643535545716b39476e695451304f4f4f387a6d72343956314c372f3861514f44456f5569386339445a3938566e2f76655a5057474565517978334b5652484f655441745165522f72775651632f62357654746845784a70516e532b79794b65644f447a305132377a363635467778497132526456484a6e2f696d3256473562536b6d7841474d3432554742726f5472357a50344551436f5830364a68714f42796d55452f496d464d33522b2f7332556e62734133786546794e5575677843397651304543544a3039575455314e4c42514c36564772444d4c683849694d786c67736c7558617371576c5264585631544541434956434f6a4f784b64495334585071357567595973684d4f426f567276517739716259695a6269592f48696c705957597845574954752b74726f3248597646314367416a5a5543537546776d49563651675141327744453431475a5851484334544339394e4a4c787544676f4e48643353314f4d4d4750665566322f657547316c46726179764479437a4a51674d46783342435263793459776f4c4e59536d586e3352683971504a767332374476382b6a64445a313277326f4f726d544c724447575751304d7a786e676d4d674b74744e54516a42456a67772f4c57576b4e762b314854374c7a795565652f6556746a59324e2f6f364f4475415557584e5a367647784a5a2f366356334a6c4839494f6b6c684d4a4f35326b6e75476e727a676d337844627576762f4c362b56504c5a6d356e326a5155704c4a4e322b684b7648502f34357365665444542f746a4b30397a63724559356c574f394c3674344d7964636c712f46797a342b6e4341464e4f4e6271464d3578626c6830704e516a6953475439384167416948312b6859624c6b383866694f5736324f576652494a4d4c4757455648747a7670633472663434324e4336324f6a75314f4161766a6d4e6d5652703567486a467a49693052413475674e6a322b7964525364784f6f4f30426c5a5146574e744d564c705353344977444448413878324845504b6c6b49474148754363384b4b57304b31773933444f536a70746d515a524e417741705a5862476e5451306c365565713161742b7459564d356463487a524b7a3347464b3071736b704a70397654764575686a6e777a632b774d66443170704e2b6e36624c39314a4e32373966464e6a7a36344a7279474c3438747a31705a33644c5349755078754144416c79315a646c6b7071372f41533666725447346c70656e746562332f35542f47597373374d362b327334494d68554c6c6b36736d583841735377486163464b694b2f376e5461396c7752594f672f66314c4c3745494d4d575568754f53487037392f2f707a78306438454b686b44577059744c466c6d565a576d76535369656a6634712b4d487632374f6f4c7031353575314c69374a51593276666b746a557255647832396f6763373168734f5a706e4e7a664d4f476657356159626e4f473636524b2f50396a62703370652f76334774632f46596a45764641705a625731744c4e63427a41477a38644872506e574449617835556d746d42505465747134584e7364697361354c4c377830567341666d414641434931307838463932336674327555636d366a44337947506b3639687052306b32312f706266335457363973333576546435576e55337a63436d34557734576938616841484a67326256706e6c586a39707253525467664b4b69353068614f46464d49305454506c4a66634f7076712b74362f6a37625537337468785a50486c4e357862727962644665526c587a613561516b7051455145445130433135414b41494c42594c35785a7231753354706a31363564412b644f4f752f4c3036764f665a71424d5563343275612b6d38505833764754674247384b6931537975416d54346e6b554539712f333045776e2f452f6f4e6c64306d626d3574565042345874312f316b6475714176582f786f6a507430776238414d4567745143467870583970312f66664d6a7a37583962365339765832777672376531393364375456556e6a567665766e4d7a61514a50737550772b7a516b77427569375245654451654655656e7a764e4e635a7565394d755347684351776d4350504b396e52736576337453653664564f4c6d6c36707351714c6557635979673939484c4c677059375a39544f57787577676d646233454a5073724d443156694e7730686d39484471705667663435564f316841314c6f532f7066547566772b594a58655a686c6c6c6d435a3055494e413845732f37763751463138646349393850375a783965724d436a6e434d69397475576e68354e4b70442f6c35594c3742544769744962584167696c4c443030762b2b413348433831362b796157662f7365673653336c436974364c7250414437416242494a494a6f4e4b724356332f303167702f336266486b7538567670712b425764642f73694c7535372f31707476766a6c346b6b32365532377873324938397767694441447179732b61576f584a4736617957532f55426963394a4b54514672664d7445793874694d64767953326566585071365a5654627674317474754f61494f44713365384f742f37657276754555706d57534d363246584d614d4854515141482f2f34782f50654e476c746265587a367563462f2f4463302b754f4f6b642b62746b3256306f707867782f6e612f7876737952546d30594a7539334433316e59337a6a472b664d4f4d6475525773577a4c4b317464554c332f4352723953584e543568632f39384b456a50636157554171357749447a68576d525631766f612f72466c39744b744330494c61712b3838736f30414243524a6e444e796651597544615a4f614c76626b71517751795877445670726a6b7a584e50484e51417778725442544a6542613631494738776f6e56593136374553712b78737a334d68704143424461436b49456375522f455245596c455250506935764b72617a2b3773625a6b306c634d5a6c524a543771753530424b41646431704a4a612b466c676272322f6364587456332f737578306448616c494a4b4c44345443505271507168705962356b38706d62362b684a664f4635346e553237536354784861365668614c756d4b6c43376f7161302f714f6535796b2b4c4175584d5a5a6479566b30476c584c622f7a6f50396557546c6c374d766e573251332f75504473526473756e3339357259592b687245543049775472754473464848486b784a305133466d6b622f637834496c70725a7349675a584f364a33734f4d7a723231357266754f4f2b35346250723036613331395a505758686936384b337762654576726e762b695438636358742f61426f476733353361534569565944436a6d3051764e4c396968754a614859672f644c584270332b64797a44346c6f7235516c58515774706d7a342b6b447179666333477a682b46516d4672313635644c4d4f5a5a577472713766736d747357567874542f6c4d4c6b6f354943394d307555754f546a694a50593549487a4a4e30394a61492b6b4d755657426d766b7a7035322f49754e455a61636961536a53304b53684351446d314d3352414843304d32466f725269676166677a306d66523041516945744b447763326d636e2f567a495133674c5249376b3036513373636d5235414541714650353757333948526146544e346e502f70387173767a7a704a46796c6c545a4d77307172314a476b6b396a74777447326152757563495551516b3471612f7a57725576447430616a555a56782f6e694e37367948676d5a706564704c6579426974756d7a5065556b457537513370524d774f592b2b486c7769745343514342415565354b7675796132785a5838636e2f4e554b2b63444261766f6e306b467670722f6e6739495a7a66304848753361354f64346e5455686a4a77437a7a48386258416d7068565a51776a4a4d356b726e62372b502f2f3746634468386630314e7a58494155696b704c4e734b6c7061582f6d6a4a6b69764f5074527a344b47306d784c45474d2f2f464e4b5963556350674e665774707a69385a6550396f6e752b3458324642454252455445794a5870524f3951782b6542754468382b49395a436956656650464641594171724b71495252616b3971545039426b4a5a334262682f663268513976664f6744667a6d386257353338734144697054446942744a4e796e4b7a657162506e54357a56646e4a7547595a7a4a333975776b414e775a386e6965356c5278346a715248747a664b7a715872747a2b302b61662f2b4848462b7738384e49746144756d504a326e6264616f68695969766653614479306f73636f2f6b585a53676f674d496f612b5a4f383358753766506e666c786f632b73442b783734492b352f417a6c6d455a556b764e4e4e4e6c756a714b454b786f50437075767537324b344a32634b486a70695152475977784f707a712b652f647956317a483337687077733633583158444b6d2b485a7734534939686b5051492b53716636544f473067507866656e584c38724b747a66522b53575a493938797333725a6a53323374305152565a6b49555462736d4e66425a7a59475a79346b4732705972634d624e434169704654697255676b776f4c42306d7530316b4a72725141597275734b6e393948566257544c396e7938705a4f7a56552f41344f6d676841394f74744f5a6b4a68636b313444662f647869665770647a554d375a704d326a745771624e4270796a5033336d2b5764656e6c632f4c35674a4a336b52524451523655756272326f7934622f594559376d7a4c5153597544676e77382f3965474e477a652b544552446258397436346c742b7530502b37322b4279335459744351426a4e3164556e394c5144417552347a5372547572585557414737364441565158754d6a42756f6533503950543231597536463552764d5167494858586e75742b31524752516e467369744439716c5577336f74522f574e5068364167704b6d5962462b722f6358717a65742f4e354c4c3778304942774f707a66466e336e7474322f3934754d706d57673375575734776c552b7778634b4e3335364c6741455a4d6d314a7265314a69307377364a425a2b444a3152742b39655634664d4d374d775a6e444b3366764f36357664317633757a434f63675a5a7a7244494331544d6742592b4d475763334c6b61777835417a33787a72556632624a6c79393879386a3334324f5a565030724b2f7638375172372b366c73426f484a505a634535336979484d78643655424765634563346c566f44706d6c5752614e524a5431765032504d55456f70726256676a476d744e66556636652b635654327246416f2b6e5766634d4a384d735a30394f306c446b342f374f346749424767696743757a55304f5455434a7230565662754930416f4c51696344626e7a4e526153394d7734626e792b54662b657544777666662b7a4e526157395856316346774f4d775070512f2b50693153494d7273656b71614467416b523449314336795553444541737254654c2b675551395261677a4f444a357a456f5a64372f72596a4841377a31745a576c624d7a65394a48657449632f624f2b724a4667616f62574771534a74465a494a314a72772b45776e7a5a746d69385769316d7a5a7330717852373044346d424c515933414b326c795333754a62787047544c56704a556d3069436c466671474471324d5243497346416f46646d475864322f7a76576238722f47446732376642734d774b6573524b575554414652552b4a73345a3661476c715a686b75654a352f612b31744d6469577731744e6255334e787368734e6833705075666a6f74556d4245772f524d736d6b5a4f6d6d67774950504445556b58626468474242435370366a5453615667453848466c78303055566c76516436667a77774d4e415444415a743237594e76393976397666336231792f666e32386165377347797a7543306f6c46444c4f5941475a5869656371515453476d7145677155534e6f48306e4e6f3578314d6f41676349325178425273776c45463535397463474147355a6c67514172725372316274695564414d414f536f7a454b744e4e665156476158535143712b6342486958753254304f64464a6e454346446f3733693759794154713831474e505170644d637a5559305430512b65773046424941454179575453414b446e38586d4f317071306642637347674452734634315a5856446c447468703036644f6f7954357177385472683263774b42394c43634f484748514d4332625143676d357161464143514545497266657a376c565963414a4a65737542645559615236593535426256335949634a414a7978584b654f70425453623562554e6c576339373331573966766675667464793770367a7636594371522b6c3133562f63335636396576585471334b6d566453583133325a676f507957593561765135447069523470314f452b686d70443732344944653851496e476f66372b5355674977704251676a6f733074483937782f5a3051304d44335454354f31347346704d3176736b7466697349614169414e4f506f4241426e4b4a465353696f4154476b4654586f4b6766523135337a504136423339473272306c6f46744e62365a463549646a494253464a2b613959786d5443546561506c574a5564753051374d644b6174474c457757787a635377576b314f4e7161713575566e47326d4975456148454c4c31434b674741754e53654e6f4b735978686f72494d78706a56424d57496f72796a2f524451615665765872336549534b395973634a62734b426c55706c56635a3051336a4854784a696a4161442f63482b586c464b436875554c70692f573047593048685868634a694873515a6a7974665158514251366173737544424f556164755862674d41417a44457054626a6f69356e714d713764723737726a754c72647a2f2b352f2b38317a44392b662f65386c6c79365a33314231396b394b575558494661346d4967353930704255735565453368306c343865316955616a576b5054386e507054533978667075504238353352466f4572624a7a506e37395a783538592f637258323139712f585169713750345a596c74313866744d752b35673176424847704252314a6454384c414a37482b68695949434c4c45363471395a5664635033567479364a62726c71453662423131513937527557615675653845516d566666646c554e4968754b65455834454e3438663335484d6e77354c622f53452b793845346b4a3675697051632f394e5639332b38744e626e33674d5856424e5455336c433264642b56322f57584b654a7831686370734e65663137642b37662f436f414b4f357445394a376744514d56376936677456382b424e4c372f3742776348324832312b66764f52705974764f722f656e767a664e766b6d75644b56426a6547633749643067426f7439373939726d592b37715042304b4f534d735375377a706b7a66652f64416275312f356c316773646a6747476c4f2b50554d484e674a413355563148746f4c7937597a696b6b677357437058413659303534415455704a566532722f5a4a766575426a6a644f622f757734626d2b705654616277376a5978774b574b394b4b694c456337716e4873457a464a745563372f5750595261586835667a57417779664f334139387439356175343546703472717930367536633333544a6452664d764853506b7271554d7a62504a417565384e79414862434f70412f74324e503739724d416f63787664796c53523031516a64414b444e7963346d7438387535627674437130706a6b5934475a536d6f412b72686f682b666d6e55647a4d706d4d2f527942496843653342546239736b6237746c53626464646e55675075515933537159457036322b612b6c3958326347473951535a2f6b732f316d6563425742613234776c6b774e2f466462572b2f516d7641617676796c3552732f325854504b35582b6d6e6c704c2b55704b4b5053562f754153623537506e33747562324777632f323877423530674e6f3242386a55485a735a76637233596e45704948766c2f73726673736c6c384a7a5a626c5a632f6538365266663849455a433865576236713339665839723633543045537876454b3549337772566b773256447675644148415a2f68546e48474c68694d64476434335044746434516f66393964586d2f573354433664656b2b4a565861467953334c6b36346759746d644945314579694344484a34576f35595071786a4c724a57436868596145427061354d61365279554a795167694c4c5a783965704441373072664a62665a4d7a6772756534706d4533324d78336d632f777a325067516b6f704133625147704c3942377259336a766232747263652b2b397831792f592f31415176552f343750394445536556454a774d6f4f324c4c6d79784b36594b5348674b586541774d56776e37547730704979686f43512b5a6d4746675174437152654f544c4a2f5a353338366f4a55416348393331324d4e33664876435657464a4a7062583266475a77727333386c31726350737354777548456d632f326d623375775564696d34657a454c2b363436736d6473487253757a2f5846494d3966744d76366d31316f376e4f44617a53344a32734d6e48417551704430704c6b577551704a4163674e6653306d49387676485256596348442f3030482f6b4f7976367544757a2b64487437653572776e58794f394932653449495643756268686c4556695554596f6c735776705077426e3844306c416b4f556a5473512f5468744175556a4b466c4a654149394f516b414454527537764b564b6d49394c7559504c6f547746673362703175576d4c65547345322f5a747937597039317342772b4a6d6964384b4749414f6e71684e464645645173686176666c583933556d396e33646f33535062666b73693573674d44444734444e39426e48775075665168726454727933612f4f7a6d313445775837466942514e433170346a62333737634b4b3331572f3762647630475a5a6877754163726b37705876484f767961397762664b4175576d7a2f515a424b6f39306a356f355469787458347259506974674b474a61764945383469454b4b303036647a764157714848516d4e387843794e7631703037366442313963334364366677656d6d573336544d3459434177474e2b457a626475443133647761482f6b3057645733686c42424c46596a4c573374364f78736448652f507a36375231442b35594f75514e2f595a7778762b577a4c644d697a6a6b3853716536427a752b4c715238316554445551344672615357486741646a3864564242473261744d76763943563350653155386e3339594758727436365965744f494d4b41714d71484d343832656c51346d48507078664466463763735865697a6a45717475527132506f7145454962576d6a6a6e6b6e506a68425a576b57534a517750372f766a53483139483861637165414d6137433530756663732f59664c417236536d5936586c4c595a3450314468376576334c7a6931524e6b736d57322b47636f594a637a2b34725a4452665943323955576a567a6d39564c49644d576647386b76503574613765752b574e4f316c69754d2b3067684a4937476a397a68344b2b684c677567364339536570622b39544770313734314858334c43757a4b2b7339346245452b70302f3748377169634e76486b374d6d7a665050332f4b5a626558734b444e4f45504b545237393566722f6558774d71335279366a554439716562507666686f4b38304144416b334d5467772b742f6b763065733647686758563164535542344b62464e793073513930316b72775173356c667074516867396c2f662b5049333961317472612b5179426f3642475655567461576e676d6351764c7272747463616d717573427a6e5772444d727137784c364e5737647533586e6e64666674446c6a424a6b416a365359365632352f36487a30342b6937474e45456b42354c766c796262772b4b76766a5457352f636b7050496c412b5943385a4a64752f636e2b4f456e4c616e425331474a7258536835486c46664c78626e325a4c4c684332706d5a646c596d6e356566664564553037446c674a58543771524749524b4a6e436931674172677a4f4f564363745962447056656d654f544f7a634f5067316c31797a594e363865574f756445735758582f5a50522f364a2b397a4e7a776776726a73612b6f7a4e393733346c6a764b30432b3435494a6e634979353355634a74765a5058763273414d484470684343425949424d524646313255567a43384a395a446363534c4b63393133496e3163446a4d73306e6f41494246593536494f5647744f57707069664437362b626f6e614764757132746a5549396f64776b2b424f7556693074455635584e306548516a76316e4c59356c45334f623235754e72304f7a334b4577784c2b537448527354326462646653456a45575a536e543845454363594a6f786b6e7a726e4f2f5a31586e582f69755865734a593577427a4d716d4c64505074725935464f725a536446345647486b365273766d7957335a4d6d53733665614d397545556d385036454e66627a327738595633587533765179314b62706937624d466b65396f4b322f5450384954722b69792f315a33712b4f466a47783535494a4f694f377250724b556c776859422b4f5875583571653537485a76746d79377149364c352b63617552786c49774b70426e354a6c3058576a68785050575a433432436a4c64796672465651497370767a43653277534b50516a724156435253495246313058354a2b727565627243724c704f615155464163644c377a584a5075497074355162624b624e2f5843464b77786d4d454775366b793950752f5a7a5a746650776c3147452b427a565069684e35444d4f6657592f4e4f4d79694c7252492f305556674a724c57584c4646594936727a397a53306d4c4534334678383158684f3571715a36357930673645466f4930616336356d615847556b6d6874595a705741596a777348426a692f4674717a3630556e41664e7078776f756c475365777a424e644a4c43594b77384b4c555831586852636c4763346d45644d31506232646732417a703357314f56704d63415a503864675a7056742b54694277496a41694d50674a744e4d4d512f4f322f314452372f79324a62662f43776344764d4848337851765638346f6665515a67675558347634644a6169476e3352546a48316d5364434a7356576554727471315674714c626b69736d4c7279786c6c65636c336637704d46436d4a4b5838687457524d684a2f66364c7a7361313442596c54574f594a77306d7830597a7331576c2b6e507073346f6d3831454c61465273464d544e39744173636d7a6c4f6d5a67465269587349735a577245794d484a6d634c4c4a417034704f354248466d464363354d366338537970703973796a7935464e56454f344868756d7972454d702f705257425959324f6a485577466a55702f70546a726b6764634141696475417a432b345954777276483669657950764e4546516b734f4d63623735364f794a37617958647375626d37736f684a4d42476365627856514173746d547a684f44456d714a506a7662396a764a7935454441583672534d74396a346547764e46564e7366467858703533424f4e4846584d6c627a4977724a6e7a315874773256516a4e794c324f74314446465874427a305465304771672b4d716f453757436a78636e7773447076664a67504a736d373858567571637a6d6a47615a6852374e324b78567a4158326d366972396962534a77636f7964556f425761694a3238596a6c7a4d6677516f3578697477687255757a46507356654133476d632b6233465363387a3036794365356b7352613230453254597135535a754f775173586361564a737366466937784d33786b4739336e656347486e4f31474b4976555a687532546a755363365677484630497a547a66504765304e724d63584778374f37575779373978306e2f772f39534d4843726e70554b6741414141424a52553545726b4a6767673d3d	1	1	\N	#FFFFFF	#875A7B	\N	t	\N	\N	31	49	28	39	48	40	29	1	2	\N	4	27	38	\N	3	\N	43	\N	\N	\N	1	233	5	\N	\N	\N	26	32	\N	12	generic_coa	1014	1015	1017	round_globally	plain	\N	tax_excluded	\N	\N	\N	\N	\N	\N	\N	\N	t	t	\N	\N	\N	t	\N	\N	f	\N	t	11	15	31	12	sms	\N	t	365	edit	one_step	5000.0	13	2	4	3	manual	periodic	standard	2	\N	\N	30	\N	\N	\N	t	t	1	\N	0
\.


--
-- Data for Name: res_partner; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_partner (id, company_id, create_date, name, parent_id, user_id, state_id, country_id, industry_id, color, commercial_partner_id, create_uid, write_uid, complete_name, ref, lang, tz, vat, company_registry, website, function, type, street, street2, zip, city, email, phone, commercial_company_name, company_name, properties, barcode, comment, partner_latitude, partner_longitude, active, employee, is_company, partner_share, write_date, message_bounce, email_normalized, signup_type, phone_sanitized, specific_property_product_pricelist, invoice_template_pdf_report_id, supplier_rank, customer_rank, autopost_bills, credit_limit, property_account_payable_id, property_account_receivable_id, property_account_position_id, property_payment_term_id, property_supplier_payment_term_id, trust, ignore_abnormal_invoice_date, ignore_abnormal_invoice_amount, invoice_sending_method, invoice_edi_format_store, property_outbound_payment_method_line_id, property_inbound_payment_method_line_id, property_stock_customer, property_stock_supplier, picking_warn_msg, global_location_number, peppol_endpoint, peppol_eas, buyer_id, property_purchase_currency_id, receipt_reminder_email, reminder_date_before_receipt, purchase_warn_msg, suggest_days, suggest_percent, suggest_based_on, group_rfq, group_on, sale_warn_msg) FROM stdin;
46	\N	2026-11-03 12:23:12.999994	이서연	\N	\N	\N	\N	\N	0	46	1	1	이서연	\N	en_US	Europe/Brussels	\N	\N	\N	\N	contact	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	f	f	2026-11-03 12:23:12.999994	0	\N	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
47	\N	2026-11-03 12:23:12.999994	박지훈	\N	\N	\N	\N	\N	0	47	1	1	박지훈	\N	en_US	Europe/Brussels	\N	\N	\N	\N	contact	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	f	f	2026-11-03 12:23:12.999994	0	\N	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
45	\N	2026-11-03 12:23:12.999994	김민준	\N	\N	\N	\N	\N	0	45	1	1	김민준	\N	en_US	Europe/Brussels	\N	\N	\N	\N	contact	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	f	f	2026-11-03 12:23:14.74627	0	\N	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
4	\N	2026-11-03 11:48:09.907963	Public user	\N	\N	\N	\N	\N	0	4	1	1	Public user	\N	en_US	\N	\N	\N	\N	\N	contact	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	t	2026-11-03 11:48:18.838126	0	\N	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
5	\N	2026-11-03 11:48:09.907963	Portal User Template	\N	\N	\N	\N	\N	0	5	1	1	Portal User Template	\N	en_US	\N	\N	\N	\N	\N	contact	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	t	2026-11-03 11:48:29.494074	0	\N	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
2	1	2026-11-03 11:48:09.907963	OdooBot	\N	\N	\N	\N	\N	0	2	1	1	OdooBot	\N	en_US	Europe/Brussels	\N	\N	\N	\N	contact	\N	\N	\N	\N	odoobot@example.com	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	f	f	2026-11-03 11:48:34.234095	0	odoobot@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
1	\N	2026-11-03 11:48:09.907963	My Company (San Francisco)	\N	\N	13	233	\N	0	1	\N	1	My Company (San Francisco)	\N	en_US	\N	\N	\N	http://www.example.com	\N	contact	8000 Marina Blvd, Suite 300	\N	94005	Brisbane	info@yourcompany.com	+1 555-555-5556	My Company (San Francisco)	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:29.494074	0	info@yourcompany.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"1": 11, "3": 3}	{"1": 11, "3": 3}	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
7	\N	2026-11-03 11:48:09.907963	Joel Willis	\N	\N	33	233	\N	0	7	1	1	YourCompany, Joel Willis	\N	en_US	\N	\N	\N	\N	\N	contact	858 Lynn Street	\N	07002	Bayonne	joel.willis63@example.com	(683)-556-5104	YourCompany	YourCompany	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:29.494074	0	joel.willis63@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
8	\N	2026-11-03 11:48:09.907963	Wood Corner	\N	\N	13	233	\N	0	8	1	1	Wood Corner	\N	en_US	\N	US12345672	\N	http://www.wood-corner.com	\N	contact	1839 Arbor Way	\N	95380	Turlock	wood.corner26@example.com	(623)-853-7197	Wood Corner	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:34.234095	0	wood.corner26@example.com	signup	+16238537197	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"1": true}	\N	\N	7	100	30_days	default	default	\N
23	1	2026-11-03 11:48:09.907963	Jesse Brown	10	\N	\N	203	\N	0	10	1	1	Gemini Furniture, Jesse Brown	\N	en_US	\N	SM12345	\N	\N	Senior Consultant	contact	Via Industria 21	\N	47899	Serravalle	jesse.brown74@example.com	(829)-386-3277	Gemini Furniture	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:32.444975	0	jesse.brown74@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SM12345	9951	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
19	\N	2026-11-03 11:48:09.907963	Douglas Fletcher	9	\N	13	233	\N	0	9	1	1	Acme Corporation, Douglas Fletcher	\N	en_US	\N	US12345673	\N	\N	Functional Consultant	contact	77 Santa Barbara Rd	\N	94523	Pleasant Hill	douglas.fletcher51@example.com	(132)-553-7242	Acme Corporation	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	douglas.fletcher51@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
20	\N	2026-11-03 11:48:09.907963	Floyd Steward	9	\N	13	233	\N	0	9	1	1	Acme Corporation, Floyd Steward	\N	en_US	\N	US12345673	\N	\N	Analyst	contact	77 Santa Barbara Rd	\N	94523	Pleasant Hill	floyd.steward34@example.com	(145)-138-3401	Acme Corporation	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	floyd.steward34@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
14	\N	2026-11-03 11:48:09.907963	The Jackson Group	\N	\N	13	233	\N	0	14	1	1	The Jackson Group	\N	en_US	\N	US12345676	\N	\N	\N	contact	1611 Peony Dr	\N	95377	Tracy	jackson.group82@example.com	(334)-502-1024	The Jackson Group	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:18.838126	0	jackson.group82@example.com	\N	+13345021024	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
17	\N	2026-11-03 11:48:09.907963	Willie Burke	8	\N	13	233	\N	0	8	1	1	Wood Corner, Willie Burke	\N	en_US	\N	US12345672	\N	\N	Service Manager	contact	1839 Arbor Way	\N	95380	Turlock	willie.burke80@example.com	(846)-523-2111	Wood Corner	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	willie.burke80@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
18	\N	2026-11-03 11:48:09.907963	Ron Gibson	8	\N	13	233	\N	0	8	1	1	Wood Corner, Ron Gibson	\N	en_US	\N	US12345672	\N	\N	Store Manager	contact	1839 Arbor Way	\N	95380	Turlock	ron.gibson76@example.com	(976)-397-4091	Wood Corner	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	ron.gibson76@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
22	\N	2026-11-03 11:48:09.907963	Billy Fox	11	\N	13	233	\N	0	11	1	1	Ready Mat, Billy Fox	\N	en_US	\N	US12345675	\N	\N	Production Supervisor	contact	7500 W Linne Road	\N	95304	Tracy	billy.fox45@example.com	(915)-498-5611	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	billy.fox45@example.com	\N	+19154985611	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
29	\N	2026-11-03 11:48:09.907963	Toni Rhodes	14	\N	13	233	\N	0	14	1	1	The Jackson Group, Toni Rhodes	\N	en_US	\N	US12345676	\N	\N	Managing Partner	contact	1611 Peony Dr	\N	95377	Tracy	toni.rhodes11@example.com	(198)-539-4948	The Jackson Group	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:18.838126	0	toni.rhodes11@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
30	\N	2026-11-03 11:48:09.907963	Gordon Owens	14	\N	13	233	\N	0	14	1	1	The Jackson Group, Gordon Owens	\N	en_US	\N	US12345676	\N	\N	Senior Consultant	contact	1611 Peony Dr	\N	95377	Tracy	gordon.owens47@example.com	(336)-723-6569	The Jackson Group	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:18.838126	0	gordon.owens47@example.com	\N	+13367236569	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
35	\N	2026-11-03 11:48:09.907963	Lorraine Douglas	16	\N	13	233	\N	0	16	1	1	Lumber Inc, Lorraine Douglas	\N	en_US	\N	US12345678	\N	\N	Functional Consultant	contact	1337 N San Joaquin St	\N	95202	Stockton	lorraine.douglas35@example.com	(443)-648-9155	Lumber Inc	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:18.838126	0	lorraine.douglas35@example.com	\N	+14436489155	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
13	\N	2026-11-03 11:48:09.907963	LightsUp	\N	\N	\N	139	\N	0	13	1	1	LightsUp	\N	en_US	\N	\N	\N	http://www.lightsup.example.com	\N	contact	Eignaa tee 12	\N	74407	Uuearu	lightsup@example.com	+372 123 1234	LightsUp	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:34.218497	0	lightsup@example.com	\N	\N	\N	\N	0	2	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	9941	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
42	\N	2026-11-03 11:48:14.323106	My US Company	\N	\N	38	233	\N	0	42	1	1	My US Company	\N	en_US	\N	\N	\N	\N	\N	contact	1034 Wildwood Street	\N	44654	Millersburg	\N	+1 555-555-5556	My US Company	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:29.494074	0	\N	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"2": 10, "3": 3}	{"2": 10, "3": 3}	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
31	\N	2026-11-03 11:48:09.907963	Theodore Gardner	11	\N	13	233	\N	0	11	1	1	Ready Mat, Theodore Gardner	\N	en_US	\N	US12345675	\N	\N	System Analyst	contact	7500 W Linne Road	\N	95304	Tracy	theodore.gardner36@example.com	(186)-612-6561	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	theodore.gardner36@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
33	\N	2026-11-03 11:48:09.907963	Tom Ruiz	8	\N	13	233	\N	0	8	1	1	Wood Corner, Tom Ruiz	\N	en_US	\N	US12345672	\N	\N	Software Developer	contact	1839 Arbor Way	\N	95380	Turlock	tom.ruiz89@example.com	(102)-834-1602	Wood Corner	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	tom.ruiz89@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
40	\N	2026-11-03 11:48:09.907963	Chester Reed	1	\N	13	233	\N	0	1	1	1	My Company (San Francisco), Chester Reed	\N	en_US	\N	\N	\N	\N	Chief Executive Officer (CEO)	contact	8000 Marina Blvd, Suite 300	\N	94005	Brisbane	chester.reed79@example.com	(979)-904-8902	My Company (San Francisco)	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:29.494074	0	chester.reed79@example.com	\N	+19799048902	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
41	\N	2026-11-03 11:48:09.907963	Dwayne Newman	1	\N	13	233	\N	0	1	1	1	My Company (San Francisco), Dwayne Newman	\N	en_US	\N	\N	\N	\N	Chief Operations Officer (COO)	contact	8000 Marina Blvd, Suite 300	\N	94005	Brisbane	dwayne.newman28@example.com	(614)-177-4937	My Company (San Francisco)	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:29.494074	0	dwayne.newman28@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
21	\N	2026-11-03 11:48:09.907963	Edwin Hansen	10	\N	\N	203	\N	0	10	1	1	Gemini Furniture, Edwin Hansen	\N	en_US	\N	SM12345	\N	\N	Marketing Manager	contact	Via Industria 21	\N	47899	Serravalle	edwin.hansen58@example.com	(943)-352-2555	Gemini Furniture	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:32.444975	0	edwin.hansen58@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SM12345	9951	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
24	\N	2026-11-03 11:48:09.907963	Soham Palmer	10	\N	\N	203	\N	0	10	1	1	Gemini Furniture, Soham Palmer	\N	en_US	\N	SM12345	\N	\N	Director	contact	Via Industria 21	\N	47899	Serravalle	soham.palmer15@example.com	(379)-167-2040	Gemini Furniture	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:32.444975	0	soham.palmer15@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SM12345	9951	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
32	\N	2026-11-03 11:48:09.907963	Oscar Morgan	10	\N	\N	203	\N	0	10	1	1	Gemini Furniture, Oscar Morgan	\N	en_US	\N	SM12345	\N	\N	Order Clerk	contact	Via Industria 21	\N	47899	Serravalle	oscar.morgan11@example.com	(561)-239-1744	Gemini Furniture	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:32.444975	0	oscar.morgan11@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SM12345	9951	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
36	\N	2026-11-03 11:48:09.907963	Addison Olson	9	\N	13	233	\N	0	9	1	1	Acme Corporation, Addison Olson	\N	en_US	\N	US12345673	\N	\N	Sales Representative	contact	77 Santa Barbara Rd	\N	94523	Pleasant Hill	addison.olson28@example.com	(223)-399-7637	Acme Corporation	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	addison.olson28@example.com	\N	+12233997637	\N	\N	0	0	ask	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
25	\N	2026-11-03 11:48:09.907963	Kim Snyder	11	\N	13	233	\N	0	11	1	1	Ready Mat, Kim Snyder	\N	en_US	\N	US12345675	\N	\N	Senior Associate	contact	7500 W Linne Road	\N	95304	Tracy	kim.snyder96@example.com	(215)-379-4865	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	kim.snyder96@example.com	\N	+12153794865	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
26	\N	2026-11-03 11:48:09.907963	Edith Sanchez	11	\N	13	233	\N	0	11	1	1	Ready Mat, Edith Sanchez	\N	en_US	\N	US12345675	\N	\N	Analyst	contact	7500 W Linne Road	\N	95304	Tracy	edith.sanchez68@example.com	(938)-175-2048	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	edith.sanchez68@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
12	\N	2026-11-03 11:48:09.907963	OpenWood	\N	\N	\N	128	\N	0	12	1	1	OpenWood	\N	en_US	\N	\N	\N	http://www.openwood.example.com	\N	contact	B	\N	9510	Wiltz	wow@example.com	+352 123 456 789	OpenWood	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:34.218497	0	wow@example.com	\N	\N	\N	\N	0	8	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	9936	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
37	\N	2026-11-03 11:48:09.907963	Sandra Neal	11	\N	13	233	\N	0	11	1	1	Ready Mat, Sandra Neal	\N	en_US	\N	US12345675	\N	\N	Sales Manager	contact	7500 W Linne Road	\N	95304	Tracy	sandra.neal80@example.com	(430)-371-7293	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	sandra.neal80@example.com	\N	+14303717293	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
3	1	2026-11-03 11:48:09.907963	Mitchell Admin	\N	2	47	233	\N	0	3	1	1	YourCompany, Mitchell Admin	\N	en_US	Europe/Brussels	\N	\N	\N	\N	contact	215 Vine St	\N	18503	Scranton	admin@example.com	+1 555-555-5555	YourCompany	YourCompany	\N	\N	\N	\N	\N	t	\N	f	f	2026-11-03 11:48:34.234095	0	admin@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
38	\N	2026-11-03 11:48:09.907963	Julie Richards	11	\N	13	233	\N	0	11	1	1	Ready Mat, Julie Richards	\N	en_US	\N	US12345675	\N	\N	Financial Manager	contact	7500 W Linne Road	\N	95304	Tracy	julie.richards84@example.com	(225)-148-7811	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	julie.richards84@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
39	\N	2026-11-03 11:48:09.907963	Travis Mendoza	11	\N	13	233	\N	0	11	1	1	Ready Mat, Travis Mendoza	\N	en_US	\N	US12345675	\N	\N	Knowledge Manager	contact	7500 W Linne Road	\N	95304	Tracy	travis.mendoza24@example.com	(840)-944-8661	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	travis.mendoza24@example.com	\N	+18409448661	\N	\N	0	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
27	\N	2026-11-03 11:48:09.907963	Brandon Freeman	15	\N	13	233	\N	0	15	1	1	Azure Interior, Brandon Freeman	\N	en_US	\N	US12345677	\N	\N	Creative Director	contact	4557 De Silva St	\N	94538	Fremont	brandon.freeman55@example.com	(355)-687-3262	Azure Interior	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	brandon.freeman55@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	{"1": 6}	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
28	\N	2026-11-03 11:48:09.907963	Nicole Ford	15	\N	13	233	\N	0	15	1	1	Azure Interior, Nicole Ford	\N	en_US	\N	US12345677	\N	\N	Director	contact	4557 De Silva St	\N	94538	Fremont	nicole.ford75@example.com	(946)-638-6034	Azure Interior	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	nicole.ford75@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	{"1": 6}	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
34	\N	2026-11-03 11:48:09.907963	Colleen Diaz	15	\N	13	233	\N	0	15	1	1	Azure Interior, Colleen Diaz	\N	en_US	\N	US12345677	\N	\N	Business Executive	contact	4557 De Silva St	\N	94538	Fremont	colleen.diaz83@example.com	(255)-595-8393	Azure Interior	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:25.878704	0	colleen.diaz83@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	{"1": 6}	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
15	\N	2026-11-03 11:48:09.907963	Azure Interior	\N	\N	13	233	\N	0	15	1	1	Azure Interior	\N	en_US	\N	US12345677	\N	http://www.azure-interior.com	\N	contact	4557 De Silva St	\N	94538	Fremont	azure.Interior24@example.com	(870)-931-0505	Azure Interior	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:34.234095	0	azure.interior24@example.com	signup	+18709310505	\N	\N	0	6	ask	\N	\N	\N	\N	{"1": 6}	{"1": 6}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"1": true}	\N	\N	7	100	30_days	default	default	\N
44	\N	2026-11-03 11:48:29.494074	Jeff Lawson	43	\N	2015	233	\N	0	43	1	1	My Company (Chicago), Jeff Lawson	\N	en_US	\N	\N	\N	\N	\N	contact	90 Streets Avenue	\N	60610	Chicago	jeff.lawson52@example.com	(461)-417-6587	My Company (Chicago)	\N	\N	\N	\N	\N	\N	t	\N	f	t	2026-11-03 11:48:29.494074	0	jeff.lawson52@example.com	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
43	\N	2026-11-03 11:48:29.494074	My Company (Chicago)	\N	\N	2015	233	\N	0	43	1	1	My Company (Chicago)	\N	en_US	\N	\N	\N	http://www.example.com	\N	contact	90 Streets Avenue	\N	60610	Chicago	chicago@yourcompany.com	+1 312 349 3030	My Company (Chicago)	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-03 11:48:29.494074	0	chicago@yourcompany.com	\N	+13123493030	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"1": 3, "2": 3, "3": 22}	{"1": 3, "2": 3, "3": 22}	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
6	1	2026-11-03 11:48:09.907963	Marc Demo	\N	5	40	233	\N	0	6	1	1	YourCompany, Marc Demo	\N	en_US	Europe/Brussels	\N	\N	\N	\N	contact	3575  Buena Vista Avenue	\N	97401	Eugene	mark.brown23@example.com	(441)-695-2334	YourCompany	YourCompany	\N	\N	\N	\N	\N	t	\N	f	f	2026-11-06 10:24:54.97385	0	mark.brown23@example.com	\N	+14416952334	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
16	\N	2026-11-03 11:48:09.907963	Lumber Inc	\N	\N	13	233	\N	0	16	1	1	Lumber Inc	\N	en_US	\N	US12345678	\N	http://www.lumber-inc.com	\N	contact	1337 N San Joaquin St	\N	95202	Stockton	lumber-inv92@example.com	(828)-316-0593	Lumber Inc	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-06 10:24:54.97385	0	lumber-inv92@example.com	signup	+18283160593	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
10	\N	2026-11-03 11:48:09.907963	Gemini Furniture	\N	\N	\N	203	\N	0	10	1	1	Gemini Furniture	\N	en_US	\N	SM12345	\N	http://www.gemini-furniture.com/	\N	contact	Via Industria 21	\N	47899	Serravalle	gemini_furniture@fake.geminifurniture.com	+378 0549 885555	Gemini Furniture	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-06 10:24:54.97385	0	gemini_furniture@fake.geminifurniture.com	signup	+3780549885555	\N	\N	2	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	SM12345	9951	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
48	\N	2026-11-03 12:50:35.931832	최윤서	\N	\N	\N	\N	\N	0	48	1	1	최윤서	\N	en_US	Europe/Brussels	\N	\N	\N	\N	contact	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	t	\N	f	f	2026-11-03 12:50:35.931832	0	\N	\N	\N	\N	\N	0	0	ask	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
9	\N	2026-11-03 11:48:09.907963	Acme Corporation	\N	\N	13	233	\N	0	9	1	1	Acme Corporation	\N	en_US	\N	US12345673	\N	http://www.acme-example-company.com	\N	contact	77 Santa Barbara Rd	\N	94523	Pleasant Hill	acme_corp@yourcompany.example.com	(603)-996-3829	Acme Corporation	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-06 10:24:54.97385	0	acme_corp@yourcompany.example.com	signup	+16039963829	\N	\N	0	14	ask	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	{"1": true}	\N	\N	7	100	30_days	default	default	\N
11	\N	2026-11-03 11:48:09.907963	Ready Mat	\N	\N	13	233	\N	0	11	1	1	Ready Mat	\N	en_US	\N	US12345675	\N	http://www.ready-mat.com/	\N	contact	7500 W Linne Road	\N	95304	Tracy	ready.mat28@example.com	(803)-873-6126	Ready Mat	\N	\N	\N	\N	\N	\N	t	\N	t	t	2026-11-06 10:24:54.97385	0	ready.mat28@example.com	signup	+18038736126	\N	\N	4	0	ask	\N	\N	\N	\N	\N	{"1": 4}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	7	100	30_days	default	default	\N
\.


--
-- Data for Name: res_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.res_users (id, partner_id, company_id, active, share) FROM stdin;
1	2	1	f	f
2	3	1	t	f
3	4	1	f	t
4	5	1	f	t
5	6	1	t	f
6	7	1	t	t
7	45	1	t	f
8	46	1	t	f
9	47	1	t	f
10	48	1	t	f
\.


--
-- Data for Name: sale_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_order (id, campaign_id, source_id, medium_id, company_id, partner_id, pending_email_template_id, journal_id, partner_invoice_id, partner_shipping_id, fiscal_position_id, payment_term_id, preferred_payment_method_line_id, pricelist_id, currency_id, user_id, team_id, create_uid, write_uid, access_token, name, state, client_order_ref, origin, reference, signed_by, invoice_status, validity_date, note, currency_rate, amount_untaxed, amount_tax, amount_total, locked, require_signature, require_payment, create_date, commitment_date, date_order, signed_on, write_date, prepayment_percent, sale_order_template_id, incoterm, warehouse_id, incoterm_location, picking_policy, delivery_status, effective_date, customizable_pdf_form_fields) FROM stdin;
1	4	11	4	1	9	\N	\N	9	9	1	4	\N	\N	1	\N	1	1	1	\N	S00001	draft	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1740.00	0.00	1740.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-03 11:48:00	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
2	4	11	4	1	11	\N	\N	25	25	1	\N	\N	\N	1	\N	1	1	1	\N	S00002	draft	\N	\N	\N	\N	no	2026-12-03	\N	1.0	2947.50	0.00	2947.50	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-03 11:48:00	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
3	4	11	4	1	11	\N	\N	11	11	1	\N	\N	\N	1	5	4	1	1	\N	S00003	draft	\N	\N	\N	\N	no	2026-12-03	\N	1.0	377.50	0.00	377.50	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
4	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	7	1	1	1	\N	S00004	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	2240.00	0.00	2240.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
5	4	11	4	1	9	\N	\N	9	9	1	4	\N	\N	1	8	4	1	1	\N	S00005	draft	\N	\N	\N	\N	no	2026-12-03	\N	1.0	405.00	0.00	405.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-03 11:48:00	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
6	4	11	4	1	16	\N	\N	16	16	1	\N	\N	\N	1	9	4	1	1	\N	S00006	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	750.00	0.00	750.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
7	4	11	4	1	10	\N	\N	24	24	2	\N	\N	\N	1	5	4	1	1	\N	S00007	sale	\N	\N	\N	\N	to invoice	2026-12-03	\N	1.0	1706.00	0.00	1706.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
8	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	7	4	1	1	\N	S00008	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	462.00	0.00	462.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
9	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	8	4	1	1	\N	S00009	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	654.00	0.00	654.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-27 11:48:38.557777	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
10	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	9	4	1	1	\N	S00010	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	751.00	0.00	751.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
11	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	5	4	1	1	\N	S00011	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1096.50	0.00	1096.50	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-13 11:48:38.558283	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
12	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	7	4	1	1	\N	S00012	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	556.00	0.00	556.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
13	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	8	4	1	1	\N	S00013	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	415.50	0.00	415.50	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
14	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	9	1	1	1	\N	S00014	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1582.00	0.00	1582.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
15	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	5	4	1	1	\N	S00015	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1541.50	0.00	1541.50	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-20 11:48:38.558759	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
16	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	7	1	1	1	\N	S00016	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1186.50	0.00	1186.50	f	t	t	2026-11-03 11:48:37.287963	\N	2026-11-03 11:48:38	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
17	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	8	1	1	1	\N	S00017	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	951.00	0.00	951.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-06 11:48:38.559219	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
18	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	9	1	1	1	\N	S00018	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	831.00	0.00	831.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-09-29 11:48:38.55969	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
19	\N	\N	\N	1	7	\N	\N	7	7	1	\N	\N	\N	1	5	4	1	1	\N	S00019	sent	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1740.00	0.00	1740.00	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-03 11:48:00	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
20	\N	\N	\N	1	7	\N	\N	7	7	1	\N	\N	\N	1	7	1	1	1	\N	S00020	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	2947.50	0.00	2947.50	f	t	t	2026-11-03 11:48:37.287963	\N	2026-10-03 11:48:38.560158	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	\N	\N	\N
21	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	8	1	1	1	\N	S00021	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	2175.00	0.00	2175.00	f	t	t	2026-11-03 11:48:39.293035	\N	2026-11-03 11:48:39	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	pending	\N	\N
22	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	9	1	1	1	\N	S00022	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1475.00	0.00	1475.00	f	t	t	2026-11-03 11:48:39.293035	\N	2026-11-03 11:48:39	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	pending	\N	\N
23	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	5	4	1	1	\N	S00023	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	4350.00	0.00	4350.00	f	t	t	2026-11-03 11:48:39.293035	\N	2026-11-03 11:48:39	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	pending	\N	\N
24	4	11	4	1	10	\N	\N	32	32	2	\N	\N	\N	1	7	1	1	1	\N	S00024	sale	\N	\N	\N	\N	no	2026-12-03	\N	1.0	1990.00	0.00	1990.00	f	t	t	2026-11-03 11:48:39.293035	\N	2026-11-03 11:48:39	\N	2026-11-06 10:24:54.97385	1	\N	\N	1	\N	direct	pending	\N	\N
\.


--
-- Data for Name: sale_order_line; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_order_line (id, order_id, sequence, company_id, currency_id, order_partner_id, salesman_id, product_id, product_uom_id, linked_line_id, combo_item_id, create_uid, write_uid, state, display_type, virtual_id, linked_virtual_id, qty_delivered_method, invoice_status, analytic_distribution, extra_tax_data, name, product_uom_qty, price_unit, discount, price_subtotal, price_total, price_reduce_taxexcl, price_reduce_taxinc, qty_delivered, qty_invoiced, qty_to_invoice, untaxed_amount_invoiced, untaxed_amount_to_invoice, is_downpayment, is_expense, collapse_prices, collapse_composition, create_date, write_date, technical_price_unit, price_tax, customer_lead, is_optional, warehouse_id) FROM stdin;
28	13	10	1	1	10	8	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	1.00	295.0	0.00	295.00	295.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	295	0	0	\N	1
29	13	10	1	1	10	8	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	1.00	120.5	0.00	120.50	120.50	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
30	14	10	1	1	10	9	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	4.00	275.0	0.00	1100.00	1100.00	275.00	275.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	275	0	0	\N	1
31	14	10	1	1	10	9	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	4.00	120.5	0.00	482.00	482.00	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
43	20	10	1	1	7	7	3	4	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	Virtual Interior Design	24.00	75.0	0.00	1800.00	1800.00	75.00	75.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	75	0	0	\N	1
44	20	10	1	1	7	7	4	4	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	Virtual Home Staging	30.00	38.25	0.00	1147.50	1147.50	38.25	38.25	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	38.25	0	0	\N	1
45	21	10	1	1	10	8	38	1	\N	\N	1	1	sale	\N	\N	\N	stock_move	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	5.00	295.0	0.00	1475.00	1475.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:39.293035	2026-11-06 10:24:54.97385	295	0	0	f	1
46	21	10	1	1	10	8	27	1	\N	\N	1	1	sale	\N	\N	\N	stock_move	no	\N	\N	[E-COM11] Cabinet with Doors	5.00	140.0	0.00	700.00	700.00	140.00	140.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:39.293035	2026-11-06 10:24:54.97385	140	0	0	f	1
47	22	10	1	1	10	9	38	1	\N	\N	1	1	sale	\N	\N	\N	stock_move	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	5.00	295.0	0.00	1475.00	1475.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:39.293035	2026-11-06 10:24:54.97385	295	0	0	f	1
48	23	10	1	1	10	5	38	1	\N	\N	1	1	sale	\N	\N	\N	stock_move	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	10.00	295.0	0.00	2950.00	2950.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:39.293035	2026-11-06 10:24:54.97385	295	0	0	f	1
49	23	10	1	1	10	5	27	1	\N	\N	1	1	sale	\N	\N	\N	stock_move	no	\N	\N	[E-COM11] Cabinet with Doors	10.00	140.0	0.00	1400.00	1400.00	140.00	140.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:39.293035	2026-11-06 10:24:54.97385	140	0	0	f	1
50	24	10	1	1	10	7	19	1	\N	\N	1	1	sale	\N	\N	\N	stock_move	no	\N	\N	[E-COM06] Corner Desk Right Sit\nRight-aligned desk with storage	10.00	199.0	0.00	1990.00	1990.00	199.00	199.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:39.293035	2026-11-06 10:24:54.97385	199	0	0	f	1
1	1	10	1	1	9	\N	38	1	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	3.00	295.0	0.00	885.00	885.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	295	0	0	\N	1
2	1	10	1	1	9	\N	6	1	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	[FURN_8888] Office Lamp	5.00	145.0	0.00	725.00	725.00	145.00	145.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	145	0	0	\N	1
3	1	10	1	1	9	\N	5	1	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	[FURN_7777] Office Chair\nComfortable yellow chair for daily work	2.00	65.0	0.00	130.00	130.00	65.00	65.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	65	0	0	\N	1
4	2	10	1	1	11	\N	3	4	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	Virtual Interior Design	24.00	75.0	0.00	1800.00	1800.00	75.00	75.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	75	0	0	\N	1
5	2	10	1	1	11	\N	4	4	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	Virtual Home Staging	30.00	38.25	0.00	1147.50	1147.50	38.25	38.25	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	38.25	0	0	\N	1
6	3	10	1	1	11	5	3	4	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	Virtual Interior Design	10.00	30.75	0.00	307.50	307.50	30.75	30.75	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	30.75	0	0	\N	1
7	3	10	1	1	11	5	5	1	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	[FURN_7777] Office Chair\nComfortable yellow chair for daily work	1.00	70.0	0.00	70.00	70.00	70.00	70.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	70	0	0	\N	1
14	7	10	1	1	10	5	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	5.00	295.0	0.00	1475.00	1475.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	295	0	0	\N	1
15	7	10	1	1	10	5	43	1	\N	\N	1	1	sale	\N	\N	\N	manual	to invoice	\N	\N	Two-Seat Sofa (Linen)\nTwo-Seater Sofa with Oak Wood Frame	1.00	173.0	0.00	173.00	173.00	173.00	173.00	0.00	0.00	1.00	0.00	173.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	173	0	0	\N	1
16	7	10	1	1	10	5	6	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_8888] Office Lamp	1.00	40.0	0.00	40.00	40.00	40.00	40.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	40	0	0	\N	1
17	7	10	1	1	10	5	5	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_7777] Office Chair\nComfortable yellow chair for daily work	1.00	18.0	0.00	18.00	18.00	18.00	18.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	18	0	0	\N	1
18	8	10	1	1	10	7	39	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_8855] Drawer	2.00	110.5	0.00	221.00	221.00	110.50	110.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	110.5	0	0	\N	1
19	8	10	1	1	10	7	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	2.00	120.5	0.00	241.00	241.00	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
20	9	10	1	1	10	8	39	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_8855] Drawer	3.00	97.5	0.00	292.50	292.50	97.50	97.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	97.5	0	0	\N	1
8	4	10	1	1	10	7	3	4	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	Virtual Interior Design	16.00	75.0	0.00	1200.00	1200.00	75.00	75.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	75	0	0	\N	1
9	4	10	1	1	10	7	6	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_8888] Office Lamp	10.00	45.0	0.00	450.00	450.00	45.00	45.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	45	0	0	\N	1
10	4	10	1	1	10	7	41	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6741] Large Meeting Table\nBig table seats 10–12 for team discussions	3.00	150.0	0.00	450.00	450.00	150.00	150.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	150	0	0	\N	1
11	4	10	1	1	10	7	5	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_7777] Office Chair\nComfortable yellow chair for daily work	2.00	70.0	0.00	140.00	140.00	70.00	70.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	70	0	0	\N	1
12	5	10	1	1	9	8	6	1	\N	\N	1	1	draft	\N	\N	\N	manual	no	\N	\N	[FURN_8888] Office Lamp	1.00	405.0	0.00	405.00	405.00	405.00	405.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	405	0	0	\N	1
13	6	10	1	1	16	9	13	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0096] Customizable Desk (White, Steel)\n160x80cm, with large legs	1.00	750.0	0.00	750.00	750.00	750.00	750.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	750	0	0	\N	1
21	9	10	1	1	10	8	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	3.00	120.5	0.00	361.50	361.50	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
22	10	10	1	1	10	9	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	2.00	255.0	0.00	510.00	510.00	255.00	255.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	255	0	0	\N	1
23	10	10	1	1	10	9	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	2.00	120.5	0.00	241.00	241.00	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
24	11	10	1	1	10	5	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	3.00	245.0	0.00	735.00	735.00	245.00	245.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	245	0	0	\N	1
25	11	10	1	1	10	5	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	3.00	120.5	0.00	361.50	361.50	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
26	12	10	1	1	10	7	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	1.00	315.0	0.00	315.00	315.00	315.00	315.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	315	0	0	\N	1
27	12	10	1	1	10	7	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	2.00	120.5	0.00	241.00	241.00	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
32	15	10	1	1	10	5	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	4.00	295.0	0.00	1180.00	1180.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	295	0	0	\N	1
33	15	10	1	1	10	5	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	3.00	120.5	0.00	361.50	361.50	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
34	16	10	1	1	10	7	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	3.00	275.0	0.00	825.00	825.00	275.00	275.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	275	0	0	\N	1
35	16	10	1	1	10	7	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	3.00	120.5	0.00	361.50	361.50	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
36	17	10	1	1	10	8	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	2.00	355.0	0.00	710.00	710.00	355.00	355.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	355	0	0	\N	1
37	17	10	1	1	10	8	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	2.00	120.5	0.00	241.00	241.00	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
38	18	10	1	1	10	9	38	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	2.00	295.0	0.00	590.00	590.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	295	0	0	\N	1
39	18	10	1	1	10	9	31	1	\N	\N	1	1	sale	\N	\N	\N	manual	no	\N	\N	[FURN_0269] Office Chair Black\nHigh-back office chair with great support	2.00	120.5	0.00	241.00	241.00	120.50	120.50	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	120.5	0	0	\N	1
40	19	10	1	1	7	5	38	1	\N	\N	1	1	sent	\N	\N	\N	manual	no	\N	\N	[FURN_6667] Acoustic Bloc Screens (Black)\nNoise-reducing panels for open spaces	3.00	295.0	0.00	885.00	885.00	295.00	295.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	295	0	0	\N	1
41	19	10	1	1	7	5	6	1	\N	\N	1	1	sent	\N	\N	\N	manual	no	\N	\N	[FURN_8888] Office Lamp	5.00	145.0	0.00	725.00	725.00	145.00	145.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	145	0	0	\N	1
42	19	10	1	1	7	5	5	1	\N	\N	1	1	sent	\N	\N	\N	manual	no	\N	\N	[FURN_7777] Office Chair\nComfortable yellow chair for daily work	2.00	65.0	0.00	130.00	130.00	65.00	65.00	0.00	0.00	0.00	0.00	0.00	\N	\N	f	f	2026-11-03 11:48:37.287963	2026-11-06 10:24:54.97385	65	0	0	\N	1
\.


--
-- Data for Name: stock_location; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_location (id, location_id, company_id, removal_strategy_id, cyclic_inventory_frequency, warehouse_id, storage_category_id, create_uid, write_uid, name, complete_name, usage, parent_path, barcode, last_inventory_date, next_inventory_date, active, replenish_location, create_date, write_date, valuation_account_id) FROM stdin;
1	\N	\N	\N	0	\N	\N	1	1	Vendors	Vendors	supplier	1/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
2	\N	\N	\N	0	\N	\N	1	1	Customers	Customers	customer	2/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
4	\N	1	\N	0	1	\N	1	1	WH	WH	view	4/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
6	4	1	\N	0	1	\N	1	1	Input	WH/Input	internal	4/6/	WHINPUT	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
7	4	1	\N	0	1	\N	1	1	Quality Control	WH/Quality Control	internal	4/7/	WHQUALITY	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
8	4	1	\N	0	1	\N	1	1	Output	WH/Output	internal	4/8/	WHOUTPUT	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
9	4	1	\N	0	1	\N	1	1	Packing Zone	WH/Packing Zone	internal	4/9/	WHPACKING	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
10	\N	2	\N	0	\N	\N	1	1	Inter-warehouse transit	Inter-warehouse transit	transit	10/	\N	\N	\N	f	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
11	\N	1	\N	0	\N	\N	1	1	Inter-warehouse transit	Inter-warehouse transit	transit	11/	\N	\N	\N	f	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
12	\N	2	\N	0	\N	\N	1	1	Inventory adjustment	Inventory adjustment	inventory	12/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
13	\N	1	\N	0	\N	\N	1	1	Inventory adjustment	Inventory adjustment	inventory	13/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
14	\N	2	\N	0	\N	\N	1	1	Production	Production	production	14/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
15	\N	1	\N	0	\N	\N	1	1	Production	Production	production	15/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
17	5	1	\N	0	1	\N	1	1	Shelf 1	WH/Stock/Shelf 1	internal	4/5/17/	SHELF1	\N	\N	t	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
18	6	1	\N	0	1	\N	1	1	Order Processing	WH/Input/Order Processing	internal	4/6/18/	\N	\N	\N	t	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
19	18	1	\N	0	1	\N	1	1	Dispatch Zone	WH/Input/Order Processing/Dispatch Zone	internal	4/6/18/19/	\N	\N	\N	t	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
20	19	1	\N	0	1	\N	1	1	Gate A	WH/Input/Order Processing/Dispatch Zone/Gate A	internal	4/6/18/19/20/	\N	\N	\N	t	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
21	19	1	\N	0	1	\N	1	1	Gate B	WH/Input/Order Processing/Dispatch Zone/Gate B	internal	4/6/18/19/21/	\N	\N	\N	t	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
3	\N	\N	\N	0	\N	\N	1	1	Inter-company transit	Inter-company transit	transit	3/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
22	\N	3	\N	0	\N	\N	1	1	Inter-warehouse transit	Inter-warehouse transit	transit	22/	\N	\N	\N	f	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
23	\N	3	\N	0	\N	\N	1	1	Inventory adjustment	Inventory adjustment	inventory	23/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
24	\N	3	\N	0	\N	\N	1	1	Production	Production	production	24/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
25	\N	3	\N	0	\N	\N	1	1	Scrap	Scrap	inventory	25/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
26	\N	3	\N	0	2	\N	1	1	My Co	My Co	view	26/	\N	\N	\N	t	f	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
27	26	3	\N	0	2	\N	1	1	Stock	My Co/Stock	internal	26/27/	MYCOSTOCK	\N	\N	t	t	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
28	26	3	\N	0	2	\N	1	1	Input	My Co/Input	internal	26/28/	MYCOINPUT	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
29	26	3	\N	0	2	\N	1	1	Quality Control	My Co/Quality Control	internal	26/29/	MYCOQUALITY	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
30	26	3	\N	0	2	\N	1	1	Output	My Co/Output	internal	26/30/	MYCOOUTPUT	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
31	26	3	\N	0	2	\N	1	1	Packing Zone	My Co/Packing Zone	internal	26/31/	MYCOPACKING	\N	\N	f	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
32	16	1	\N	0	1	\N	1	1	Small Refrigerator	WH/Stock/Shelf 2/Small Refrigerator	internal	4/5/16/32/	REFRIG	\N	\N	t	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
16	5	1	\N	0	1	\N	1	1	Shelf 2	WH/Stock/Shelf 2	internal	4/5/16/	SHELF2	2026-11-03	\N	t	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
5	4	1	\N	0	1	\N	1	1	Stock	WH/Stock	internal	4/5/	WHSTOCK	2026-11-03	\N	t	t	2026-11-03 11:48:29.494074	2026-11-03 11:48:39.293035	\N
\.


--
-- Data for Name: stock_picking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_picking (id, backorder_id, return_id, location_id, location_dest_id, picking_type_id, partner_id, company_id, user_id, owner_id, create_uid, write_uid, name, origin, move_type, state, priority, picking_properties, note, shipping_weight, has_deadline_issue, printed, is_locked, scheduled_date, date_deadline, date_done, create_date, write_date, sale_id) FROM stdin;
8	\N	\N	1	5	1	\N	1	\N	\N	1	1	WH/IN/00001	\N	direct	draft	0	\N	\N	0.00	f	\N	t	2026-11-03 11:48:32	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
12	\N	\N	1	5	1	8	1	\N	\N	1	1	WH/IN/00005	\N	direct	draft	0	\N	\N	0.00	f	\N	t	2026-11-03 11:48:32	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
10	\N	\N	1	5	1	8	1	\N	\N	1	1	WH/IN/00003	\N	direct	assigned	0	\N	\N	1.25	f	\N	t	2026-11-03 11:48:32	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
11	\N	\N	1	5	1	8	1	\N	\N	1	1	WH/IN/00004	\N	direct	assigned	0	\N	\N	1.20	f	\N	t	2026-11-03 11:48:32	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
3	\N	\N	5	2	2	8	1	\N	\N	1	1	WH/OUT/00003	outgoing shipment	direct	draft	0	\N	\N	0.00	f	\N	t	2026-10-29 11:48:32.059756	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
4	\N	\N	5	2	2	8	1	\N	\N	1	1	WH/OUT/00004	your company warehouse	direct	draft	0	\N	\N	0.00	f	\N	t	2026-11-03 11:48:32.064855	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
1	\N	\N	5	2	2	8	1	\N	\N	1	1	WH/OUT/00001	outgoing shipment	direct	assigned	0	\N	\N	0.15	f	\N	t	2026-11-03 11:48:32.045214	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
5	\N	\N	5	2	2	8	1	\N	\N	1	1	WH/OUT/00005	outgoing shipment	direct	assigned	0	\N	\N	0.16	f	\N	t	2026-11-06 11:48:32.155968	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
9	\N	\N	1	5	1	8	1	\N	\N	1	1	WH/IN/00002	\N	direct	assigned	0	\N	\N	0.35	f	\N	t	2026-10-29 11:48:32.089411	\N	\N	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
7	\N	\N	5	2	2	8	1	\N	\N	1	1	WH/OUT/00007	outgoing shipment	direct	assigned	0	\N	\N	16.50	f	\N	t	2026-10-27 11:48:32.157043	\N	2026-10-27 11:48:32.155385	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
13	\N	\N	1	5	1	11	1	\N	\N	1	1	WH/IN/00006	P00011	direct	assigned	0	\N	\N	0.10	f	\N	t	2026-11-03 11:48:36.627901	2026-11-03 11:48:36.627901	\N	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
2	\N	\N	5	2	2	8	1	\N	\N	1	1	WH/OUT/00002	outgoing shipment	direct	assigned	0	\N	\N	59.40	f	\N	t	2026-10-19 11:48:32.054536	\N	2026-11-03 11:48:32	2026-11-03 11:48:29.494074	2026-11-03 11:48:52.182474	\N
6	\N	\N	5	2	2	8	1	\N	\N	1	1	WH/OUT/00006	outgoing shipment	direct	assigned	0	\N	\N	0.40	f	\N	t	2026-10-16 11:48:32.156527	\N	2026-10-17 11:48:32.154935	2026-11-03 11:48:29.494074	2026-11-03 11:48:52.182474	\N
14	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00008	\N	direct	done	0	\N	\N	0.06	f	\N	t	2025-12-03 11:48:36.697402	\N	2025-12-05 11:48:37.147749	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
15	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00009	\N	direct	done	0	\N	\N	0.10	f	\N	t	2026-08-15 11:48:36.704237	\N	2026-08-20 11:48:37.151121	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
16	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00010	\N	direct	done	0	\N	\N	0.20	f	\N	t	2026-09-04 11:48:36.709541	\N	2026-09-14 11:48:37.152926	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
17	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00011	\N	direct	done	0	\N	\N	0.05	f	\N	t	2026-10-11 11:48:36.716172	\N	2026-10-13 11:48:37.15695	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
18	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00012	\N	direct	done	0	\N	\N	0.04	f	\N	t	2026-10-24 11:48:36.722193	\N	2026-10-27 11:48:37.160075	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
19	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00013	\N	direct	done	0	\N	\N	1.20	f	\N	t	2025-11-03 11:48:36.727334	\N	2025-11-03 11:48:37.162171	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
20	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00014	\N	direct	done	0	\N	\N	1.30	f	\N	t	2025-12-03 11:48:36.733044	\N	2025-12-03 11:48:37.164027	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
21	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00015	\N	direct	done	0	\N	\N	1.10	f	\N	t	2026-01-03 11:48:36.738348	\N	2026-01-03 11:48:37.165887	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
22	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00016	\N	direct	done	0	\N	\N	1.00	f	\N	t	2026-02-03 11:48:36.743646	\N	2026-02-03 11:48:37.16785	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
23	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00017	\N	direct	done	0	\N	\N	0.90	f	\N	t	2026-03-03 11:48:36.748796	\N	2026-03-03 11:48:37.169771	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
24	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00018	\N	direct	done	0	\N	\N	1.40	f	\N	t	2026-04-03 11:48:36.754081	\N	2026-04-03 11:48:37.1716	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
25	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00019	\N	direct	done	0	\N	\N	1.15	f	\N	t	2026-05-03 11:48:36.759247	\N	2026-05-03 11:48:37.173391	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
26	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00020	\N	direct	done	0	\N	\N	1.20	f	\N	t	2026-06-03 11:48:36.764457	\N	2026-06-03 11:48:37.175209	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
27	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00021	\N	direct	done	0	\N	\N	1.20	f	\N	t	2026-07-03 11:48:36.76962	\N	2026-07-03 11:48:37.176996	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
28	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00022	\N	direct	done	0	\N	\N	1.00	f	\N	t	2026-08-03 11:48:36.774668	\N	2026-08-03 11:48:37.178853	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
29	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00023	\N	direct	done	0	\N	\N	0.90	f	\N	t	2026-09-03 11:48:36.779798	\N	2026-09-03 11:48:37.180591	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
30	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00024	\N	direct	done	0	\N	\N	1.25	f	\N	t	2026-10-03 11:48:36.784918	\N	2026-10-03 11:48:37.182383	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
31	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00025	\N	direct	done	0	\N	\N	1.10	f	\N	t	2024-11-03 11:48:36.790027	\N	2024-11-03 11:48:37.184196	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
32	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00026	\N	direct	done	0	\N	\N	1.20	f	\N	t	2024-12-03 11:48:36.795162	\N	2024-12-03 11:48:37.185999	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
33	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00027	\N	direct	done	0	\N	\N	1.00	f	\N	t	2025-01-03 11:48:36.800298	\N	2025-01-03 11:48:37.187823	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
34	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00028	\N	direct	done	0	\N	\N	0.90	f	\N	t	2025-02-03 11:48:36.805449	\N	2025-02-03 11:48:37.189604	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
35	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00029	\N	direct	done	0	\N	\N	0.80	f	\N	t	2025-03-03 11:48:36.81078	\N	2025-03-03 11:48:37.191385	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
36	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00030	\N	direct	done	0	\N	\N	1.30	f	\N	t	2025-04-03 11:48:36.815963	\N	2025-04-03 11:48:37.193193	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
37	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00031	\N	direct	done	0	\N	\N	1.05	f	\N	t	2025-05-03 11:48:36.821031	\N	2025-05-03 11:48:37.194998	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
38	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00032	\N	direct	done	0	\N	\N	1.10	f	\N	t	2025-06-03 11:48:36.826055	\N	2025-06-03 11:48:37.196768	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
39	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00033	\N	direct	done	0	\N	\N	1.10	f	\N	t	2025-07-03 11:48:36.831131	\N	2025-07-03 11:48:37.19854	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
40	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00034	\N	direct	done	0	\N	\N	0.90	f	\N	t	2025-08-03 11:48:36.836495	\N	2025-08-03 11:48:37.200327	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
41	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00035	\N	direct	done	0	\N	\N	0.80	f	\N	t	2025-09-03 11:48:36.841882	\N	2025-09-03 11:48:37.202129	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
42	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00036	\N	direct	done	0	\N	\N	1.15	f	\N	t	2025-10-03 11:48:36.847136	\N	2025-10-03 11:48:37.203969	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
45	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00039	\N	direct	done	0	\N	\N	0.20	f	\N	t	2026-11-04 11:48:36.862723	\N	2026-11-02 11:48:37.206086	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
43	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00037	\N	direct	assigned	0	\N	\N	0.99	f	\N	t	2026-12-03 11:48:36.852364	\N	\N	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
44	\N	\N	5	2	2	\N	1	1	\N	1	1	WH/OUT/00038	\N	direct	assigned	0	\N	\N	0.80	f	\N	t	2027-02-03 11:48:36.857512	\N	\N	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
49	\N	\N	5	2	2	32	1	\N	\N	1	1	WH/OUT/00043	S00024	direct	confirmed	0	\N	\N	0.00	f	\N	t	2026-11-03 11:48:39	2026-11-03 11:48:39	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	24
46	\N	\N	5	2	2	32	1	\N	\N	1	1	WH/OUT/00040	S00021	direct	assigned	0	\N	\N	0.05	t	\N	t	2026-11-04 11:48:39	2026-11-03 11:48:39	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	21
47	\N	\N	5	2	2	32	1	\N	\N	1	1	WH/OUT/00041	S00022	direct	assigned	0	\N	\N	0.00	t	\N	t	2026-11-05 11:48:39	2026-11-03 11:48:39	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	22
48	\N	\N	5	2	2	32	1	\N	\N	1	1	WH/OUT/00042	S00023	direct	assigned	0	\N	\N	0.10	t	\N	t	2026-11-06 11:48:39	2026-11-03 11:48:39	\N	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	23
\.


--
-- Data for Name: stock_quant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_quant (id, product_id, company_id, location_id, lot_id, package_id, owner_id, user_id, create_uid, write_uid, inventory_date, quantity, reserved_quantity, inventory_quantity, inventory_diff_quantity, inventory_quantity_set, in_date, create_date, write_date, accounting_date) FROM stdin;
16	36	1	13	\N	\N	\N	\N	1	1	\N	-16.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
17	21	1	13	\N	\N	\N	\N	1	1	\N	-18.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
18	20	1	13	\N	\N	\N	\N	1	1	\N	-500.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
19	26	1	13	\N	\N	\N	\N	1	1	\N	-22.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
20	27	1	13	\N	\N	\N	\N	1	1	\N	-33.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
21	29	1	13	\N	\N	\N	\N	1	1	\N	-26.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
22	30	1	13	\N	\N	\N	\N	1	1	\N	-30.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
23	13	1	13	\N	\N	\N	\N	1	1	\N	-45.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
24	16	1	13	\N	\N	\N	\N	1	1	\N	-50.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
25	14	1	13	\N	\N	\N	\N	1	1	\N	-55.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
26	31	1	13	\N	\N	\N	\N	1	1	\N	-10.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
27	32	1	13	\N	\N	\N	\N	1	1	\N	-2.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
28	39	1	13	1	\N	\N	\N	1	1	\N	-80.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
29	8	1	13	\N	\N	\N	\N	1	1	\N	-2855.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
30	38	1	13	\N	\N	\N	\N	1	1	\N	-16.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
1	36	1	5	\N	\N	\N	\N	1	1	2026-12-31	16.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
2	21	1	5	\N	\N	\N	\N	1	1	2026-12-31	18.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
6	29	1	5	\N	\N	\N	\N	1	1	2026-12-31	26.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
7	30	1	5	\N	\N	\N	\N	1	1	2026-12-31	30.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
8	13	1	5	\N	\N	\N	\N	1	1	2026-12-31	45.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
9	16	1	5	\N	\N	\N	\N	1	1	2026-12-31	50.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
10	14	1	5	\N	\N	\N	\N	1	1	2026-12-31	55.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
11	31	1	5	\N	\N	\N	\N	1	1	2026-12-31	10.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
12	32	1	5	\N	\N	\N	\N	1	1	2026-12-31	2.00	0.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
37	23	1	13	\N	\N	\N	\N	1	1	\N	-8.00	0.00	\N	0.00	f	2026-11-03 11:48:36	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
13	39	1	5	1	\N	\N	\N	1	1	2026-12-31	80.00	15.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
33	53	1	13	3	\N	\N	\N	1	1	\N	-50.00	0.00	\N	0.00	f	2026-11-03 11:48:32	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
34	53	1	13	4	\N	\N	\N	1	1	\N	-40.00	0.00	\N	0.00	f	2026-11-03 11:48:32	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
31	53	1	16	3	\N	\N	\N	1	1	2026-12-31	50.00	0.00	0.00	0.00	f	2026-11-03 11:48:32	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
32	53	1	16	4	\N	\N	\N	1	1	2026-12-31	40.00	0.00	0.00	0.00	f	2026-11-03 11:48:32	2026-11-03 11:48:29.494074	2026-11-03 11:48:29.494074	\N
38	5	1	13	\N	\N	\N	\N	1	1	\N	-23.00	0.00	\N	0.00	f	2026-11-03 11:48:36	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
39	23	\N	2	\N	\N	\N	\N	1	1	\N	8.00	0.00	\N	0.00	f	2026-11-03 11:48:36	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
40	5	\N	2	\N	\N	\N	\N	1	1	\N	23.00	0.00	\N	0.00	f	2026-11-03 11:48:36	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
41	26	\N	2	\N	\N	\N	\N	1	1	\N	22.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
42	8	\N	2	\N	\N	\N	\N	1	1	\N	2620.00	0.00	\N	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:36.241642	2026-11-03 11:48:36.241642	\N
45	15	1	13	\N	\N	\N	\N	1	1	\N	-65.00	0.00	\N	0.00	f	2026-11-03 11:48:39	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	\N
46	18	1	13	\N	\N	\N	\N	1	1	\N	-70.00	0.00	\N	0.00	f	2026-11-03 11:48:39	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	\N
43	15	1	5	\N	\N	\N	\N	1	1	2026-12-31	65.00	0.00	0.00	0.00	f	2026-11-03 11:48:39	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	\N
44	18	1	5	\N	\N	\N	\N	1	1	2026-12-31	70.00	0.00	0.00	0.00	f	2026-11-03 11:48:39	2026-11-03 11:48:39.293035	2026-11-03 11:48:39.293035	\N
5	27	1	5	\N	\N	\N	\N	1	1	2026-12-31	33.00	15.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:39.293035	\N
15	38	1	5	\N	\N	\N	\N	1	1	2026-12-31	16.00	16.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:39.293035	\N
3	20	1	5	\N	\N	\N	\N	1	1	2026-12-31	500.00	230.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:52.182474	\N
14	8	1	5	\N	\N	\N	\N	1	1	2026-12-31	235.00	235.00	0.00	0.00	f	2026-11-03 11:48:31	2026-11-03 11:48:29.494074	2026-11-03 11:48:52.182474	\N
\.


--
-- Data for Name: stock_warehouse_orderpoint; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_warehouse_orderpoint (id, warehouse_id, location_id, product_id, replenishment_uom_id, company_id, route_id, create_uid, write_uid, name, trigger, snoozed_until, deadline_date, product_min_qty, product_max_qty, qty_to_order_computed, qty_to_order_manual, active, create_date, write_date, supplier_id) FROM stdin;
1	1	5	6	\N	1	\N	1	1	OP/00001	auto	\N	2026-11-08	5.00	10.00	0.00	\N	t	2026-11-03 11:48:29.494074	2026-11-08 11:49:06.751677	\N
2	1	5	34	\N	1	\N	1	1	OP/00002	auto	\N	2026-11-08	5.00	12.00	0.00	\N	t	2026-11-03 11:48:29.494074	2026-11-08 11:49:06.751677	\N
3	1	5	5	\N	1	\N	1	1	OP/00003	auto	\N	2026-11-08	3.00	5.00	0.00	\N	t	2026-11-03 11:48:29.494074	2026-11-08 11:49:06.751677	\N
\.


--
-- Name: account_move_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_move_id_seq', 56, true);


--
-- Name: product_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_product_id_seq', 55, true);


--
-- Name: product_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.product_template_id_seq', 37, true);


--
-- Name: purchase_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_order_id_seq', 11, true);


--
-- Name: purchase_order_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.purchase_order_line_id_seq', 23, true);


--
-- Name: res_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.res_company_id_seq', 3, true);


--
-- Name: res_partner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.res_partner_id_seq', 48, true);


--
-- Name: sale_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_order_id_seq', 24, true);


--
-- Name: sale_order_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sale_order_line_id_seq', 50, true);


--
-- Name: stock_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_location_id_seq', 32, true);


--
-- Name: stock_picking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_picking_id_seq', 49, true);


--
-- Name: stock_quant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_quant_id_seq', 46, true);


--
-- Name: stock_warehouse_orderpoint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_warehouse_orderpoint_id_seq', 3, true);


--
-- PostgreSQL database dump complete
--


